<?php

namespace App\Http\Resources\Admin;

use App\Enums\Locale;
use App\Models\Project;
use App\Support\PublicFile;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

/**
 * One image of the media library (A6): a project cover (projects.cover_image_path) or a
 * gallery image (project_images). Built from the array made by Admin\MediaController.
 *
 * Never exposes the stored path or any disk location: only the file name, its type and
 * size, and an admin-only preview URL. `available` is false when the stored path is unsafe
 * or the file is missing.
 */
class AdminMediaResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        /** @var array{kind: string, id: int, project: Project, path: ?string, width: ?int, height: ?int, sort_order: ?int, alt: array<string, ?string>, updated_at: mixed} $item */
        $item = $this->resource;
        $path = is_string($item['path']) ? str_replace('\\', '/', trim($item['path'])) : '';
        $available = PublicFile::url($path) !== null;
        $disk = Storage::disk('public');

        $width = $item['width'];
        $height = $item['height'];
        if ($available && ($width === null || $height === null)) {
            $size = @getimagesize($disk->path($path));
            [$width, $height] = is_array($size) ? [$size[0], $size[1]] : [null, null];
        }

        $titles = [];
        foreach (Locale::cases() as $locale) {
            $titles[$locale->value] = $item['project']->translations->first(fn ($t) => $t->locale === $locale)?->title;
        }

        return [
            'key' => "{$item['kind']}-{$item['id']}",
            'kind' => $item['kind'],
            'id' => $item['id'],
            'file_name' => $path === '' ? null : basename($path),
            'mime_type' => $available ? $disk->mimeType($path) : null,
            'size' => $available ? $disk->size($path) : null,
            'width' => $width,
            'height' => $height,
            'sort_order' => $item['sort_order'],
            'alt' => $item['alt'],
            'available' => $available,
            'preview_url' => $available ? "/api/admin/media/{$item['kind']}/{$item['id']}/preview" : null,
            'project' => [
                'id' => $item['project']->id,
                'status' => $item['project']->status->value,
                'title' => $titles,
            ],
            'updated_at' => $item['updated_at']?->toIso8601ZuluString(),
        ];
    }
}
