<?php

namespace App\Http\Requests\Admin;

use App\Enums\Locale;
use App\Support\WebpImage;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Upload one gallery image for an existing project (A6).
 *
 * - JPG / PNG / WebP only, at most 5 MB. `mimetypes` checks the real content type (finfo);
 *   the file is then decoded and re-encoded to WebP (App\Support\WebpImage).
 * - The client never chooses a storage path or file name, and cannot replace a file.
 * - Alternative texts are optional (the public site falls back to the project title).
 */
class MediaUploadRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $rules = [
            'project_id' => ['required', 'integer', Rule::exists('projects', 'id')],
            'file' => [
                'required', 'file', 'max:'.(WebpImage::MAX_BYTES / 1024),
                'mimes:jpg,jpeg,png,webp', 'mimetypes:image/jpeg,image/png,image/webp',
            ],
            'alt' => ['sometimes', 'nullable', 'array:'.implode(',', array_map(fn (Locale $l) => $l->value, Locale::cases()))],
        ];
        foreach (Locale::cases() as $locale) {
            $rules["alt.{$locale->value}"] = ['nullable', 'string', 'max:200'];
        }

        return $rules;
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'file.uploaded' => 'The file could not be uploaded. It may be larger than the server allows.',
            'file.max' => 'The image may not be larger than 5 MB.',
            'file.mimes' => 'Only JPG, PNG and WebP images are accepted.',
            'file.mimetypes' => 'Only JPG, PNG and WebP images are accepted.',
        ];
    }
}
