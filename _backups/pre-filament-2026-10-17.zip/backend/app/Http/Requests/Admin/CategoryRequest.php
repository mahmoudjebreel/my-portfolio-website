<?php

namespace App\Http\Requests\Admin;

use App\Enums\Locale;
use App\Models\Category;
use App\Support\ProjectContent;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

/**
 * Create / update a category from the administration (A5).
 *
 * Names per language (translations.en, translations.ar), each { name, slug }:
 * - at least one language is required; a language with any field filled must be complete
 *   (the table cannot store a partial translation);
 * - an existing language cannot be emptied here (nothing is deleted in this phase);
 * - name and slug are unique per language (same unique indexes as the table);
 * - an unchanged slug is accepted as stored, a new one must follow the slug format.
 */
class CategoryRequest extends FormRequest
{
    public const FIELDS = ['name', 'slug'];

    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $category = $this->category();

        $rules = [
            'sort_order' => ['sometimes', 'integer', 'min:0', 'max:65535'],
            'translations' => ['required', 'array:'.implode(',', array_map(fn (Locale $l) => $l->value, Locale::cases()))],
        ];

        foreach (Locale::cases() as $locale) {
            $prefix = "translations.{$locale->value}";
            $required = $this->contentRequired($locale->value) ? 'required' : 'nullable';

            $slug = [$required, 'string', 'max:100'];
            if ($this->input("{$prefix}.slug") !== $category?->translation($locale)?->slug) {
                $slug[] = 'regex:'.ProjectContent::SLUG_PATTERN;
            }
            $slug[] = Rule::unique('category_translations', 'slug')->where('locale', $locale->value)->ignore($category?->getKey(), 'category_id');

            $rules[$prefix] = ['nullable', 'array:'.implode(',', self::FIELDS)];
            $rules["{$prefix}.name"] = [
                $required, 'string', 'max:80',
                Rule::unique('category_translations', 'name')->where('locale', $locale->value)->ignore($category?->getKey(), 'category_id'),
            ];
            $rules["{$prefix}.slug"] = $slug;
        }

        return $rules;
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'translations.*.name.unique' => 'This name is already used by another category in this language.',
            'translations.*.slug.unique' => 'This slug is already used by another category in this language.',
            'translations.*.slug.regex' => 'The slug may only contain lowercase Latin letters, numbers and single hyphens.',
        ];
    }

    /**
     * @return array<int, callable>
     */
    public function after(): array
    {
        return [
            function (Validator $validator) {
                foreach (Locale::cases() as $locale) {
                    if (self::isFilled($this->input("translations.{$locale->value}"))) {
                        return;
                    }
                }
                $validator->errors()->add('translations', 'Fill in the name in at least one language.');
            },
        ];
    }

    /**
     * True when at least one field of a { name, slug } pair has a value.
     */
    public static function isFilled(mixed $content): bool
    {
        if (! is_array($content)) {
            return false;
        }
        foreach (self::FIELDS as $field) {
            if (is_string($content[$field] ?? null) && trim($content[$field]) !== '') {
                return true;
            }
        }

        return false;
    }

    public function category(): ?Category
    {
        $category = $this->route('category');

        return $category instanceof Category ? $category : null;
    }

    private function contentRequired(string $locale): bool
    {
        return self::isFilled($this->input("translations.{$locale}"))
            || $this->category()?->translation($locale) !== null;
    }
}
