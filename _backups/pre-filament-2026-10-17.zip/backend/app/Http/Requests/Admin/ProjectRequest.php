<?php

namespace App\Http\Requests\Admin;

use App\Enums\Locale;
use App\Enums\ProjectStatus;
use App\Models\Project;
use App\Support\ProjectContent;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

/**
 * Create / update a project from the administration.
 *
 * Content per language (translations.en, translations.ar):
 * - publishing requires both languages complete;
 * - a draft needs at least one complete language; a language with any field filled must be
 *   complete (the table cannot store a partial translation);
 * - an existing translation cannot be emptied here (nothing is deleted in this phase).
 *
 * Only the fields listed in rules() are used: cover_image_path, published_at and other
 * columns are never taken from the request.
 */
class ProjectRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $project = $this->project();
        $url = ['nullable', 'string', 'max:500', 'url:http,https'];

        $rules = [
            'status' => ['required', Rule::enum(ProjectStatus::class)],
            'is_featured' => ['sometimes', 'boolean'],
            'sort_order' => ['sometimes', 'integer', 'min:0', 'max:100000'],
            'github_url' => $url,
            'live_url' => $url,
            'category_ids' => ['sometimes', 'array', 'max:20'],
            'category_ids.*' => ['integer', 'distinct', Rule::exists('categories', 'id')],
            'technology_ids' => ['sometimes', 'array', 'max:50'],
            'technology_ids.*' => ['integer', 'distinct', Rule::exists('technologies', 'id')],
            'translations' => ['required', 'array:'.implode(',', array_map(fn (Locale $l) => $l->value, Locale::cases()))],
        ];

        foreach (Locale::cases() as $locale) {
            $prefix = "translations.{$locale->value}";
            $required = $this->contentRequired($locale->value) ? 'required' : 'nullable';

            $rules[$prefix] = ['nullable', 'array:'.implode(',', ProjectContent::fields())];
            $rules["{$prefix}.title"] = [$required, 'string', 'max:150'];
            $rules["{$prefix}.slug"] = [
                $required, 'string', 'max:160', 'regex:'.ProjectContent::SLUG_PATTERN,
                Rule::unique('project_translations', 'slug')
                    ->where('locale', $locale->value)
                    ->ignore($project?->getKey(), 'project_id'),
            ];
            $rules["{$prefix}.short_description"] = [$required, 'string', 'max:300'];
            $rules["{$prefix}.description"] = [$required, 'string', 'max:20000'];
            $rules["{$prefix}.problem"] = ['nullable', 'string', 'max:20000'];
            $rules["{$prefix}.solution"] = ['nullable', 'string', 'max:20000'];
            $rules["{$prefix}.cover_image_alt"] = ['nullable', 'string', 'max:200'];
        }

        return $rules;
    }

    /**
     * @return array<int, \Closure>
     */
    public function after(): array
    {
        return [
            function (Validator $validator) {
                $filled = array_filter(Locale::cases(), fn (Locale $l) => ProjectContent::isFilled($this->content($l->value)));
                if ($filled === []) {
                    $validator->errors()->add('translations', 'Fill in the content in at least one language.');
                }
                if ($this->publishing() && ProjectContent::incompleteLocales($this->contentByLocale()) !== []) {
                    $validator->errors()->add('status', 'To publish, complete the English and Arabic content.');
                }
            },
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'translations.*.slug.regex' => 'Use lowercase Latin letters, numbers and single hyphens.',
            'translations.*.slug.unique' => 'This slug is already used by another project in this language.',
        ];
    }

    public function project(): ?Project
    {
        $project = $this->route('project');

        return $project instanceof Project ? $project : null;
    }

    public function publishing(): bool
    {
        return $this->input('status') === ProjectStatus::Published->value;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function content(string $locale): ?array
    {
        $content = $this->input("translations.{$locale}");

        return is_array($content) ? $content : null;
    }

    /**
     * @return array<string, array<string, mixed>|null>
     */
    private function contentByLocale(): array
    {
        $byLocale = [];
        foreach (Locale::cases() as $locale) {
            $byLocale[$locale->value] = $this->content($locale->value);
        }

        return $byLocale;
    }

    private function contentRequired(string $locale): bool
    {
        return $this->publishing()
            || ProjectContent::isFilled($this->content($locale))
            || ($this->project()?->translations()->where('locale', $locale)->exists() ?? false);
    }
}
