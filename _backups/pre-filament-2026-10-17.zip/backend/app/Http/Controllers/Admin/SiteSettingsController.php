<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Locale;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SiteSettingsRequest;
use App\Models\SiteSetting;
use App\Support\PublicFile;
use App\Support\SiteSettingsForm;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Site settings for the administration (A6). Reads and writes only the keys listed by
 * SiteSettingsForm (taken from SiteSettingsRegistry). Nothing is deleted: clearing a value
 * stores an empty value, which the public API already treats as "not set".
 * Image settings are shown read-only, without their storage paths.
 */
class SiteSettingsController extends Controller
{
    public function show(): JsonResponse
    {
        return response()->json(['data' => $this->present()]);
    }

    public function update(SiteSettingsRequest $request): JsonResponse
    {
        DB::transaction(function () use ($request) {
            $settings = $this->settings();

            foreach (SiteSettingsForm::textKeys() as $key) {
                if (! $request->has("texts.{$key}")) {
                    continue;
                }
                $setting = $settings->get($key);
                foreach (Locale::cases() as $locale) {
                    $value = trim((string) $request->validated("texts.{$key}.{$locale->value}"));
                    $translation = $setting?->translations->first(fn ($t) => $t->locale === $locale);

                    if ($translation !== null) {
                        if ($translation->value !== $value) {
                            $translation->update(['value' => $value]);
                        }
                    } elseif ($value !== '') {
                        $setting ??= SiteSetting::create(['key' => $key, 'value' => null]);
                        $setting->translations()->create(['locale' => $locale->value, 'value' => $value]);
                    }
                }
            }

            foreach (array_keys(SiteSettingsForm::valueKeys()) as $key) {
                if (! $request->has("values.{$key}")) {
                    continue;
                }
                $value = trim((string) $request->validated("values.{$key}"));
                $value = $value === '' ? null : $value;
                $setting = $settings->get($key);

                if ($setting !== null) {
                    if ($setting->value !== $value) {
                        $setting->update(['value' => $value]);
                    }
                } elseif ($value !== null) {
                    SiteSetting::create(['key' => $key, 'value' => $value]);
                }
            }
        });

        return response()->json(['data' => $this->present()]);
    }

    /**
     * @return Collection<string, SiteSetting>
     */
    private function settings(): Collection
    {
        $keys = [...SiteSettingsForm::textKeys(), ...array_keys(SiteSettingsForm::valueKeys()), ...SiteSettingsForm::imageKeys()];

        return SiteSetting::query()->whereIn('key', $keys)->with('translations')->get()->keyBy('key');
    }

    /**
     * @return array<string, mixed>
     */
    private function present(): array
    {
        $settings = $this->settings();

        $texts = [];
        foreach (SiteSettingsForm::textKeys() as $key) {
            foreach (Locale::cases() as $locale) {
                $texts[$key][$locale->value] = $settings->get($key)?->translations->first(fn ($t) => $t->locale === $locale)?->value;
            }
        }

        $values = [];
        foreach (array_keys(SiteSettingsForm::valueKeys()) as $key) {
            $value = $settings->get($key)?->value;
            $values[$key] = is_string($value) ? $value : null;
        }

        $images = [];
        foreach (SiteSettingsForm::imageKeys() as $key) {
            $path = $settings->get($key)?->value;
            $images[$key] = [
                'set' => is_string($path) && trim($path) !== '',
                'url' => PublicFile::url($path),
            ];
        }

        $private = array_values(array_filter(
            [...SiteSettingsForm::textKeys(), ...array_keys(SiteSettingsForm::valueKeys())],
            fn (string $key) => ! SiteSettingsForm::isPublic($key),
        ));

        return [
            'texts' => $texts,
            'values' => $values,
            'images' => $images,
            'limits' => ['texts' => SiteSettingsForm::TEXT_LIMITS, 'email' => SiteSettingsForm::EMAIL_MAX, 'url' => SiteSettingsForm::URL_MAX],
            'private_keys' => $private,
        ];
    }
}
