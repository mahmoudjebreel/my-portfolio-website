<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Locale;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\MediaIndexRequest;
use App\Http\Requests\Admin\MediaUploadRequest;
use App\Http\Resources\Admin\AdminMediaResource;
use App\Models\Project;
use App\Models\ProjectImage;
use App\Support\PublicFile;
use App\Support\WebpImage;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use RuntimeException;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

/**
 * Media library for the administration (A6): project covers and gallery images.
 *
 * - Listing reads the existing relations only; covers stay read-only (changing a cover is
 *   not part of this phase).
 * - Uploading adds a gallery image (project_images) to an existing project.
 * - Nothing is ever deleted, detached or replaced, and no client-supplied path is used.
 */
class MediaController extends Controller
{
    /** Image types the preview endpoint will serve (never SVG or other active content). */
    private const PREVIEW_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif'];

    public function index(MediaIndexRequest $request): AnonymousResourceCollection
    {
        $search = mb_strtolower(trim((string) $request->validated('q')));
        $projectId = $request->validated('project');
        $kind = $request->validated('kind');

        // A portfolio holds few images: both sources are merged and paginated in memory,
        // and file details are read only for the current page.
        $items = $this->items($projectId, $kind)
            ->filter(fn (array $item) => $search === '' || $this->matches($item, $search))
            ->sortByDesc(fn (array $item) => [$item['updated_at']?->getTimestamp() ?? 0, $item['kind'] === 'cover' ? 1 : 0, $item['id']])
            ->values();

        $perPage = $request->perPage();
        $page = (int) $request->validated('page', 1);
        $paginator = new LengthAwarePaginator(
            $items->forPage($page, $perPage)->values(),
            $items->count(),
            $perPage,
            $page,
            ['path' => $request->url(), 'query' => $request->query()],
        );

        return AdminMediaResource::collection($paginator)->additional([
            'projects' => Project::query()->with('translations')->orderByDesc('updated_at')->get()->map(fn (Project $project) => [
                'id' => $project->id,
                'title' => $this->titles($project),
            ])->values(),
        ]);
    }

    public function show(string $kind, int $id): AdminMediaResource
    {
        return new AdminMediaResource($this->find($kind, $id));
    }

    /**
     * Streams the image for the admin preview. Only safe relative paths of existing files on
     * the public disk, only raster image types, never as a download or as HTML.
     */
    public function preview(string $kind, int $id): BinaryFileResponse
    {
        $path = str_replace('\\', '/', trim((string) $this->find($kind, $id)['path']));
        abort_if(PublicFile::url($path) === null, 404);

        $disk = Storage::disk('public');
        $type = $disk->mimeType($path);
        abort_unless(in_array($type, self::PREVIEW_TYPES, true), 404);

        return response()->file($disk->path($path), [
            'Content-Type' => $type,
            'Content-Disposition' => 'inline',
            'X-Content-Type-Options' => 'nosniff',
            'Content-Security-Policy' => "default-src 'none'; sandbox",
        ]);
    }

    public function store(MediaUploadRequest $request): JsonResponse
    {
        try {
            $encoded = WebpImage::encode((string) $request->file('file')->get());
        } catch (RuntimeException $exception) {
            throw ValidationException::withMessages(['file' => $exception->getMessage()]);
        }

        $project = Project::query()->findOrFail($request->validated('project_id'));
        $disk = Storage::disk('public');

        $image = DB::transaction(function () use ($project, $request, $encoded, $disk) {
            // Server-generated name; the uploaded file name is never used.
            do {
                $path = "projects/{$project->id}/".Str::uuid()->toString().'.webp';
            } while ($disk->exists($path));

            $image = $project->images()->create([
                'path' => $path,
                'width' => $encoded['width'],
                'height' => $encoded['height'],
                'sort_order' => min(65535, (int) $project->images()->max('sort_order') + 1),
            ]);

            foreach (Locale::cases() as $locale) {
                $alt = trim((string) $request->validated("alt.{$locale->value}"));
                if ($alt !== '') {
                    $image->translations()->create(['locale' => $locale->value, 'alt_text' => $alt]);
                }
            }

            // Written last: if it fails, the transaction is rolled back and no row points to it.
            if (! $disk->put($path, $encoded['bytes'])) {
                throw new RuntimeException('The image could not be stored.');
            }

            return $image;
        });

        return (new AdminMediaResource($this->galleryItem($image->load(['project.translations', 'translations']))))
            ->response()
            ->setStatusCode(201);
    }

    /**
     * @return Collection<int, array<string, mixed>>
     */
    private function items(?int $projectId, ?string $kind): Collection
    {
        $items = collect();

        if ($kind !== 'gallery') {
            Project::query()
                ->whereNotNull('cover_image_path')
                ->where('cover_image_path', '<>', '')
                ->when($projectId !== null, fn ($query) => $query->whereKey($projectId))
                ->with('translations')
                ->get()
                ->each(fn (Project $project) => $items->push($this->coverItem($project)));
        }

        if ($kind !== 'cover') {
            ProjectImage::query()
                ->when($projectId !== null, fn ($query) => $query->where('project_id', $projectId))
                ->with(['project.translations', 'translations'])
                ->get()
                ->each(fn (ProjectImage $image) => $items->push($this->galleryItem($image)));
        }

        return $items;
    }

    /**
     * @return array<string, mixed>
     */
    private function find(string $kind, int $id): array
    {
        if ($kind === 'cover') {
            $project = Project::query()->with('translations')->findOrFail($id);
            abort_if(! is_string($project->cover_image_path) || trim($project->cover_image_path) === '', 404);

            return $this->coverItem($project);
        }

        return $this->galleryItem(ProjectImage::query()->with(['project.translations', 'translations'])->findOrFail($id));
    }

    /**
     * @return array<string, mixed>
     */
    private function coverItem(Project $project): array
    {
        $alt = [];
        foreach (Locale::cases() as $locale) {
            $alt[$locale->value] = $project->translations->first(fn ($t) => $t->locale === $locale)?->cover_image_alt;
        }

        return [
            'kind' => 'cover', 'id' => $project->id, 'project' => $project, 'path' => $project->cover_image_path,
            'width' => null, 'height' => null, 'sort_order' => null, 'alt' => $alt, 'updated_at' => $project->updated_at,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function galleryItem(ProjectImage $image): array
    {
        $alt = [];
        foreach (Locale::cases() as $locale) {
            $alt[$locale->value] = $image->translations->first(fn ($t) => $t->locale === $locale)?->alt_text;
        }

        return [
            'kind' => 'gallery', 'id' => $image->id, 'project' => $image->project, 'path' => $image->path,
            'width' => $image->width, 'height' => $image->height, 'sort_order' => $image->sort_order, 'alt' => $alt,
            'updated_at' => $image->updated_at,
        ];
    }

    /**
     * @param  array<string, mixed>  $item
     */
    private function matches(array $item, string $search): bool
    {
        $haystack = [basename(str_replace('\\', '/', (string) $item['path'])), ...array_values($this->titles($item['project']))];
        foreach ($haystack as $value) {
            if (is_string($value) && str_contains(mb_strtolower($value), $search)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array<string, ?string>
     */
    private function titles(Project $project): array
    {
        $titles = [];
        foreach (Locale::cases() as $locale) {
            $titles[$locale->value] = $project->translations->first(fn ($t) => $t->locale === $locale)?->title;
        }

        return $titles;
    }
}
