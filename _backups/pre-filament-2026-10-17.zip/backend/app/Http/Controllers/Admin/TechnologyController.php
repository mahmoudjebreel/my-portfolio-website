<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Locale;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TechnologyIndexRequest;
use App\Http\Requests\Admin\TechnologyRequest;
use App\Http\Resources\Admin\AdminTechnologyResource;
use App\Models\Technology;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\DB;

/**
 * Technology management for the administration (routes/admin.php, "admin" middleware).
 * There is deliberately no delete action in this phase (A5), and an update never changes
 * whether a technology is shown on the public site.
 */
class TechnologyController extends Controller
{
    public function index(TechnologyIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));
        $group = $request->validated('group');
        $visibility = $request->validated('visibility');

        $technologies = Technology::query()
            ->when($search !== '', function (Builder $query) use ($search) {
                $like = '%'.addcslashes($search, '\\%_').'%';
                $query->where(fn (Builder $match) => $match
                    ->where('name', 'like', $like)
                    ->orWhereHas('translations', fn (Builder $translation) => $translation->where('display_name', 'like', $like)));
            })
            ->when($group !== null, fn (Builder $query) => $query->where('group', $group))
            ->when($visibility !== null, fn (Builder $query) => $query->where('is_visible', $visibility === 'visible'))
            ->with('translations')
            ->withCount('projects')
            ->orderBy('name')
            ->orderBy('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminTechnologyResource::collection($technologies);
    }

    public function show(Technology $technology): AdminTechnologyResource
    {
        return new AdminTechnologyResource($this->loadDetail($technology));
    }

    public function store(TechnologyRequest $request): JsonResponse
    {
        $technology = DB::transaction(function () use ($request) {
            $technology = new Technology;
            $this->fill($technology, $request);
            // Chosen only here; hidden unless the administrator asked otherwise.
            $technology->is_visible = (bool) $request->validated('is_visible', false);
            $technology->save();
            $this->saveTranslations($technology, $request);

            return $technology;
        });

        return (new AdminTechnologyResource($this->loadDetail($technology)))->response()->setStatusCode(201);
    }

    public function update(TechnologyRequest $request, Technology $technology): AdminTechnologyResource
    {
        DB::transaction(function () use ($request, $technology) {
            $this->fill($technology, $request); // is_visible is never changed here
            $technology->save();
            $this->saveTranslations($technology, $request);
            $technology->touch(); // translation-only changes also count as an update
        });

        return new AdminTechnologyResource($this->loadDetail($technology));
    }

    private function fill(Technology $technology, TechnologyRequest $request): void
    {
        $icon = $request->validated('icon');

        $technology->name = trim($request->validated('name'));
        $technology->slug = trim($request->validated('slug'));
        $technology->group = $request->validated('group');
        $technology->icon = is_string($icon) && trim($icon) !== '' ? trim($icon) : null;
        $technology->sort_order = (int) $request->validated('sort_order', $technology->sort_order ?? 0);
    }

    /**
     * Optional texts per language. An existing translation is updated (cleared fields become
     * null, the row is kept); a new one is created only when something was filled in.
     */
    private function saveTranslations(Technology $technology, TechnologyRequest $request): void
    {
        if (! $request->has('translations')) {
            return;
        }

        foreach (Locale::cases() as $locale) {
            $content = $request->validated("translations.{$locale->value}");
            $values = [];
            foreach (TechnologyRequest::TRANSLATION_FIELDS as $field) {
                $value = is_array($content) ? ($content[$field] ?? null) : null;
                $values[$field] = is_string($value) && trim($value) !== '' ? trim($value) : null;
            }

            $existing = $technology->translations()->where('locale', $locale->value)->first();
            if ($existing !== null) {
                $existing->update($values);
            } elseif (array_filter($values) !== []) {
                $technology->translations()->create(['locale' => $locale->value] + $values);
            }
        }
    }

    private function loadDetail(Technology $technology): Technology
    {
        return $technology->load('translations')->loadCount('projects');
    }
}
