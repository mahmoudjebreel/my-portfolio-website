<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Locale;
use App\Enums\ProjectStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProjectIndexRequest;
use App\Http\Requests\Admin\ProjectRequest;
use App\Http\Requests\Admin\ProjectStatusRequest;
use App\Http\Resources\Admin\AdminProjectDetailResource;
use App\Http\Resources\Admin\AdminProjectResource;
use App\Models\Project;
use App\Support\ProjectContent;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Project management for the administration (routes/admin.php, "admin" middleware).
 * There is deliberately no delete action in this phase, and images are read-only.
 */
class ProjectController extends Controller
{
    public function index(ProjectIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));
        $status = $request->validated('status');
        $category = $request->validated('category');

        $projects = Project::query()
            ->when($search !== '', fn (Builder $query) => $query->whereHas(
                'translations',
                fn (Builder $translation) => $translation->where('title', 'like', '%'.addcslashes($search, '\\%_').'%'),
            ))
            ->when($status !== null, fn (Builder $query) => $query->where('status', $status))
            ->when($category !== null, fn (Builder $query) => $query->whereHas(
                'categories',
                fn (Builder $categories) => $categories->whereKey($category),
            ))
            ->with(['translations', 'categories' => fn ($query) => $query->orderBy('categories.sort_order'), 'categories.translations'])
            ->orderByDesc('updated_at')
            ->orderByDesc('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminProjectResource::collection($projects);
    }

    public function show(Project $project): AdminProjectDetailResource
    {
        return new AdminProjectDetailResource($this->loadDetail($project));
    }

    public function store(ProjectRequest $request): JsonResponse
    {
        $project = DB::transaction(function () use ($request) {
            $project = new Project;
            $this->fill($project, $request);
            $project->save();
            $this->saveRelations($project, $request);

            return $project;
        });

        return (new AdminProjectDetailResource($this->loadDetail($project)))->response()->setStatusCode(201);
    }

    public function update(ProjectRequest $request, Project $project): AdminProjectDetailResource
    {
        DB::transaction(function () use ($request, $project) {
            $this->fill($project, $request);
            $project->save();
            $this->saveRelations($project, $request);
            $project->touch(); // content-only changes also count as an update
        });

        return new AdminProjectDetailResource($this->loadDetail($project));
    }

    /**
     * Publish or unpublish. Publishing is refused unless both languages are complete.
     */
    public function updateStatus(ProjectStatusRequest $request, Project $project): AdminProjectResource
    {
        $status = $request->status();

        if ($status === ProjectStatus::Published) {
            $byLocale = [];
            foreach (Locale::cases() as $locale) {
                $byLocale[$locale->value] = $project->translations()->where('locale', $locale->value)->first()?->only(ProjectContent::fields());
            }
            $missing = ProjectContent::incompleteLocales($byLocale);
            if ($missing !== []) {
                $messages = ['status' => 'To publish, complete the English and Arabic content.'];
                foreach ($missing as $locale) {
                    $messages["translations.{$locale}"] = 'This language is incomplete.';
                }
                throw ValidationException::withMessages($messages);
            }
        }

        $project->status = $status;
        if ($status === ProjectStatus::Published && $project->published_at === null) {
            $project->published_at = now();
        }
        $project->save();

        return new AdminProjectResource($project->load(['translations', 'categories.translations']));
    }

    private function fill(Project $project, ProjectRequest $request): void
    {
        $status = ProjectStatus::from($request->validated('status'));

        $project->status = $status;
        $project->is_featured = (bool) $request->validated('is_featured', $project->is_featured ?? false);
        $project->sort_order = (int) $request->validated('sort_order', $project->sort_order ?? 0);
        $project->github_url = $request->validated('github_url');
        $project->live_url = $request->validated('live_url');

        // First publication date; kept when a project is unpublished and published again.
        if ($status === ProjectStatus::Published && $project->published_at === null) {
            $project->published_at = now();
        }
    }

    private function saveRelations(Project $project, ProjectRequest $request): void
    {
        foreach (Locale::cases() as $locale) {
            $content = $request->validated("translations.{$locale->value}");
            if (! is_array($content) || ! ProjectContent::isFilled($content)) {
                continue; // validation guarantees an existing translation is never emptied
            }

            $values = [];
            foreach (ProjectContent::fields() as $field) {
                $values[$field] = $content[$field] ?? null;
            }
            $project->translations()->updateOrCreate(['locale' => $locale->value], $values);
        }

        if ($request->has('category_ids')) {
            $project->categories()->sync($request->validated('category_ids', []));
        }
        if ($request->has('technology_ids')) {
            $project->technologies()->sync($request->validated('technology_ids', []));
        }
    }

    private function loadDetail(Project $project): Project
    {
        return $project->load(['translations', 'categories', 'technologies'])->loadCount('images');
    }
}
