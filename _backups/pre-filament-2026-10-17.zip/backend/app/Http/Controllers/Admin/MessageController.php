<?php

namespace App\Http\Controllers\Admin;

use App\Enums\MessageStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\MessageIndexRequest;
use App\Http\Requests\Admin\MessageStatusRequest;
use App\Http\Resources\Admin\AdminMessageResource;
use App\Models\ContactMessage;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Contact inbox for the administration (A7), on the existing contact_messages table
 * (status unread / read / archived, read_at). Reading never changes a message; only the
 * explicit status action does. There is no delete action and no email is ever sent.
 */
class MessageController extends Controller
{
    public function index(MessageIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));
        $status = $request->validated('status');

        $messages = ContactMessage::query()
            ->when($search !== '', function (Builder $query) use ($search) {
                $like = '%'.addcslashes($search, '\\%_').'%';
                $query->where(fn (Builder $match) => $match
                    ->where('name', 'like', $like)
                    ->orWhere('email', 'like', $like)
                    ->orWhere('subject', 'like', $like));
            })
            ->when($status !== null, fn (Builder $query) => $query->where('status', $status))
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminMessageResource::collection($messages)->additional(['unread_count' => $this->unreadCount()]);
    }

    public function show(ContactMessage $message): JsonResponse
    {
        return (new AdminMessageResource($message))->withBody()->additional(['unread_count' => $this->unreadCount()])->response();
    }

    /**
     * Read: status "read" and the first read time is kept. Unread: status "unread" and
     * read_at cleared. Archived messages are left as they are.
     */
    public function updateStatus(MessageStatusRequest $request, ContactMessage $message): JsonResponse
    {
        abort_if($message->status === MessageStatus::Archived, 409, 'Archived messages cannot be changed here.');

        $status = $request->status();
        $message->status = $status;
        $message->read_at = $status === MessageStatus::Read ? ($message->read_at ?? now()) : null;
        $message->save();

        return (new AdminMessageResource($message))->withBody()->additional(['unread_count' => $this->unreadCount()])->response();
    }

    private function unreadCount(): int
    {
        return ContactMessage::query()->where('status', MessageStatus::Unread)->count();
    }
}
