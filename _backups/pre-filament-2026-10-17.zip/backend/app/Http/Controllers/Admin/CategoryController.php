<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Locale;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CategoryIndexRequest;
use App\Http\Requests\Admin\CategoryRequest;
use App\Http\Resources\Admin\AdminCategoryResource;
use App\Models\Category;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Support\Facades\DB;

/**
 * Category management for the administration (routes/admin.php, "admin" middleware).
 * There is deliberately no delete action in this phase (A5).
 */
class CategoryController extends Controller
{
    public function index(CategoryIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));

        $categories = Category::query()
            ->when($search !== '', fn (Builder $query) => $query->whereHas(
                'translations',
                fn (Builder $translation) => $translation->where('name', 'like', '%'.addcslashes($search, '\\%_').'%'),
            ))
            ->with('translations')
            ->withCount('projects')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminCategoryResource::collection($categories);
    }

    public function show(Category $category): AdminCategoryResource
    {
        return new AdminCategoryResource($this->loadDetail($category));
    }

    public function store(CategoryRequest $request): JsonResponse
    {
        $category = DB::transaction(function () use ($request) {
            $category = Category::create(['sort_order' => (int) $request->validated('sort_order', 0)]);
            $this->saveTranslations($category, $request);

            return $category;
        });

        return (new AdminCategoryResource($this->loadDetail($category)))->response()->setStatusCode(201);
    }

    public function update(CategoryRequest $request, Category $category): AdminCategoryResource
    {
        DB::transaction(function () use ($request, $category) {
            $category->sort_order = (int) $request->validated('sort_order', $category->sort_order);
            $category->save();
            $this->saveTranslations($category, $request);
            $category->touch(); // name-only changes also count as an update
        });

        return new AdminCategoryResource($this->loadDetail($category));
    }

    private function saveTranslations(Category $category, CategoryRequest $request): void
    {
        foreach (Locale::cases() as $locale) {
            $content = $request->validated("translations.{$locale->value}");
            if (! CategoryRequest::isFilled($content)) {
                continue; // validation guarantees an existing translation is never emptied
            }

            $category->translations()->updateOrCreate(
                ['locale' => $locale->value],
                ['name' => trim($content['name']), 'slug' => trim($content['slug'])],
            );
        }
    }

    private function loadDetail(Category $category): Category
    {
        return $category->load('translations')->loadCount('projects');
    }
}
