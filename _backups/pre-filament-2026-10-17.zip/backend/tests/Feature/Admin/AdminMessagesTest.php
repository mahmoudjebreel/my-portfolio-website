<?php

namespace Tests\Feature\Admin;

use App\Enums\MessageStatus;
use App\Models\ContactMessage;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Admin contact inbox (A7). Test database only (TestCase guard + RefreshDatabase).
 */
class AdminMessagesTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
    }

    private function signIn(): void
    {
        $this->actingAs(User::factory()->admin()->create(), 'web');
    }

    public function test_every_inbox_route_requires_an_admin_session(): void
    {
        $message = ContactMessage::factory()->create();
        $requests = [
            ['GET', '/api/admin/messages'],
            ['GET', "/api/admin/messages/{$message->id}"],
            ['PATCH', "/api/admin/messages/{$message->id}/status"],
        ];

        foreach ($requests as [$method, $uri]) {
            $this->json($method, $uri, ['status' => 'read'])->assertUnauthorized();
        }
        $this->actingAs(User::factory()->create(), 'web');
        foreach ($requests as [$method, $uri]) {
            $this->json($method, $uri, ['status' => 'read'])->assertForbidden();
        }
        $this->assertSame(MessageStatus::Unread, $message->fresh()->status);
    }

    public function test_the_inbox_lists_newest_first_with_search_filters_and_unread_count(): void
    {
        $this->signIn();
        $old = ContactMessage::factory()->create(['name' => 'Sara', 'email' => 'sara@example.com', 'subject' => 'Website 100%', 'created_at' => now()->subDays(2)]);
        $new = ContactMessage::factory()->create(['name' => 'Omar', 'subject' => 'Logo', 'status' => MessageStatus::Read, 'read_at' => now(), 'created_at' => now()->subDay()]);
        ContactMessage::factory()->create(['name' => 'Archived person', 'status' => MessageStatus::Archived, 'created_at' => now()->subDays(3)]);

        $response = $this->getJson('/api/admin/messages')->assertOk();
        $response->assertJsonPath('unread_count', 1)->assertJsonPath('meta.total', 3);
        $this->assertSame([$new->id, $old->id], array_slice(collect($response->json('data'))->pluck('id')->all(), 0, 2));
        $response->assertJsonMissingPath('data.0.message');

        $ids = fn (string $query) => collect($this->getJson('/api/admin/messages?'.$query)->assertOk()->json('data'))->pluck('id')->all();
        $this->assertSame([$old->id], $ids('q=sara%40example'));
        $this->assertSame([$old->id], $ids('q='.urlencode('100%')));
        $this->assertSame([], $ids('q='.urlencode('%')));
        $this->assertSame([$new->id], $ids('status=read'));
        $this->getJson('/api/admin/messages?status=spam')->assertStatus(422);
    }

    public function test_opening_a_message_shows_it_in_full_without_changing_it(): void
    {
        $this->signIn();
        $message = ContactMessage::factory()->create([
            'email' => 'a?cc=x@example.com',
            'message' => "<script>alert(1)</script>\nSecond line",
        ]);

        $this->getJson("/api/admin/messages/{$message->id}")->assertOk()
            ->assertJsonPath('data.message', "<script>alert(1)</script>\nSecond line")
            ->assertJsonPath('data.status', 'unread');
        $this->assertNull($message->fresh()->read_at);

        $invalid = ContactMessage::factory()->create(['email' => 'not an email']);
        $this->getJson("/api/admin/messages/{$invalid->id}")->assertJsonPath('data.reply_email', null);
        $this->getJson('/api/admin/messages/999999')->assertNotFound();
    }

    public function test_marking_read_and_unread(): void
    {
        $this->signIn();
        $message = ContactMessage::factory()->create();

        $this->patchJson("/api/admin/messages/{$message->id}/status", ['status' => 'read'])->assertOk()
            ->assertJsonPath('data.status', 'read')->assertJsonPath('unread_count', 0);
        $firstRead = $message->fresh()->read_at;
        $this->assertNotNull($firstRead);

        $this->travel(1)->hours();
        $this->patchJson("/api/admin/messages/{$message->id}/status", ['status' => 'read'])->assertOk();
        $this->assertEquals($firstRead, $message->fresh()->read_at);

        $this->patchJson("/api/admin/messages/{$message->id}/status", ['status' => 'unread'])->assertOk()
            ->assertJsonPath('data.read_at', null)->assertJsonPath('unread_count', 1);

        $this->patchJson("/api/admin/messages/{$message->id}/status", ['status' => 'archived'])->assertStatus(422);
        $archived = ContactMessage::factory()->create(['status' => MessageStatus::Archived]);
        $this->patchJson("/api/admin/messages/{$archived->id}/status", ['status' => 'read'])->assertStatus(409);
        $this->assertSame(MessageStatus::Archived, $archived->fresh()->status);
    }

    public function test_there_is_no_delete_route(): void
    {
        $this->signIn();
        $message = ContactMessage::factory()->create();

        $this->deleteJson("/api/admin/messages/{$message->id}")->assertStatus(405);
        $this->assertModelExists($message);
    }
}
