<?php

namespace Tests\Feature\Admin;

use App\Http\Requests\Admin\LoginRequest;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Log;
use Tests\Feature\Admin\Concerns\InteractsWithAdminSession;
use Tests\TestCase;

class AdminAuthTest extends TestCase
{
    use InteractsWithAdminSession;
    use RefreshDatabase;

    public function test_an_admin_signs_in_with_valid_credentials(): void
    {
        $admin = $this->admin(['name' => 'Site Owner', 'email' => 'owner@example.com']);

        $this->signIn($admin)
            ->assertOk()
            ->assertExactJson(['data' => ['id' => $admin->id, 'name' => 'Site Owner', 'email' => 'owner@example.com']]);

        $this->sameBrowser()->getJson('/api/admin/me')->assertOk()->assertJsonPath('data.email', 'owner@example.com');
    }

    public function test_a_wrong_password_is_rejected_with_a_generic_message(): void
    {
        $admin = $this->admin();

        $this->signIn($admin, 'wrong password!!')
            ->assertStatus(422)
            ->assertExactJson([
                'message' => LoginRequest::FAILED_MESSAGE,
                'errors' => ['email' => [LoginRequest::FAILED_MESSAGE]],
            ]);

        $this->assertGuest('web');
    }

    public function test_unknown_email_wrong_password_and_non_admin_get_the_identical_response(): void
    {
        $admin = $this->admin(['email' => 'admin@example.com']);
        $regular = $this->regularUser(['email' => 'user@example.com']);

        $wrongPassword = $this->postJson('/api/admin/login', ['email' => $admin->email, 'password' => 'not the password'])->assertStatus(422);
        $unknownEmail = $this->postJson('/api/admin/login', ['email' => 'nobody@example.com', 'password' => 'not the password'])->assertStatus(422);
        // A regular account with its CORRECT password: still the same answer.
        $nonAdmin = $this->postJson('/api/admin/login', ['email' => $regular->email, 'password' => 'correct horse battery staple'])->assertStatus(422);

        $this->assertSame($wrongPassword->json(), $unknownEmail->json());
        $this->assertSame($wrongPassword->json(), $nonAdmin->json());
        $this->assertGuest('web');
    }

    public function test_invalid_input_is_rejected(): void
    {
        $this->postJson('/api/admin/login', [])->assertStatus(422)->assertJsonValidationErrors(['email', 'password']);
        $this->postJson('/api/admin/login', ['email' => 'not-an-email', 'password' => 'x'])->assertJsonValidationErrors(['email']);
        $this->postJson('/api/admin/login', ['email' => ['a@example.com'], 'password' => 'x'])->assertJsonValidationErrors(['email']);
        $this->postJson('/api/admin/login', ['email' => 'a@example.com', 'password' => str_repeat('x', 1001)])->assertJsonValidationErrors(['password']);
        $this->assertGuest('web');
    }

    public function test_the_session_id_and_csrf_token_are_rotated_on_sign_in(): void
    {
        $admin = $this->admin();

        $this->keepCookies($this->sameBrowser()->getJson('/api/admin/csrf-cookie'))->assertNoContent();
        $sessionBefore = $this->sessionId;
        $xsrfBefore = $this->xsrfCookie;

        $this->keepCookies(
            $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $xsrfBefore)
                ->postJson('/api/admin/login', ['email' => $admin->email, 'password' => 'correct horse battery staple']),
        )->assertOk();

        $this->assertNotNull($sessionBefore);
        $this->assertNotSame($sessionBefore, $this->sessionId);
        $this->assertNotSame(decrypt($xsrfBefore, false), decrypt((string) $this->xsrfCookie, false));

        // The new session is authenticated; the pre-login session id gives nothing.
        $this->sameBrowser()->getJson('/api/admin/me')->assertOk();
        $this->sameBrowser($sessionBefore)->getJson('/api/admin/me')->assertUnauthorized();
    }

    public function test_sign_out_destroys_the_session(): void
    {
        $admin = $this->admin();
        $this->signIn($admin)->assertOk();
        $signedInSession = $this->sessionId;

        $this->sameBrowser()->getJson('/api/admin/me')->assertOk();

        $this->keepCookies(
            $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $this->xsrfCookie)->postJson('/api/admin/logout'),
        )->assertNoContent();

        // Neither the old session id nor the new one is authenticated.
        $this->sameBrowser($signedInSession)->getJson('/api/admin/me')->assertUnauthorized();
        $this->sameBrowser()->getJson('/api/admin/me')->assertUnauthorized();
        $this->assertNotSame($signedInSession, $this->sessionId);
    }

    public function test_sign_out_without_a_session_is_harmless(): void
    {
        $this->postJson('/api/admin/logout')->assertNoContent();
    }

    public function test_requests_without_a_session_are_unauthenticated(): void
    {
        $this->getJson('/api/admin/me')->assertUnauthorized()->assertExactJson(['message' => 'Unauthenticated.']);
    }

    public function test_the_session_expires_after_the_configured_lifetime(): void
    {
        $this->assertSame(120, config('session.lifetime'));
        $admin = $this->admin();
        $this->signIn($admin)->assertOk();

        $this->travel(119)->minutes();
        $this->sameBrowser()->getJson('/api/admin/me')->assertOk();

        // Activity extends the session; 121 minutes without any request ends it.
        $this->travel(121)->minutes();
        $this->sameBrowser()->getJson('/api/admin/me')->assertUnauthorized();
    }

    public function test_there_is_no_remember_me(): void
    {
        $admin = $this->admin();
        $rememberTokenBefore = $admin->remember_token;

        $response = $this->postJson('/api/admin/login', [
            'email' => $admin->email,
            'password' => 'correct horse battery staple',
            'remember' => true,
        ])->assertOk();

        foreach ($response->headers->getCookies() as $cookie) {
            $this->assertStringStartsNotWith('remember_', $cookie->getName());
        }
        $this->assertSame($rememberTokenBefore, $admin->fresh()->remember_token);
    }

    public function test_the_session_cookie_is_http_only_and_the_xsrf_cookie_is_readable(): void
    {
        $response = $this->getJson('/api/admin/csrf-cookie')->assertNoContent();

        $session = $response->getCookie(config('session.cookie'), decrypt: false);
        $xsrf = $response->getCookie('XSRF-TOKEN', decrypt: false);

        $this->assertTrue($session->isHttpOnly());
        $this->assertSame('lax', $session->getSameSite());
        $this->assertFalse($xsrf->isHttpOnly(), 'The SPA must be able to read XSRF-TOKEN to send it back.');
        $this->assertSame('lax', $xsrf->getSameSite());
    }

    public function test_admin_data_responses_are_not_stored_by_caches(): void
    {
        // SetCacheHeaders only touches responses with a body (the 204 of csrf-cookie keeps
        // the framework default "no-cache, private"); data such as /me must be "no-store".
        $this->actingAs($this->admin(), 'web')
            ->getJson('/api/admin/me')
            ->assertOk()
            ->assertHeader('Cache-Control', 'no-store, private');
    }

    public function test_credentials_are_never_written_to_the_log(): void
    {
        Log::spy();
        $admin = $this->admin();

        $this->postJson('/api/admin/login', ['email' => $admin->email, 'password' => 'a wrong password value']);
        $this->postJson('/api/admin/login', ['email' => $admin->email, 'password' => 'correct horse battery staple']);

        foreach (['emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug', 'log'] as $level) {
            Log::shouldNotHaveReceived($level);
        }
    }
}
