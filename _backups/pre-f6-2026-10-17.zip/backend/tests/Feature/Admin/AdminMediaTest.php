<?php

namespace Tests\Feature\Admin;

use App\Models\ProjectImage;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\Feature\Api\Concerns\BuildsProjects;
use Tests\TestCase;

/**
 * Admin media API (A6). Test database only (TestCase guard + RefreshDatabase), fake disk.
 */
class AdminMediaTest extends TestCase
{
    use BuildsProjects;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
        Storage::fake('public');
    }

    private function signIn(): void
    {
        $this->actingAs(User::factory()->admin()->create(), 'web');
    }

    public function test_every_media_route_requires_an_admin_session(): void
    {
        $project = $this->englishProject('with-image');
        $image = ProjectImage::factory()->create(['project_id' => $project->id]);
        $requests = [
            ['GET', '/api/admin/media'],
            ['GET', "/api/admin/media/gallery/{$image->id}"],
            ['GET', "/api/admin/media/gallery/{$image->id}/preview"],
            ['POST', '/api/admin/media'],
        ];

        foreach ($requests as [$method, $uri]) {
            $this->json($method, $uri, ['project_id' => $project->id])->assertUnauthorized();
        }
        $this->actingAs(User::factory()->create(), 'web');
        foreach ($requests as [$method, $uri]) {
            $this->json($method, $uri, ['project_id' => $project->id])->assertForbidden();
        }
        $this->assertSame(1, ProjectImage::query()->count());
    }

    public function test_covers_and_gallery_images_are_listed_without_storage_paths(): void
    {
        $this->signIn();
        Storage::disk('public')->put('projects/cover.png', UploadedFile::fake()->image('cover.png', 40, 30)->get());
        Storage::disk('public')->put('projects/one.webp', UploadedFile::fake()->image('one.webp', 64, 48)->get());
        $shop = $this->makeProject(['en' => ['slug' => 'shop', 'title' => 'Online Shop']], ['cover_image_path' => 'projects/cover.png']);
        $image = ProjectImage::factory()->create(['project_id' => $shop->id, 'path' => 'projects/one.webp', 'width' => 64, 'height' => 48]);
        $image->translations()->create(['locale' => 'ar', 'alt_text' => 'صورة']);
        ProjectImage::factory()->create(['project_id' => $shop->id, 'path' => '../.env']);

        $response = $this->getJson('/api/admin/media')->assertOk();
        $response->assertJsonPath('meta.total', 3)->assertJsonPath('projects.0.title.en', 'Online Shop');
        $items = collect($response->json('data'))->keyBy('key');

        $cover = $items["cover-{$shop->id}"];
        $this->assertSame(['cover.png', 'image/png', 40, 30, true], [$cover['file_name'], $cover['mime_type'], $cover['width'], $cover['height'], $cover['available']]);
        $this->assertSame("/api/admin/media/cover/{$shop->id}/preview", $cover['preview_url']);

        $gallery = $items["gallery-{$image->id}"];
        $this->assertSame(['one.webp', 'صورة', 'Online Shop'], [$gallery['file_name'], $gallery['alt']['ar'], $gallery['project']['title']['en']]);
        $this->assertGreaterThan(0, $gallery['size']);

        $unsafe = $items->firstWhere('file_name', '.env');
        $this->assertFalse($unsafe['available']);
        $this->assertNull($unsafe['preview_url']);
        $this->assertStringNotContainsString('projects/', $response->getContent());
        $this->assertStringNotContainsString('storage', strtolower(json_encode($response->json('data'))));

        $this->assertSame([$image->id], collect($this->getJson('/api/admin/media?kind=gallery&q=one')->json('data'))->pluck('id')->all());
        $this->assertCount(1, $this->getJson('/api/admin/media?kind=cover')->json('data'));
        $this->getJson('/api/admin/media?kind=video')->assertStatus(422);
    }

    public function test_the_preview_serves_only_safe_existing_raster_images(): void
    {
        $this->signIn();
        Storage::disk('public')->put('projects/ok.png', UploadedFile::fake()->image('ok.png', 10, 10)->get());
        Storage::disk('public')->put('projects/evil.svg', '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
        $project = $this->englishProject('preview');
        $ok = ProjectImage::factory()->create(['project_id' => $project->id, 'path' => 'projects/ok.png']);
        $svg = ProjectImage::factory()->create(['project_id' => $project->id, 'path' => 'projects/evil.svg']);
        $missing = ProjectImage::factory()->create(['project_id' => $project->id, 'path' => 'projects/missing.webp']);
        $traversal = ProjectImage::factory()->create(['project_id' => $project->id, 'path' => '../../.env']);

        $this->get("/api/admin/media/gallery/{$ok->id}/preview")->assertOk()
            ->assertHeader('Content-Type', 'image/png')->assertHeader('X-Content-Type-Options', 'nosniff');
        foreach ([$svg, $missing, $traversal] as $image) {
            $this->get("/api/admin/media/gallery/{$image->id}/preview")->assertNotFound();
        }
        $this->get("/api/admin/media/cover/{$project->id}/preview")->assertNotFound();
    }

    public function test_an_upload_is_re_encoded_to_webp_under_a_server_generated_name(): void
    {
        $this->signIn();
        $project = $this->englishProject('gallery');
        ProjectImage::factory()->create(['project_id' => $project->id, 'sort_order' => 4]);

        $response = $this->post('/api/admin/media', [
            'project_id' => $project->id,
            'file' => UploadedFile::fake()->image('../../evil name.png', 800, 600),
            'alt' => ['en' => 'Home page', 'ar' => null],
        ], ['Accept' => 'application/json'])->assertCreated();

        $image = ProjectImage::query()->latest('id')->firstOrFail();
        $this->assertMatchesRegularExpression("#^projects/{$project->id}/[0-9a-f-]{36}\\.webp$#", $image->path);
        $this->assertSame([800, 600, 5], [$image->width, $image->height, $image->sort_order]);
        Storage::disk('public')->assertExists($image->path);
        $this->assertSame('RIFF', substr(Storage::disk('public')->get($image->path), 0, 4));
        $this->assertSame('Home page', $image->translation('en')->alt_text);
        $this->assertNull($image->translation('ar'));
        $response->assertJsonPath('data.mime_type', 'image/webp')->assertJsonPath('data.file_name', basename($image->path));
    }

    public function test_invalid_uploads_are_refused_without_writing_anything(): void
    {
        $this->signIn();
        $project = $this->englishProject('gallery');
        $upload = fn (array $data) => $this->post('/api/admin/media', $data + ['project_id' => $project->id], ['Accept' => 'application/json']);

        $upload(['file' => UploadedFile::fake()->create('notes.pdf', 10, 'application/pdf')])->assertStatus(422)->assertJsonValidationErrors('file');
        $upload(['file' => UploadedFile::fake()->createWithContent('fake.png', '<?php echo 1;')])->assertStatus(422)->assertJsonValidationErrors('file');
        $upload(['file' => UploadedFile::fake()->image('big.jpg')->size(6000)])->assertStatus(422)->assertJsonValidationErrors('file');
        $upload(['file' => UploadedFile::fake()->image('anim.gif')])->assertStatus(422)->assertJsonValidationErrors('file');
        $this->post('/api/admin/media', ['project_id' => 999999, 'file' => UploadedFile::fake()->image('a.png')], ['Accept' => 'application/json'])
            ->assertStatus(422)->assertJsonValidationErrors('project_id');
        $upload(['file' => UploadedFile::fake()->image('a.png'), 'path' => 'projects/override.webp'])->assertCreated();

        Storage::disk('public')->assertMissing('projects/override.webp');
        $this->assertSame(1, ProjectImage::query()->count());
    }

    public function test_there_is_no_delete_or_replace_route(): void
    {
        $this->signIn();
        $image = ProjectImage::factory()->create(['project_id' => $this->englishProject('kept')->id]);

        $this->deleteJson("/api/admin/media/gallery/{$image->id}")->assertStatus(405);
        $this->putJson("/api/admin/media/gallery/{$image->id}")->assertStatus(405);
        $this->assertModelExists($image);
    }
}
