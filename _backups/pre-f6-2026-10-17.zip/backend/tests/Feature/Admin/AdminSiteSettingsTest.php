<?php

namespace Tests\Feature\Admin;

use App\Models\SiteSetting;
use App\Models\User;
use App\Support\SiteSettingsForm;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/**
 * Admin site settings API (A6). Test database only (TestCase guard + RefreshDatabase).
 */
class AdminSiteSettingsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
    }

    private function signIn(): void
    {
        $this->actingAs(User::factory()->admin()->create(), 'web');
    }

    /**
     * @return array<string, mixed>
     */
    private function payload(array $texts = [], array $values = []): array
    {
        $allTexts = [];
        foreach (SiteSettingsForm::textKeys() as $key) {
            $allTexts[$key] = $texts[$key] ?? ['en' => null, 'ar' => null];
        }

        return [
            'texts' => $allTexts,
            'values' => $values + ['contact_email' => null, 'github_url' => null, 'linkedin_url' => null, 'notification_email' => null],
        ];
    }

    public function test_settings_require_an_admin_session(): void
    {
        $this->getJson('/api/admin/site-settings')->assertUnauthorized();
        $this->putJson('/api/admin/site-settings', $this->payload())->assertUnauthorized();
        $this->actingAs(User::factory()->create(), 'web');
        $this->getJson('/api/admin/site-settings')->assertForbidden();
        $this->putJson('/api/admin/site-settings', $this->payload())->assertForbidden();
        $this->assertSame(0, SiteSetting::query()->count());
    }

    public function test_reading_shows_known_keys_only_and_changes_nothing(): void
    {
        $this->signIn();
        $name = SiteSetting::create(['key' => 'display_name', 'value' => null]);
        $name->translations()->create(['locale' => 'en', 'value' => 'Jebreel']);
        SiteSetting::create(['key' => 'github_url', 'value' => 'https://github.com/example']);
        SiteSetting::create(['key' => 'profile_image_path', 'value' => 'profile/me.webp']);
        SiteSetting::create(['key' => 'mail_password', 'value' => 'secret']);
        $before = SiteSetting::query()->get()->toJson();

        $response = $this->getJson('/api/admin/site-settings')->assertOk();
        $response->assertJsonPath('data.texts.display_name', ['en' => 'Jebreel', 'ar' => null]);
        $response->assertJsonPath('data.values.github_url', 'https://github.com/example');
        $response->assertJsonPath('data.images.profile_image_path', ['set' => true, 'url' => null]);
        $response->assertJsonPath('data.private_keys', ['notification_email']);
        $this->assertStringNotContainsString('secret', $response->getContent());
        $this->assertStringNotContainsString('profile/me.webp', $response->getContent());
        $this->assertSame($before, SiteSetting::query()->get()->toJson());
    }

    public function test_saving_creates_updates_and_clears_without_deleting(): void
    {
        $this->signIn();
        $footer = SiteSetting::create(['key' => 'footer_text', 'value' => null]);
        $footer->translations()->create(['locale' => 'ar', 'value' => 'نص قديم']);
        SiteSetting::create(['key' => 'linkedin_url', 'value' => 'https://linkedin.com/in/old']);

        $this->putJson('/api/admin/site-settings', $this->payload(
            ['display_name' => ['en' => 'Jebreel', 'ar' => 'جبريل'], 'footer_text' => ['en' => null, 'ar' => null]],
            ['github_url' => 'https://github.com/jebreel', 'contact_email' => 'hello@example.com'],
        ))->assertOk()
            ->assertJsonPath('data.texts.display_name', ['en' => 'Jebreel', 'ar' => 'جبريل'])
            ->assertJsonPath('data.texts.footer_text.ar', '')
            ->assertJsonPath('data.values.linkedin_url', null);

        $this->assertDatabaseHas('site_setting_translations', ['site_setting_id' => $footer->id, 'locale' => 'ar', 'value' => '']);
        $this->assertSame(1, SiteSetting::query()->where('key', 'linkedin_url')->count());
        $this->assertNull(SiteSetting::query()->where('key', 'hero_headline')->first(), 'empty keys are not created');

        $this->getJson('/api/site-settings?locale=ar')->assertOk()
            ->assertJsonPath('data.display_name', 'جبريل')
            ->assertJsonPath('data.footer_text', null)
            ->assertJsonPath('data.contact.github_url', 'https://github.com/jebreel');
    }

    public function test_values_are_validated_and_unknown_keys_refused(): void
    {
        $this->signIn();

        $this->putJson('/api/admin/site-settings', $this->payload([], ['github_url' => 'javascript:alert(1)', 'contact_email' => 'not-an-email']))
            ->assertStatus(422)->assertJsonValidationErrors(['values.github_url', 'values.contact_email']);
        $this->putJson('/api/admin/site-settings', $this->payload(['footer_text' => ['en' => str_repeat('a', 301), 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors('texts.footer_text.en');

        $payload = $this->payload();
        $payload['values']['profile_image_path'] = '../../.env';
        $payload['texts']['mail_password'] = ['en' => 'x'];
        $this->putJson('/api/admin/site-settings', $payload)->assertStatus(422)->assertJsonValidationErrors(['values', 'texts']);

        $this->assertSame(0, SiteSetting::query()->count());
    }
}
