<?php

namespace Tests\Feature\Admin;

use App\Enums\TechnologyGroup;
use App\Models\Category;
use App\Models\Technology;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Feature\Api\Concerns\BuildsProjects;
use Tests\TestCase;

/**
 * Admin category and technology API (A5). Test database only (TestCase guard + RefreshDatabase).
 */
class AdminCatalogTest extends TestCase
{
    use BuildsProjects;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
    }

    private function signIn(): void
    {
        $this->actingAs(User::factory()->admin()->create(), 'web');
    }

    /**
     * @return array<string, mixed>
     */
    private function category(array $overrides = []): array
    {
        return $overrides + [
            'sort_order' => 0,
            'translations' => ['en' => ['name' => 'Web Applications', 'slug' => 'web-applications'], 'ar' => null],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function technology(array $overrides = []): array
    {
        return $overrides + [
            'name' => 'Vue',
            'slug' => 'vue',
            'group' => 'frontend',
            'icon' => null,
            'sort_order' => 0,
            'translations' => ['en' => null, 'ar' => null],
        ];
    }

    public function test_every_catalog_route_requires_an_admin_session(): void
    {
        $category = $this->makeCategory(['en' => ['name' => 'Web', 'slug' => 'web']]);
        $technology = $this->makeTechnology('Laravel');
        $requests = [
            ['GET', '/api/admin/categories', []],
            ['GET', "/api/admin/categories/{$category->id}", []],
            ['POST', '/api/admin/categories', $this->category()],
            ['PUT', "/api/admin/categories/{$category->id}", $this->category()],
            ['GET', '/api/admin/technologies', []],
            ['GET', "/api/admin/technologies/{$technology->id}", []],
            ['POST', '/api/admin/technologies', $this->technology()],
            ['PUT', "/api/admin/technologies/{$technology->id}", $this->technology()],
        ];

        foreach ($requests as [$method, $uri, $body]) {
            $this->json($method, $uri, $body)->assertUnauthorized();
        }

        $this->actingAs(User::factory()->create(), 'web');
        foreach ($requests as [$method, $uri, $body]) {
            $this->json($method, $uri, $body)->assertForbidden();
        }

        $this->assertSame(1, Category::query()->count());
        $this->assertSame(1, Technology::query()->count());
        $this->assertSame('web', $category->translation('en')->slug);
    }

    public function test_there_is_no_delete_route(): void
    {
        $this->signIn();
        $category = $this->makeCategory(['en' => ['name' => 'Web', 'slug' => 'web']]);
        $technology = $this->makeTechnology('Laravel');

        $this->deleteJson("/api/admin/categories/{$category->id}")->assertStatus(405);
        $this->deleteJson("/api/admin/technologies/{$technology->id}")->assertStatus(405);
        $this->assertModelExists($category);
        $this->assertModelExists($technology);
    }

    public function test_the_category_list_shows_both_languages_and_linked_projects(): void
    {
        $this->signIn();
        $web = $this->makeCategory(['en' => ['name' => 'Web Applications', 'slug' => 'web'], 'ar' => ['name' => 'تطبيقات الويب', 'slug' => 'tatbiqat']], 1);
        $this->makeCategory(['en' => ['name' => 'Landing Pages', 'slug' => 'landing']], 2);
        $draft = $this->englishProject('draft-project', ['status' => 'draft', 'published_at' => null]);
        $draft->categories()->attach($web->id);
        $this->englishProject('published-project')->categories()->attach($web->id);

        $response = $this->getJson('/api/admin/categories')->assertOk();
        $response->assertJsonPath('meta.total', 2)->assertJsonPath('data.0.id', $web->id);
        $response->assertJsonPath('data.0.translations', [
            'en' => ['name' => 'Web Applications', 'slug' => 'web'],
            'ar' => ['name' => 'تطبيقات الويب', 'slug' => 'tatbiqat'],
        ]);
        $response->assertJsonPath('data.0.projects_count', 2)->assertJsonPath('data.0.in_use', true);
        $response->assertJsonPath('data.1.translations.ar', null)->assertJsonPath('data.1.in_use', false);

        $names = fn (string $query) => collect($this->getJson('/api/admin/categories?'.$query)->assertOk()->json('data'))->pluck('translations.en.name')->all();
        $this->assertSame(['Web Applications'], $names('q='.urlencode('تطبيقات')));
        $this->assertSame(['Landing Pages'], $names('q=landing'));
        $this->assertSame([], $names('q='.urlencode('%')));
        $this->getJson('/api/admin/categories?per_page=500')->assertStatus(422);
    }

    public function test_a_category_can_be_created_in_one_language_and_completed_later(): void
    {
        $this->signIn();

        $created = $this->postJson('/api/admin/categories', $this->category())->assertCreated();
        $id = $created->json('data.id');
        $created->assertJsonPath('data.translations.ar', null)->assertJsonPath('data.projects_count', 0);

        $this->putJson("/api/admin/categories/{$id}", $this->category([
            'sort_order' => 3,
            'translations' => [
                'en' => ['name' => 'Web Apps', 'slug' => 'web-apps'],
                'ar' => ['name' => 'تطبيقات الويب', 'slug' => 'tatbiqat-alweb'],
            ],
        ]))->assertOk()->assertJsonPath('data.sort_order', 3)->assertJsonPath('data.translations.ar.name', 'تطبيقات الويب');

        $this->assertDatabaseHas('category_translations', ['category_id' => $id, 'locale' => 'en', 'name' => 'Web Apps', 'slug' => 'web-apps']);
        $this->assertSame(2, Category::findOrFail($id)->translations()->count());
    }

    public function test_category_validation(): void
    {
        $this->signIn();
        $existing = $this->makeCategory(['en' => ['name' => 'Web', 'slug' => 'web'], 'ar' => ['name' => 'ويب', 'slug' => 'web-ar']]);

        $this->postJson('/api/admin/categories', $this->category(['translations' => ['en' => null, 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors('translations');
        $this->postJson('/api/admin/categories', $this->category(['translations' => ['en' => ['name' => 'Only a name'], 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors('translations.en.slug');
        $this->postJson('/api/admin/categories', $this->category(['translations' => ['en' => ['name' => 'Bad', 'slug' => 'Bad Slug'], 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors('translations.en.slug');
        $this->postJson('/api/admin/categories', $this->category(['translations' => ['en' => ['name' => 'Web', 'slug' => 'web'], 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations.en.name', 'translations.en.slug']);
        $this->postJson('/api/admin/categories', $this->category(['translations' => ['en' => ['name' => str_repeat('a', 81), 'slug' => 'long'], 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors('translations.en.name');
        $this->postJson('/api/admin/categories', $this->category(['sort_order' => 70000]))
            ->assertStatus(422)->assertJsonValidationErrors('sort_order');

        // The same name / slug in another language is allowed; an existing language cannot be emptied.
        $this->postJson('/api/admin/categories', $this->category(['translations' => ['en' => null, 'ar' => ['name' => 'Web', 'slug' => 'web']]]))->assertCreated();
        $this->putJson("/api/admin/categories/{$existing->id}", $this->category(['translations' => ['en' => ['name' => 'Web', 'slug' => 'web'], 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations.ar.name', 'translations.ar.slug']);
        // Saving a category with its own name and slug is not a conflict.
        $this->putJson("/api/admin/categories/{$existing->id}", $this->category(['translations' => ['en' => ['name' => 'Web', 'slug' => 'web'], 'ar' => ['name' => 'ويب', 'slug' => 'web-ar']]]))
            ->assertOk();
    }

    public function test_the_technology_list_includes_hidden_ones_with_filters(): void
    {
        $this->signIn();
        $laravel = $this->makeTechnology('Laravel');
        $laravel->translations()->create(['locale' => 'ar', 'display_name' => 'لارافيل', 'description' => null]);
        $this->makeTechnology('Old Tool', visible: false);
        Technology::create(['name' => 'React', 'slug' => 'react', 'group' => TechnologyGroup::Frontend, 'icon' => 'react', 'is_visible' => true, 'sort_order' => 0]);
        $this->englishProject('uses-laravel')->technologies()->attach($laravel->id);

        $response = $this->getJson('/api/admin/technologies')->assertOk();
        $response->assertJsonPath('meta.total', 3);
        $this->assertSame(['Laravel', 'Old Tool', 'React'], collect($response->json('data'))->pluck('name')->all());
        $response->assertJsonPath('data.0.projects_count', 1)->assertJsonPath('data.0.in_use', true);
        $response->assertJsonPath('data.0.translations.ar', ['display_name' => 'لارافيل', 'description' => null]);
        $response->assertJsonPath('data.1.is_visible', false)->assertJsonPath('data.2.icon', 'react');

        $names = fn (string $query) => collect($this->getJson('/api/admin/technologies?'.$query)->assertOk()->json('data'))->pluck('name')->all();
        $this->assertSame(['Laravel'], $names('q='.urlencode('لارافيل')));
        $this->assertSame(['React'], $names('group=frontend'));
        $this->assertSame(['Old Tool'], $names('visibility=hidden'));
        $this->getJson('/api/admin/technologies?group=mobile')->assertStatus(422);
    }

    public function test_a_new_technology_is_hidden_unless_chosen_and_the_icon_is_optional(): void
    {
        $this->signIn();

        $this->postJson('/api/admin/technologies', $this->technology())->assertCreated()
            ->assertJsonPath('data.is_visible', false)->assertJsonPath('data.icon', null)->assertJsonPath('data.translations', ['en' => null, 'ar' => null]);

        $this->postJson('/api/admin/technologies', $this->technology([
            'name' => 'Tailwind CSS', 'slug' => 'tailwind-css', 'icon' => 'simple-icons:tailwindcss', 'is_visible' => true,
            'translations' => ['en' => null, 'ar' => ['display_name' => 'تيلويند', 'description' => 'إطار CSS']],
        ]))->assertCreated()->assertJsonPath('data.is_visible', true)->assertJsonPath('data.translations.ar.display_name', 'تيلويند');
    }

    public function test_editing_a_technology_never_changes_its_visibility(): void
    {
        $this->signIn();
        $hidden = $this->makeTechnology('Old Tool', visible: false);

        $this->putJson("/api/admin/technologies/{$hidden->id}", $this->technology([
            'name' => 'Old Tool 2', 'slug' => 'old-tool-2', 'group' => 'tools', 'is_visible' => true,
        ]))->assertOk()->assertJsonPath('data.is_visible', false)->assertJsonPath('data.name', 'Old Tool 2');

        $this->assertFalse($hidden->fresh()->is_visible);
        $this->getJson('/api/technologies')->assertOk()->assertJsonMissing(['name' => 'Old Tool 2']);
    }

    public function test_technology_validation(): void
    {
        $this->signIn();
        $laravel = $this->makeTechnology('Laravel');
        Technology::query()->whereKey($laravel->id)->update(['icon' => 'legacy icon value']);

        $this->postJson('/api/admin/technologies', $this->technology(['name' => '', 'slug' => '', 'group' => 'mobile']))
            ->assertStatus(422)->assertJsonValidationErrors(['name', 'slug', 'group']);
        $this->postJson('/api/admin/technologies', $this->technology(['name' => 'Laravel', 'slug' => 'laravel']))
            ->assertStatus(422)->assertJsonValidationErrors(['name', 'slug']);
        $this->postJson('/api/admin/technologies', $this->technology(['icon' => '<svg onload=x>']))
            ->assertStatus(422)->assertJsonValidationErrors('icon');
        $this->postJson('/api/admin/technologies', $this->technology(['translations' => ['en' => ['display_name' => str_repeat('a', 61)], 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors('translations.en.display_name');

        // A stored icon is kept as it is when unchanged.
        $this->putJson("/api/admin/technologies/{$laravel->id}", $this->technology(['name' => 'Laravel', 'slug' => 'laravel', 'group' => 'backend', 'icon' => 'legacy icon value']))
            ->assertOk()->assertJsonPath('data.icon', 'legacy icon value');
    }

    public function test_clearing_translated_texts_keeps_the_row(): void
    {
        $this->signIn();
        $laravel = $this->makeTechnology('Laravel');
        $laravel->translations()->create(['locale' => 'ar', 'display_name' => 'لارافيل', 'description' => 'وصف']);

        $this->putJson("/api/admin/technologies/{$laravel->id}", $this->technology(['name' => 'Laravel', 'slug' => 'laravel', 'group' => 'backend']))
            ->assertOk()->assertJsonPath('data.translations.ar', ['display_name' => null, 'description' => null]);

        $this->assertDatabaseHas('technology_translations', ['technology_id' => $laravel->id, 'locale' => 'ar', 'display_name' => null]);
    }
}
