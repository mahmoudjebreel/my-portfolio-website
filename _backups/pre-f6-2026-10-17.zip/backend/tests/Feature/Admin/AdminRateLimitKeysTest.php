<?php

namespace Tests\Feature\Admin;

use App\Http\Requests\Admin\LoginRequest;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use ReflectionProperty;
use Tests\TestCase;

/**
 * Limiter keys and the login timebox, checked without any database access
 * (no RefreshDatabase, no queries): the keys are computed from the request only.
 */
class AdminRateLimitKeysTest extends TestCase
{
    private function key(string $limiter, string $ip): string
    {
        $limit = RateLimiter::limiter($limiter)(Request::create('/api/admin/login', 'POST', server: ['REMOTE_ADDR' => $ip]));
        $this->assertInstanceOf(Limit::class, $limit);

        return $limit->key;
    }

    public function test_ipv4_keys_are_exactly_as_before(): void
    {
        $this->assertSame('ip:203.0.113.10', $this->key('admin-login', '203.0.113.10'));
        $this->assertSame('ip:203.0.113.10', $this->key('admin', '203.0.113.10'));
        $this->assertSame(
            'admin-login:'.hash('sha256', 'owner@example.com|203.0.113.10'),
            LoginRequest::throttleKeyFor(' Owner@Example.com ', '203.0.113.10'),
        );
    }

    public function test_ipv6_clients_of_one_64_share_every_key(): void
    {
        foreach (['admin-login', 'admin'] as $limiter) {
            $this->assertSame('ip:2001:db8:1:2::/64', $this->key($limiter, '2001:db8:1:2::1'));
            $this->assertSame($this->key($limiter, '2001:db8:1:2::1'), $this->key($limiter, '2001:db8:1:2:ffff:ffff:ffff:ffff'), $limiter);
        }

        $this->assertSame(
            LoginRequest::throttleKeyFor('owner@example.com', '2001:db8:1:2::1'),
            LoginRequest::throttleKeyFor('owner@example.com', '2001:db8:1:2:dead:beef:0:1'),
        );
    }

    public function test_ipv6_clients_of_different_64s_keep_separate_keys(): void
    {
        foreach (['admin-login', 'admin'] as $limiter) {
            $this->assertNotSame($this->key($limiter, '2001:db8:1:2::1'), $this->key($limiter, '2001:db8:1:3::1'), $limiter);
        }

        $this->assertNotSame(
            LoginRequest::throttleKeyFor('owner@example.com', '2001:db8:1:2::1'),
            LoginRequest::throttleKeyFor('owner@example.com', '2001:db8:1:3::1'),
        );
        // Different emails from the same /64 are still counted separately.
        $this->assertNotSame(
            LoginRequest::throttleKeyFor('owner@example.com', '2001:db8:1:2::1'),
            LoginRequest::throttleKeyFor('other@example.com', '2001:db8:1:2::1'),
        );
    }

    public function test_the_public_api_limiter_is_unchanged(): void
    {
        // Out of scope for this change: still keyed by the full address.
        $this->assertSame('2001:db8:1:2::1', $this->key('public-api', '2001:db8:1:2::1'));
    }

    public function test_failed_logins_are_padded_to_500_ms(): void
    {
        $this->assertSame(500000, config('auth.timebox_duration'));

        $guard = Auth::guard('web');
        $this->assertSame(500000, (new ReflectionProperty($guard, 'timeboxDuration'))->getValue($guard));
    }

    public function test_the_other_auth_settings_are_untouched(): void
    {
        $this->assertSame('web', config('auth.defaults.guard'));
        $this->assertSame('session', config('auth.guards.web.driver'));
        $this->assertSame('users', config('auth.guards.web.provider'));
        $this->assertSame(10800, (int) config('auth.password_timeout'));
    }
}
