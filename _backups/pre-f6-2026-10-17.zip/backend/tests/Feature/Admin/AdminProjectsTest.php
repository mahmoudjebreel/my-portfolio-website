<?php

namespace Tests\Feature\Admin;

use App\Enums\ProjectStatus;
use App\Models\Project;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Feature\Api\Concerns\BuildsProjects;
use Tests\TestCase;

/**
 * Admin project API (A4). Test database only (TestCase guard + RefreshDatabase).
 */
class AdminProjectsTest extends TestCase
{
    use BuildsProjects;
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.debug' => false]);
    }

    private function admin(): User
    {
        return User::factory()->admin()->create();
    }

    /**
     * @return array<string, mixed>
     */
    private function content(string $slug, array $overrides = []): array
    {
        return $overrides + [
            'title' => ucfirst(str_replace('-', ' ', $slug)),
            'slug' => $slug,
            'short_description' => 'Short text',
            'description' => 'Long text',
            'problem' => null,
            'solution' => null,
            'cover_image_alt' => null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function payload(array $overrides = []): array
    {
        return $overrides + [
            'status' => 'draft',
            'is_featured' => false,
            'sort_order' => 0,
            'github_url' => null,
            'live_url' => null,
            'category_ids' => [],
            'technology_ids' => [],
            'translations' => ['en' => $this->content('portfolio-site'), 'ar' => null],
        ];
    }

    public function test_every_project_route_requires_an_admin_session(): void
    {
        $project = $this->englishProject('existing');
        $requests = [
            ['GET', '/api/admin/projects'],
            ['GET', '/api/admin/project-options'],
            ['GET', "/api/admin/projects/{$project->id}"],
            ['POST', '/api/admin/projects'],
            ['PUT', "/api/admin/projects/{$project->id}"],
            ['PATCH', "/api/admin/projects/{$project->id}/status"],
        ];

        foreach ($requests as [$method, $uri]) {
            $this->json($method, $uri, $this->payload())->assertUnauthorized();
        }

        $this->actingAs(User::factory()->create(), 'web');
        foreach ($requests as [$method, $uri]) {
            $this->json($method, $uri, $this->payload())->assertForbidden();
        }

        $this->assertSame(1, Project::query()->count());
    }

    public function test_the_list_includes_drafts_and_both_languages_with_server_pagination(): void
    {
        $this->actingAs($this->admin(), 'web');
        $this->makeProject(['en' => ['slug' => 'bilingual', 'title' => 'Bilingual'], 'ar' => ['slug' => 'thunai', 'title' => 'ثنائي']]);
        $this->makeProject(['en' => ['slug' => 'draft-one', 'title' => 'Draft one']], ['status' => ProjectStatus::Draft, 'published_at' => null]);
        foreach (range(1, 10) as $i) {
            $this->englishProject("filler-{$i}");
        }

        $first = $this->getJson('/api/admin/projects?per_page=5')->assertOk();
        $first->assertJsonPath('meta.total', 12)->assertJsonPath('meta.per_page', 5)->assertJsonPath('meta.last_page', 3)->assertJsonCount(5, 'data');

        $all = collect($this->getJson('/api/admin/projects?per_page=50')->json('data'));
        $bilingual = $all->firstWhere('title.en', 'Bilingual');
        $this->assertSame(['en' => 'Bilingual', 'ar' => 'ثنائي'], $bilingual['title']);
        $this->assertSame(['en' => true, 'ar' => true], $bilingual['complete']);
        $this->assertSame('draft', $all->firstWhere('title.en', 'Draft one')['status']);
        $this->assertSame(['en' => true, 'ar' => false], $all->firstWhere('title.en', 'Draft one')['complete']);
    }

    public function test_search_status_and_category_filters(): void
    {
        $this->actingAs($this->admin(), 'web');
        $web = $this->makeCategory(['en' => ['name' => 'Web', 'slug' => 'web']]);
        $shop = $this->makeProject(['en' => ['slug' => 'shop', 'title' => 'Online Shop'], 'ar' => ['slug' => 'matjar', 'title' => 'متجر إلكتروني']]);
        $shop->categories()->attach($web->id);
        $this->makeProject(['en' => ['slug' => 'blog', 'title' => 'Blog 100%']], ['status' => ProjectStatus::Draft, 'published_at' => null]);

        $titles = fn (string $query) => collect($this->getJson('/api/admin/projects?'.$query)->assertOk()->json('data'))->pluck('title.en')->all();

        $this->assertSame(['Online Shop'], $titles('q=shop'));
        $this->assertSame(['Online Shop'], $titles('q='.urlencode('متجر')));
        $this->assertSame(['Blog 100%'], $titles('q='.urlencode('100%')));
        // Wildcards are escaped: "%" only finds a literal percent sign, "_" a literal underscore.
        $this->assertSame(['Blog 100%'], $titles('q='.urlencode('%')));
        $this->assertSame([], $titles('q='.urlencode('_')));
        $this->assertSame(['Blog 100%'], $titles('status=draft'));
        $this->assertSame(['Online Shop'], $titles("category={$web->id}"));
        $this->getJson('/api/admin/projects?status=archived')->assertStatus(422);
    }

    public function test_a_draft_can_be_saved_with_one_language(): void
    {
        $this->actingAs($this->admin(), 'web');
        $web = $this->makeCategory(['en' => ['name' => 'Web', 'slug' => 'web']]);
        $laravel = $this->makeTechnology('Laravel');

        $response = $this->postJson('/api/admin/projects', $this->payload([
            'category_ids' => [$web->id],
            'technology_ids' => [$laravel->id],
            'github_url' => 'https://github.com/example/site',
        ]))->assertCreated();

        $response->assertJsonPath('data.status', 'draft')
            ->assertJsonPath('data.translations.en.slug', 'portfolio-site')
            ->assertJsonPath('data.translations.ar', null)
            ->assertJsonPath('data.complete', ['en' => true, 'ar' => false])
            ->assertJsonPath('data.category_ids', [$web->id])
            ->assertJsonPath('data.technology_ids', [$laravel->id]);

        $project = Project::query()->sole();
        $this->assertNull($project->published_at);
        $this->assertSame(1, $project->translations()->count());
    }

    public function test_a_draft_needs_at_least_one_complete_language(): void
    {
        $this->actingAs($this->admin(), 'web');

        $this->postJson('/api/admin/projects', $this->payload(['translations' => ['en' => null, 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations']);

        // A partly filled language must be complete.
        $this->postJson('/api/admin/projects', $this->payload(['translations' => ['en' => ['title' => 'Only a title']]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations.en.slug', 'translations.en.short_description', 'translations.en.description']);

        $this->assertSame(0, Project::query()->count());
    }

    public function test_publishing_requires_complete_english_and_arabic_content(): void
    {
        $this->actingAs($this->admin(), 'web');

        $this->postJson('/api/admin/projects', $this->payload(['status' => 'published']))
            ->assertStatus(422)
            ->assertJsonValidationErrors(['status', 'translations.ar.title', 'translations.ar.slug', 'translations.ar.short_description', 'translations.ar.description']);
        $this->assertSame(0, Project::query()->count());

        $this->postJson('/api/admin/projects', $this->payload([
            'status' => 'published',
            'translations' => ['en' => $this->content('portfolio-site'), 'ar' => $this->content('mawqi-shakhsi', ['title' => 'موقع شخصي'])],
        ]))->assertCreated()->assertJsonPath('data.status', 'published');

        $this->assertNotNull(Project::query()->sole()->published_at);
        // Visible on the public API in both languages.
        $this->getJson('/api/projects/mawqi-shakhsi?locale=ar')->assertOk();
    }

    public function test_slugs_are_validated_and_unique_per_language(): void
    {
        $this->actingAs($this->admin(), 'web');
        $this->englishProject('taken');

        $this->postJson('/api/admin/projects', $this->payload(['translations' => ['en' => $this->content('taken')]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations.en.slug']);
        $this->postJson('/api/admin/projects', $this->payload(['translations' => ['en' => $this->content('Not_Valid')]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations.en.slug']);
        // The same slug is fine in another language.
        $this->postJson('/api/admin/projects', $this->payload(['translations' => ['en' => null, 'ar' => $this->content('taken', ['title' => 'مأخوذ'])]]))
            ->assertCreated();
    }

    public function test_untrusted_fields_are_ignored_and_references_must_exist(): void
    {
        $this->actingAs($this->admin(), 'web');

        $this->postJson('/api/admin/projects', $this->payload([
            'cover_image_path' => '../../.env',
            'published_at' => '2000-01-01',
            'id' => 999,
        ]))->assertCreated();
        $project = Project::query()->sole();
        $this->assertNull($project->cover_image_path);
        $this->assertNull($project->published_at);
        $this->assertNotSame(999, $project->id);

        $this->postJson('/api/admin/projects', $this->payload(['category_ids' => [123456], 'technology_ids' => [654321]]))
            ->assertStatus(422)->assertJsonValidationErrors(['category_ids.0', 'technology_ids.0']);
        $this->postJson('/api/admin/projects', $this->payload(['live_url' => 'javascript:alert(1)']))
            ->assertStatus(422)->assertJsonValidationErrors(['live_url']);
    }

    public function test_update_keeps_slugs_valid_and_never_empties_an_existing_language(): void
    {
        $this->actingAs($this->admin(), 'web');
        $project = $this->makeProject(['en' => ['slug' => 'site', 'title' => 'Site'], 'ar' => ['slug' => 'mawqi', 'title' => 'موقع']]);

        $this->putJson("/api/admin/projects/{$project->id}", $this->payload([
            'status' => 'published',
            'translations' => ['en' => $this->content('site', ['title' => 'Site v2']), 'ar' => $this->content('mawqi', ['title' => 'موقع 2'])],
        ]))->assertOk()->assertJsonPath('data.translations.en.title', 'Site v2');

        $this->putJson("/api/admin/projects/{$project->id}", $this->payload(['translations' => ['en' => $this->content('site'), 'ar' => null]]))
            ->assertStatus(422)->assertJsonValidationErrors(['translations.ar.title']);
        $this->assertSame(2, $project->translations()->count());

        $this->putJson('/api/admin/projects/999999', $this->payload())->assertNotFound();
    }

    public function test_status_change_refuses_to_publish_incomplete_content(): void
    {
        $this->actingAs($this->admin(), 'web');
        $draft = $this->makeProject(['en' => ['slug' => 'draft']], ['status' => ProjectStatus::Draft, 'published_at' => null]);

        $this->patchJson("/api/admin/projects/{$draft->id}/status", ['status' => 'published'])
            ->assertStatus(422)->assertJsonValidationErrors(['status', 'translations.ar']);
        $this->assertSame(ProjectStatus::Draft, $draft->fresh()->status);

        $draft->translations()->create(['locale' => 'ar', 'slug' => 'musawwada', 'title' => 'مسودة', 'short_description' => 'قصير', 'description' => 'طويل']);
        $this->patchJson("/api/admin/projects/{$draft->id}/status", ['status' => 'published'])->assertOk()->assertJsonPath('data.status', 'published');
        $publishedAt = $draft->fresh()->published_at;
        $this->assertNotNull($publishedAt);

        $this->patchJson("/api/admin/projects/{$draft->id}/status", ['status' => 'draft'])->assertOk()->assertJsonPath('data.status', 'draft');
        $this->assertEquals($publishedAt, $draft->fresh()->published_at); // first publication date kept
        $this->patchJson("/api/admin/projects/{$draft->id}/status", ['status' => 'archived'])->assertStatus(422);
    }

    public function test_options_list_categories_in_both_languages_and_every_technology(): void
    {
        $this->actingAs($this->admin(), 'web');
        $this->makeCategory(['en' => ['name' => 'Web', 'slug' => 'web'], 'ar' => ['name' => 'ويب', 'slug' => 'wib']]);
        $this->makeTechnology('Laravel');
        $this->makeTechnology('Hidden Tool', visible: false);

        $response = $this->getJson('/api/admin/project-options')
            ->assertOk()
            ->assertJsonPath('data.categories.0.name', ['en' => 'Web', 'ar' => 'ويب'])
            ->assertJsonCount(2, 'data.technologies');

        // Ordered by sort order, then name.
        $technologies = collect($response->json('data.technologies'))->keyBy('name');
        $this->assertSame(['Hidden Tool', 'Laravel'], collect($response->json('data.technologies'))->pluck('name')->all());
        $this->assertFalse($technologies['Hidden Tool']['is_visible']);
        $this->assertTrue($technologies['Laravel']['is_visible']);
    }

    public function test_there_is_no_delete_route(): void
    {
        $this->actingAs($this->admin(), 'web');
        $project = $this->englishProject('kept');

        $this->deleteJson("/api/admin/projects/{$project->id}")->assertStatus(405);
        $this->assertModelExists($project);
    }
}
