<?php

namespace Tests\Feature\Admin;

use Illuminate\Contracts\Http\Kernel as HttpKernel;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Feature\Admin\Concerns\InteractsWithAdminSession;
use Tests\Feature\Admin\Concerns\StrictPreventRequestForgery;
use Tests\TestCase;

/**
 * Real CSRF checks. Laravel's PreventRequestForgery skips verification whenever
 * PHPUnit is running (runningUnitTests()), so these tests swap in a subclass that
 * only disables that skip. The router resolves middleware from the container,
 * so every admin request below goes through the real verification logic.
 */
class AdminCsrfTest extends TestCase
{
    use InteractsWithAdminSession;
    use RefreshDatabase;

    private const PASSWORD = 'correct horse battery staple';

    protected function setUp(): void
    {
        parent::setUp();
        $this->app->bind(PreventRequestForgery::class, StrictPreventRequestForgery::class);
    }

    public function test_by_default_feature_tests_skip_csrf_which_is_why_this_file_exists(): void
    {
        $this->app->offsetUnset(PreventRequestForgery::class); // back to the framework class
        $admin = $this->admin();

        // No token, no Origin information: still accepted under PHPUnit.
        $this->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD])->assertOk();
    }

    public function test_the_web_group_contains_the_csrf_middleware_and_no_path_is_excluded(): void
    {
        $this->assertContains(PreventRequestForgery::class, $this->app->make(HttpKernel::class)->getMiddlewareGroups()['web']);
        $this->assertSame([], $this->app->make(PreventRequestForgery::class)->getExcludedPaths());
    }

    public function test_login_without_any_token_is_rejected(): void
    {
        $admin = $this->admin();

        $this->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD])
            ->assertStatus(419)
            ->assertExactJson(['message' => 'CSRF token mismatch.']);
        $this->assertGuest('web');
    }

    public function test_a_cross_site_request_without_a_token_is_rejected(): void
    {
        $admin = $this->admin();

        $this->withHeader('Sec-Fetch-Site', 'cross-site')
            ->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD])
            ->assertStatus(419);

        // "same-site" (another subdomain) is not trusted either (allowSameSite is off).
        $this->withHeader('Sec-Fetch-Site', 'same-site')
            ->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD])
            ->assertStatus(419);
    }

    public function test_invalid_tokens_are_rejected(): void
    {
        $admin = $this->admin();
        $this->keepCookies($this->sameBrowser()->getJson('/api/admin/csrf-cookie'));
        $credentials = ['email' => $admin->email, 'password' => self::PASSWORD];

        $this->sameBrowser()->withHeader('X-XSRF-TOKEN', 'not-an-encrypted-value')->postJson('/api/admin/login', $credentials)->assertStatus(419);
        $this->sameBrowser()->withHeader('X-XSRF-TOKEN', encrypt('forged-token', false))->postJson('/api/admin/login', $credentials)->assertStatus(419);
        $this->sameBrowser()->withHeader('X-CSRF-TOKEN', 'forged-token')->postJson('/api/admin/login', $credentials)->assertStatus(419);
        $this->sameBrowser()->postJson('/api/admin/login', $credentials + ['_token' => 'forged-token'])->assertStatus(419);

        // A valid token from ANOTHER session does not work either.
        $other = $this->otherBrowser()->getJson('/api/admin/csrf-cookie');
        $otherXsrf = $other->getCookie('XSRF-TOKEN', decrypt: false)->getValue();
        $this->sameBrowser()->withHeader('X-XSRF-TOKEN', $otherXsrf)->postJson('/api/admin/login', $credentials)->assertStatus(419);

        $this->assertGuest('web');
    }

    public function test_the_spa_flow_with_the_xsrf_cookie_succeeds(): void
    {
        $admin = $this->admin();

        // 1. GET csrf-cookie  2. send the XSRF-TOKEN cookie value back in X-XSRF-TOKEN.
        $this->signIn($admin)->assertOk();
        $this->sameBrowser()->getJson('/api/admin/me')->assertOk();
    }

    public function test_a_same_origin_browser_request_is_accepted_without_a_token(): void
    {
        // Laravel 13 behaviour: browsers send Sec-Fetch-Site (scripts cannot set it), and
        // "same-origin" proves the request comes from the site itself.
        $admin = $this->admin();

        $this->withHeader('Sec-Fetch-Site', 'same-origin')
            ->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD])
            ->assertOk();
    }

    public function test_logout_requires_a_token_and_the_old_token_dies_with_the_session(): void
    {
        $admin = $this->admin();
        $this->signIn($admin)->assertOk();
        $signedInToken = $this->xsrfCookie;

        $this->sameBrowser()->postJson('/api/admin/logout')->assertStatus(419);
        $this->sameBrowser()->getJson('/api/admin/me')->assertOk(); // still signed in

        $this->keepCookies(
            $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $signedInToken)->postJson('/api/admin/logout'),
        )->assertNoContent();

        // The token of the destroyed session is no longer accepted.
        $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $signedInToken)
            ->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD])
            ->assertStatus(419);
    }

    public function test_the_pre_login_token_is_not_valid_after_sign_in(): void
    {
        $admin = $this->admin();
        $this->keepCookies($this->sameBrowser()->getJson('/api/admin/csrf-cookie'));
        $preLoginToken = $this->xsrfCookie;

        $this->keepCookies(
            $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $preLoginToken)
                ->postJson('/api/admin/login', ['email' => $admin->email, 'password' => self::PASSWORD]),
        )->assertOk();

        $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $preLoginToken)->postJson('/api/admin/logout')->assertStatus(419);
        $this->sameBrowser()->withHeader('X-XSRF-TOKEN', (string) $this->xsrfCookie)->postJson('/api/admin/logout')->assertNoContent();
    }

    public function test_reading_requests_need_no_token(): void
    {
        $this->getJson('/api/admin/csrf-cookie')->assertNoContent();
        $this->getJson('/api/admin/me')->assertUnauthorized(); // auth decides, not CSRF
    }
}
