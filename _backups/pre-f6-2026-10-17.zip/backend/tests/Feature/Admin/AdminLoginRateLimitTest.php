<?php

namespace Tests\Feature\Admin;

use App\Http\Requests\Admin\LoginRequest;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Feature\Admin\Concerns\InteractsWithAdminSession;
use Tests\TestCase;

/**
 * phpunit.xml sets CACHE_STORE=array: limiter counters live in memory for one
 * test only and are never written to a database.
 */
class AdminLoginRateLimitTest extends TestCase
{
    use InteractsWithAdminSession;
    use RefreshDatabase;

    private const PASSWORD = 'correct horse battery staple';

    private function attempt(string $email, string $password, string $ip = '203.0.113.10')
    {
        return $this->otherBrowser()
            ->withServerVariables(['REMOTE_ADDR' => $ip])
            ->postJson('/api/admin/login', ['email' => $email, 'password' => $password]);
    }

    public function test_the_cache_used_by_the_limiter_is_in_memory(): void
    {
        $this->assertSame('array', config('cache.default'));
    }

    public function test_five_failures_lock_the_email_and_ip_pair_with_429(): void
    {
        $admin = $this->admin();

        for ($i = 1; $i <= LoginRequest::MAX_ATTEMPTS; $i++) {
            $this->attempt($admin->email, "wrong password {$i}")->assertStatus(422);
        }

        // Locked: even the correct password is refused now.
        $locked = $this->attempt($admin->email, self::PASSWORD)
            ->assertStatus(429)
            ->assertJsonPath('message', 'Too many login attempts. Please try again later.');
        $this->assertGreaterThan(0, (int) $locked->headers->get('Retry-After'));
        $this->assertLessThanOrEqual(LoginRequest::DECAY_SECONDS, (int) $locked->headers->get('Retry-After'));
        $this->assertGuest('web');

        // The email is matched case-insensitively, so changing its case does not help.
        $this->attempt(strtoupper($admin->email), self::PASSWORD)->assertStatus(429);
    }

    public function test_the_lock_expires_after_the_decay_time(): void
    {
        $admin = $this->admin();
        for ($i = 1; $i <= LoginRequest::MAX_ATTEMPTS; $i++) {
            $this->attempt($admin->email, 'wrong password!');
        }
        $this->attempt($admin->email, self::PASSWORD)->assertStatus(429);

        $this->travel(LoginRequest::DECAY_SECONDS + 1)->seconds();

        $this->attempt($admin->email, self::PASSWORD)->assertOk();
    }

    public function test_the_lock_is_per_email_and_ip(): void
    {
        $admin = $this->admin();
        for ($i = 1; $i <= LoginRequest::MAX_ATTEMPTS; $i++) {
            $this->attempt($admin->email, 'wrong password!', '203.0.113.10');
        }

        $this->attempt($admin->email, self::PASSWORD, '203.0.113.10')->assertStatus(429);
        // The real owner on another network is not locked out by an attacker's failures.
        $this->attempt($admin->email, self::PASSWORD, '198.51.100.20')->assertOk();
    }

    public function test_a_successful_sign_in_resets_the_failure_count(): void
    {
        $admin = $this->admin();
        for ($i = 1; $i < LoginRequest::MAX_ATTEMPTS; $i++) {
            $this->attempt($admin->email, 'wrong password!');
        }
        $this->attempt($admin->email, self::PASSWORD)->assertOk();

        for ($i = 1; $i < LoginRequest::MAX_ATTEMPTS; $i++) {
            $this->attempt($admin->email, 'wrong password!')->assertStatus(422);
        }
    }

    public function test_one_ip_cannot_spray_many_accounts(): void
    {
        // 20 login requests per minute per IP, whatever the email.
        for ($i = 1; $i <= 20; $i++) {
            $this->attempt("user{$i}@example.com", 'wrong password!', '192.0.2.50')->assertStatus(422);
        }

        $this->attempt('user21@example.com', 'wrong password!', '192.0.2.50')->assertStatus(429);
        $this->attempt('user21@example.com', 'wrong password!', '192.0.2.51')->assertStatus(422);
    }

    public function test_rotating_ipv6_addresses_inside_one_64_does_not_escape_the_lock(): void
    {
        $admin = $this->admin();

        for ($i = 1; $i <= LoginRequest::MAX_ATTEMPTS; $i++) {
            $this->attempt($admin->email, 'wrong password!', "2001:db8:1:2::{$i}")->assertStatus(422);
        }

        $this->attempt($admin->email, self::PASSWORD, '2001:db8:1:2:ffff:ffff:ffff:ffff')->assertStatus(429);
        // Another /64 is another network: not locked.
        $this->attempt($admin->email, self::PASSWORD, '2001:db8:1:3::1')->assertOk();
    }

    public function test_one_ipv6_64_cannot_spray_many_accounts(): void
    {
        for ($i = 1; $i <= 20; $i++) {
            $this->attempt("user{$i}@example.com", 'wrong password!', "2001:db8:aa:bb::{$i}")->assertStatus(422);
        }

        $this->attempt('user21@example.com', 'wrong password!', '2001:db8:aa:bb::ffff')->assertStatus(429);
        $this->attempt('user21@example.com', 'wrong password!', '2001:db8:aa:bc::1')->assertStatus(422);
    }
}
