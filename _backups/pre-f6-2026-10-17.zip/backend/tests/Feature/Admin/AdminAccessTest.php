<?php

namespace Tests\Feature\Admin;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Routing\Route as RoutingRoute;
use Illuminate\Support\Facades\Route;
use Tests\Feature\Admin\Concerns\InteractsWithAdminSession;
use Tests\TestCase;

class AdminAccessTest extends TestCase
{
    use InteractsWithAdminSession;
    use RefreshDatabase;

    public function test_a_guest_cannot_reach_the_protected_admin_route(): void
    {
        $this->getJson('/api/admin/me')->assertUnauthorized();
    }

    public function test_a_signed_in_regular_user_gets_403(): void
    {
        $this->actingAs($this->regularUser(), 'web')
            ->getJson('/api/admin/me')
            ->assertForbidden()
            ->assertExactJson(['message' => 'Forbidden.']);
    }

    public function test_an_admin_reaches_the_protected_route(): void
    {
        $admin = $this->admin();

        $this->actingAs($admin, 'web')
            ->getJson('/api/admin/me')
            ->assertOk()
            ->assertExactJson(['data' => ['id' => $admin->id, 'name' => $admin->name, 'email' => $admin->email]]);
    }

    public function test_is_admin_sent_by_the_client_grants_nothing(): void
    {
        $user = $this->regularUser();

        // In the login payload, with the correct password: still rejected, still not an admin.
        $this->postJson('/api/admin/login', [
            'email' => $user->email,
            'password' => 'correct horse battery staple',
            'is_admin' => true,
        ])->assertStatus(422);
        $this->assertGuest('web');
        $this->assertFalse($user->fresh()->is_admin);

        // In the query string, body or headers of a protected request.
        $this->actingAs($user, 'web')
            ->withHeader('X-Is-Admin', '1')
            ->json('GET', '/api/admin/me?is_admin=1', ['is_admin' => true])
            ->assertForbidden();
    }

    public function test_is_admin_cannot_be_mass_assigned(): void
    {
        $user = $this->regularUser();

        $user->update(['is_admin' => true]);
        $user->fill(['is_admin' => true])->save();
        User::query()->whereKey($user->id)->first()->update(['is_admin' => true]);

        $this->assertFalse($user->fresh()->is_admin);
    }

    public function test_access_is_checked_against_the_database_on_every_request(): void
    {
        $admin = $this->admin();
        $this->signIn($admin)->assertOk();
        $this->sameBrowser()->getJson('/api/admin/me')->assertOk();

        // Demoted while signed in: the very next request is refused.
        $admin->forceFill(['is_admin' => false])->save();
        $this->sameBrowser()->getJson('/api/admin/me')->assertForbidden();

        // Deleted while signed in: the session no longer resolves to a user.
        $admin->delete();
        $this->sameBrowser()->getJson('/api/admin/me')->assertUnauthorized();
    }

    public function test_every_admin_route_runs_in_the_web_group_and_protected_ones_require_admin(): void
    {
        $adminRoutes = collect(Route::getRoutes()->getRoutes())
            ->filter(fn (RoutingRoute $route) => str_starts_with($route->uri(), 'api/admin'));

        $this->assertEqualsCanonicalizing(
            [
                'admin.csrf-cookie', 'admin.login', 'admin.logout', 'admin.me',
                'admin.project-options', 'admin.projects.index', 'admin.projects.store',
                'admin.projects.show', 'admin.projects.update', 'admin.projects.status',
                'admin.categories.index', 'admin.categories.store', 'admin.categories.show', 'admin.categories.update',
                'admin.technologies.index', 'admin.technologies.store', 'admin.technologies.show', 'admin.technologies.update',
                'admin.media.index', 'admin.media.store', 'admin.media.show', 'admin.media.preview', 'admin.site-settings.show', 'admin.site-settings.update',
                'admin.messages.index', 'admin.messages.show', 'admin.messages.status',
            ],
            $adminRoutes->map->getName()->values()->all(),
        );

        foreach ($adminRoutes as $route) {
            $this->assertContains('web', $route->gatherMiddleware(), $route->getName().' must use the web group');
            $this->assertStringStartsWith('admin.', (string) $route->getName());
        }

        $protected = [
            'admin.me', 'admin.project-options', 'admin.projects.index', 'admin.projects.store', 'admin.projects.show', 'admin.projects.update', 'admin.projects.status',
            'admin.categories.index', 'admin.categories.store', 'admin.categories.show', 'admin.categories.update',
            'admin.technologies.index', 'admin.technologies.store', 'admin.technologies.show', 'admin.technologies.update',
            'admin.media.index', 'admin.media.store', 'admin.media.show', 'admin.media.preview', 'admin.site-settings.show', 'admin.site-settings.update',
            'admin.messages.index', 'admin.messages.show', 'admin.messages.status',
        ];
        foreach ($protected as $name) {
            $this->assertContains('admin', Route::getRoutes()->getByName($name)->gatherMiddleware(), $name);
        }
        $this->assertNotContains('admin', Route::getRoutes()->getByName('admin.login')->gatherMiddleware());
    }

    public function test_the_public_api_is_unchanged_and_still_read_only(): void
    {
        $this->getJson('/api/projects')->assertOk();
        $this->postJson('/api/projects')->assertStatus(405);
        $this->assertNotContains('web', Route::getRoutes()->getByName('api.projects.index')->gatherMiddleware());
    }
}
