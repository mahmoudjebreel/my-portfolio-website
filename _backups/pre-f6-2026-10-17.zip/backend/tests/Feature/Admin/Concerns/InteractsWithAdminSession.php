<?php

namespace Tests\Feature\Admin\Concerns;

use App\Models\User;
use Illuminate\Testing\TestResponse;

/**
 * Makes consecutive test requests behave like one browser: the session cookie
 * (and the XSRF-TOKEN cookie) from a response are sent with the next request,
 * and the in-memory auth guard is reset so authentication is read from the
 * session again, exactly as in a new HTTP request.
 */
trait InteractsWithAdminSession
{
    protected ?string $sessionId = null;

    /**
     * Runs automatically (Laravel calls setUp{TraitName}). Error bodies as in production:
     * the local .env has APP_DEBUG=true, which would add exception traces.
     */
    protected function setUpInteractsWithAdminSession(): void
    {
        config(['app.debug' => false]);
    }

    /** Raw (encrypted) XSRF-TOKEN cookie value, as the browser stores it. */
    protected ?string $xsrfCookie = null;

    protected function admin(array $attributes = []): User
    {
        return User::factory()->admin()->create(['password' => 'correct horse battery staple'] + $attributes);
    }

    protected function regularUser(array $attributes = []): User
    {
        return User::factory()->create(['password' => 'correct horse battery staple'] + $attributes);
    }

    protected function keepCookies(TestResponse $response): TestResponse
    {
        $session = $response->getCookie(config('session.cookie'));
        if ($session !== null) {
            $this->sessionId = $session->getValue();
        }

        $xsrf = $response->getCookie('XSRF-TOKEN', decrypt: false);
        if ($xsrf !== null) {
            $this->xsrfCookie = $xsrf->getValue();
        }

        return $response;
    }

    /**
     * Prepares the next request as a new HTTP request from the same browser: only the
     * session cookie is carried over. Headers and cookies set with withHeader() /
     * withCookie() otherwise persist for every later request of the test, which could
     * silently re-send an old CSRF token, so they are cleared first.
     */
    protected function sameBrowser(?string $sessionId = null): static
    {
        $this->resetClient();
        $this->withCredentials();

        $sessionId ??= $this->sessionId;
        if ($sessionId !== null) {
            $this->withCookie(config('session.cookie'), $sessionId);
        }

        return $this;
    }

    /** A different browser: no cookies at all. */
    protected function otherBrowser(): static
    {
        $this->resetClient();

        return $this;
    }

    private function resetClient(): void
    {
        // In a test, every request reuses the same session Store object, and Store::start()
        // merges what it reads from the handler INTO the attributes left by the previous
        // request (array_replace). Without this flush a destroyed or foreign session would
        // still look signed in. Real HTTP requests always start from an empty Store.
        $this->app['session']->driver()->flush();
        $this->app['auth']->forgetGuards();
        $this->flushHeaders();
        $this->defaultCookies = [];
        $this->unencryptedCookies = [];
        $this->withCredentials = false;
    }

    protected function signIn(User $user, string $password = 'correct horse battery staple'): TestResponse
    {
        $this->keepCookies($this->sameBrowser()->getJson('/api/admin/csrf-cookie'));

        return $this->keepCookies(
            $this->sameBrowser()
                ->withHeader('X-XSRF-TOKEN', (string) $this->xsrfCookie)
                ->postJson('/api/admin/login', ['email' => $user->email, 'password' => $password]),
        );
    }
}
