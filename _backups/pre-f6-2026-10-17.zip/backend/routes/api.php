<?php

use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ProjectController;
use App\Http\Controllers\Api\SiteSettingsController;
use App\Http\Controllers\Api\TechnologyController;
use Illuminate\Support\Facades\Route;

/*
| Public, read-only API (GET only). The "api" middleware group is stateless
| (no session, no cookies). Rate limiting is applied once, here, with the
| dedicated "public-api" limiter defined in AppServiceProvider.
*/

Route::middleware('throttle:public-api')->name('api.')->group(function () {
    Route::get('site-settings', SiteSettingsController::class)->name('site-settings');
    Route::get('technologies', [TechnologyController::class, 'index'])->name('technologies.index');
    Route::get('categories', [CategoryController::class, 'index'])->name('categories.index');
    Route::get('projects', [ProjectController::class, 'index'])->name('projects.index');
    // Malformed slugs never reach the controller: they fall through to the generic 404.
    Route::get('projects/{slug}', [ProjectController::class, 'show'])
        ->where('slug', '[a-z0-9]+(?:-[a-z0-9]+)*')
        ->name('projects.show');
});
