<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\MediaController;
use App\Http\Controllers\Admin\MessageController;
use App\Http\Controllers\Admin\ProjectController;
use App\Http\Controllers\Admin\ProjectOptionsController;
use App\Http\Controllers\Admin\SiteSettingsController;
use App\Http\Controllers\Admin\TechnologyController;
use Illuminate\Support\Facades\Route;

/*
| Admin API (session based). Registered in bootstrap/app.php with the "web"
| middleware group under the "api/admin" prefix: cookies, sessions and CSRF
| protection (PreventRequestForgery) apply to every route here. The SPA is
| served from the same origin (Vite proxy in development, one domain in
| production), so no CORS or token authentication is involved.
|
| Every state-changing request must come from the same origin (Sec-Fetch-Site)
| or carry the X-XSRF-TOKEN header copied from the XSRF-TOKEN cookie.
*/

Route::middleware(['throttle:admin', 'cache.headers:no_store;private'])->group(function () {
    // Issues the XSRF-TOKEN cookie (done by the web group on every response).
    Route::get('csrf-cookie', [AuthController::class, 'csrfCookie'])->name('csrf-cookie');

    Route::post('login', [AuthController::class, 'login'])
        ->middleware('throttle:admin-login')
        ->name('login');

    Route::post('logout', [AuthController::class, 'logout'])->name('logout');

    // Everything below requires an authenticated administrator (401 / 403 otherwise).
    Route::middleware('admin')->group(function () {
        Route::get('me', [AuthController::class, 'me'])->name('me');

        // Projects (A4): list, details, create, update, publish/unpublish. No delete.
        Route::get('project-options', ProjectOptionsController::class)->name('project-options');
        Route::get('projects', [ProjectController::class, 'index'])->name('projects.index');
        Route::post('projects', [ProjectController::class, 'store'])->name('projects.store');
        Route::get('projects/{project}', [ProjectController::class, 'show'])->whereNumber('project')->name('projects.show');
        Route::put('projects/{project}', [ProjectController::class, 'update'])->whereNumber('project')->name('projects.update');
        Route::patch('projects/{project}/status', [ProjectController::class, 'updateStatus'])->whereNumber('project')->name('projects.status');

        // Categories and technologies (A5): list, details, create, update. No delete.
        Route::get('categories', [CategoryController::class, 'index'])->name('categories.index');
        Route::post('categories', [CategoryController::class, 'store'])->name('categories.store');
        Route::get('categories/{category}', [CategoryController::class, 'show'])->whereNumber('category')->name('categories.show');
        Route::put('categories/{category}', [CategoryController::class, 'update'])->whereNumber('category')->name('categories.update');
        Route::get('technologies', [TechnologyController::class, 'index'])->name('technologies.index');
        Route::post('technologies', [TechnologyController::class, 'store'])->name('technologies.store');
        Route::get('technologies/{technology}', [TechnologyController::class, 'show'])->whereNumber('technology')->name('technologies.show');
        Route::put('technologies/{technology}', [TechnologyController::class, 'update'])->whereNumber('technology')->name('technologies.update');

        // Media and site settings (A6): list, preview, gallery upload; read / save settings.
        // No delete, detach or replace of any file.
        Route::get('media', [MediaController::class, 'index'])->name('media.index');
        Route::post('media', [MediaController::class, 'store'])->name('media.store');
        Route::get('media/{kind}/{id}', [MediaController::class, 'show'])->whereIn('kind', ['cover', 'gallery'])->whereNumber('id')->name('media.show');
        Route::get('media/{kind}/{id}/preview', [MediaController::class, 'preview'])->whereIn('kind', ['cover', 'gallery'])->whereNumber('id')->name('media.preview');
        Route::get('site-settings', [SiteSettingsController::class, 'show'])->name('site-settings.show');
        Route::put('site-settings', [SiteSettingsController::class, 'update'])->name('site-settings.update');

        // Contact inbox (A7): list, read, mark read / unread. No delete, no email sending.
        Route::get('messages', [MessageController::class, 'index'])->name('messages.index');
        Route::get('messages/{message}', [MessageController::class, 'show'])->whereNumber('message')->name('messages.show');
        Route::patch('messages/{message}/status', [MessageController::class, 'updateStatus'])->whereNumber('message')->name('messages.status');
    });
});
