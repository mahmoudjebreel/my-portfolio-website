<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

/**
 * Server-side gate for the admin API: the session must belong to a user whose
 * `is_admin` column is true. The flag is read from the database record of the
 * session user only; nothing sent by the client is taken into account.
 *
 * No session (or an expired one) → 401. Signed in but not an admin → 403.
 */
class EnsureUserIsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user('web');

        if ($user === null) {
            throw new AuthenticationException('Unauthenticated.', ['web']);
        }

        if ($user->is_admin !== true) {
            throw new AccessDeniedHttpException('Forbidden.');
        }

        return $next($request);
    }
}
