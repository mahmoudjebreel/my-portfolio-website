<?php

namespace App\Http\Resources\Admin;

use App\Models\Project;
use App\Support\ProjectContent;
use App\Support\PublicFile;
use Illuminate\Http\Request;

/**
 * Everything the edit form needs. Images are read-only in this phase (cover URL and the
 * number of gallery images are shown, nothing can be uploaded or deleted).
 *
 * @mixin Project
 */
class AdminProjectDetailResource extends AdminProjectResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $byLocale = $this->contentByLocale();
        $coverUrl = PublicFile::url($this->cover_image_path);

        return [
            'id' => $this->id,
            'status' => $this->status->value,
            'is_featured' => (bool) $this->is_featured,
            'sort_order' => (int) $this->sort_order,
            'github_url' => $this->github_url,
            'live_url' => $this->live_url,
            'translations' => $byLocale,
            'complete' => array_map(fn (?array $content) => ProjectContent::isComplete($content), $byLocale),
            'category_ids' => $this->categories->pluck('id')->values(),
            'technology_ids' => $this->technologies->pluck('id')->values(),
            'cover' => $coverUrl === null ? null : ['url' => $coverUrl],
            'images_count' => (int) ($this->images_count ?? $this->images()->count()),
            'updated_at' => $this->updated_at?->toIso8601ZuluString(),
            'published_at' => $this->published_at?->toIso8601ZuluString(),
        ];
    }
}
