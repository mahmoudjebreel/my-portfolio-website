<?php

namespace App\Http\Resources\Admin;

use App\Enums\Locale;
use App\Http\Requests\Admin\TechnologyRequest;
use App\Models\Technology;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Admin shape of a technology: hidden ones included, optional translated display name and
 * description per language, and the number of linked projects (all statuses).
 * Expects `translations` to be eager loaded and `projects_count` (withCount).
 *
 * `in_use`: linked to at least one project. There is no delete action; any future one must
 * refuse a technology while it is in use.
 *
 * @mixin Technology
 */
class AdminTechnologyResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $translations = [];
        foreach (Locale::cases() as $locale) {
            $translation = $this->translations->first(fn ($t) => $t->locale === $locale);
            $translations[$locale->value] = $translation?->only(TechnologyRequest::TRANSLATION_FIELDS);
        }
        $projects = (int) $this->projects_count;

        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'group' => $this->group->value,
            'icon' => $this->icon,
            'is_visible' => (bool) $this->is_visible,
            'sort_order' => (int) $this->sort_order,
            'translations' => $translations,
            'projects_count' => $projects,
            'in_use' => $projects > 0,
            'updated_at' => $this->updated_at?->toIso8601ZuluString(),
        ];
    }
}
