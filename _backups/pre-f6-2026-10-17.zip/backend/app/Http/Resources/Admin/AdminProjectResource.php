<?php

namespace App\Http\Resources\Admin;

use App\Enums\Locale;
use App\Models\CategoryTranslation;
use App\Models\Project;
use App\Support\ProjectContent;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Collection;

/**
 * Admin list item: drafts included, both languages side by side.
 * Expects `translations` and `categories.translations` to be eager loaded (all languages).
 *
 * @mixin Project
 */
class AdminProjectResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $byLocale = $this->contentByLocale();

        return [
            'id' => $this->id,
            'status' => $this->status->value,
            'is_featured' => (bool) $this->is_featured,
            'sort_order' => (int) $this->sort_order,
            'title' => array_map(fn (?array $content) => $content['title'] ?? null, $byLocale),
            'complete' => array_map(fn (?array $content) => ProjectContent::isComplete($content), $byLocale),
            'categories' => $this->categories->map(fn ($category) => [
                'id' => $category->id,
                'name' => $this->namesByLocale($category->translations),
            ])->values(),
            'updated_at' => $this->updated_at?->toIso8601ZuluString(),
            'published_at' => $this->published_at?->toIso8601ZuluString(),
        ];
    }

    /**
     * @return array<string, array<string, mixed>|null>
     */
    protected function contentByLocale(): array
    {
        $byLocale = [];
        foreach (Locale::cases() as $locale) {
            $translation = $this->translations->first(fn ($t) => $t->locale === $locale);
            $byLocale[$locale->value] = $translation?->only(ProjectContent::fields());
        }

        return $byLocale;
    }

    /**
     * @param  Collection<int, CategoryTranslation>  $translations
     * @return array<string, string|null>
     */
    private function namesByLocale($translations): array
    {
        $names = [];
        foreach (Locale::cases() as $locale) {
            $names[$locale->value] = $translations->first(fn ($t) => $t->locale === $locale)?->name;
        }

        return $names;
    }
}
