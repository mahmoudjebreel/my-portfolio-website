<?php

namespace App\Http\Resources\Admin;

use App\Enums\Locale;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Admin shape of a category: both languages side by side and the number of linked projects
 * (all statuses). Expects `translations` to be eager loaded and `projects_count` (withCount).
 *
 * `in_use`: linked to at least one project. There is no delete action; any future one must
 * refuse a category while it is in use.
 *
 * @mixin Category
 */
class AdminCategoryResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $translations = [];
        foreach (Locale::cases() as $locale) {
            $translation = $this->translations->first(fn ($t) => $t->locale === $locale);
            $translations[$locale->value] = $translation ? ['name' => $translation->name, 'slug' => $translation->slug] : null;
        }
        $projects = (int) $this->projects_count;

        return [
            'id' => $this->id,
            'sort_order' => (int) $this->sort_order,
            'translations' => $translations,
            'projects_count' => $projects,
            'in_use' => $projects > 0,
            'updated_at' => $this->updated_at?->toIso8601ZuluString(),
        ];
    }
}
