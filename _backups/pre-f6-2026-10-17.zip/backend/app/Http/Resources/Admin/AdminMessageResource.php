<?php

namespace App\Http\Resources\Admin;

use App\Models\ContactMessage;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Str;

/**
 * A contact message for the administration (A7). The list shows a short plain-text excerpt;
 * the detail (`withBody()`) adds the full message. Texts are returned as stored: the
 * interface renders them as plain text, never as HTML.
 *
 * `reply_email` is set only when the stored address is a valid email, so a mailto: link is
 * never built from an invalid value.
 *
 * @mixin ContactMessage
 */
class AdminMessageResource extends JsonResource
{
    private bool $withBody = false;

    public function withBody(): static
    {
        $this->withBody = true;

        return $this;
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $email = trim((string) $this->email);

        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'reply_email' => filter_var($email, FILTER_VALIDATE_EMAIL) !== false ? $email : null,
            'subject' => $this->subject,
            'excerpt' => Str::limit(Str::squish((string) $this->message), 140),
            'message' => $this->when($this->withBody, $this->message),
            'locale' => $this->locale?->value,
            'status' => $this->status->value,
            'read_at' => $this->read_at?->toIso8601ZuluString(),
            'created_at' => $this->created_at?->toIso8601ZuluString(),
        ];
    }
}
