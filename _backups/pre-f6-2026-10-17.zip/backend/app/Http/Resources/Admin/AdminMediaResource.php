<?php

namespace App\Http\Resources\Admin;

use App\Support\MediaLibrary;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * One image of the media library (A6), described by App\Support\MediaLibrary: a project
 * cover or a gallery image. Never exposes the stored path or any disk location: only the file
 * name, its type and size, and an admin-only preview URL.
 */
class AdminMediaResource extends JsonResource
{
    /**
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return MediaLibrary::describe(
            $this->resource,
            fn (string $kind, int $id): string => "/api/admin/media/{$kind}/{$id}/preview",
        );
    }
}
