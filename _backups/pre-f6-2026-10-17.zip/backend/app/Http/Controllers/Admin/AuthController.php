<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\LoginRequest;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    /**
     * No body: the "web" middleware group attaches the XSRF-TOKEN cookie (readable
     * by the SPA) and the session cookie (HttpOnly) to this response.
     */
    public function csrfCookie(): Response
    {
        return response()->noContent();
    }

    /**
     * Signs an administrator in. Auth::attempt() already regenerates the session id
     * and the CSRF token (SessionGuard::updateSession), so a session id or token
     * known before the login cannot be reused afterwards.
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $request->authenticate();

        return response()->json(['data' => $this->userData($request->user('web'))]);
    }

    /**
     * Signs out and destroys the session; a new CSRF token is issued for the next request.
     */
    public function logout(Request $request): Response
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->noContent();
    }

    /**
     * The signed-in administrator (route protected by the "admin" middleware).
     */
    public function me(Request $request): JsonResponse
    {
        return response()->json(['data' => $this->userData($request->user('web'))]);
    }

    /**
     * @return array{id: int, name: string, email: string}
     */
    private function userData(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
        ];
    }
}
