<?php

namespace App\Http\Controllers\Admin;

use App\Actions\Media\AddGalleryImage;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\MediaIndexRequest;
use App\Http\Requests\Admin\MediaUploadRequest;
use App\Http\Resources\Admin\AdminMediaResource;
use App\Models\Project;
use App\Support\MediaLibrary;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Pagination\LengthAwarePaginator;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

/**
 * Media library for the administration (A6): project covers and gallery images, through
 * App\Support\MediaLibrary (shared with the Filament panel).
 *
 * - Listing reads the existing relations only; covers stay read-only.
 * - Uploading adds a gallery image (project_images) to an existing project.
 * - Nothing is ever deleted, detached or replaced, and no client-supplied path is used.
 */
class MediaController extends Controller
{
    public function index(MediaIndexRequest $request): AnonymousResourceCollection
    {
        $items = MediaLibrary::items($request->validated('project'), $request->validated('kind'), (string) $request->validated('q'));

        $perPage = $request->perPage();
        $page = (int) $request->validated('page', 1);
        $paginator = new LengthAwarePaginator(
            $items->forPage($page, $perPage)->values(),
            $items->count(),
            $perPage,
            $page,
            ['path' => $request->url(), 'query' => $request->query()],
        );

        return AdminMediaResource::collection($paginator)->additional([
            'projects' => MediaLibrary::projectOptions(),
        ]);
    }

    public function show(string $kind, int $id): AdminMediaResource
    {
        return new AdminMediaResource(MediaLibrary::find($kind, $id));
    }

    public function preview(string $kind, int $id): BinaryFileResponse
    {
        return MediaLibrary::previewResponse(MediaLibrary::find($kind, $id));
    }

    public function store(MediaUploadRequest $request, AddGalleryImage $add): JsonResponse
    {
        $project = Project::query()->findOrFail($request->validated('project_id'));
        $image = $add->handle($project, (string) $request->file('file')->get(), (array) ($request->validated('alt') ?? []));

        return (new AdminMediaResource(MediaLibrary::galleryItem($image->load(['project.translations', 'translations']))))
            ->response()
            ->setStatusCode(201);
    }
}
