<?php

namespace App\Http\Controllers\Admin;

use App\Actions\Catalog\SaveTechnology;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\TechnologyIndexRequest;
use App\Http\Requests\Admin\TechnologyRequest;
use App\Http\Resources\Admin\AdminTechnologyResource;
use App\Models\Technology;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Technology management for the administration (routes/admin.php, "admin" middleware).
 * There is deliberately no delete action in this phase (A5), and an update never changes
 * whether a technology is shown on the public site.
 */
class TechnologyController extends Controller
{
    public function index(TechnologyIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));
        $group = $request->validated('group');
        $visibility = $request->validated('visibility');

        $technologies = Technology::query()
            ->when($search !== '', function (Builder $query) use ($search) {
                $like = '%'.addcslashes($search, '\\%_').'%';
                $query->where(fn (Builder $match) => $match
                    ->where('name', 'like', $like)
                    ->orWhereHas('translations', fn (Builder $translation) => $translation->where('display_name', 'like', $like)));
            })
            ->when($group !== null, fn (Builder $query) => $query->where('group', $group))
            ->when($visibility !== null, fn (Builder $query) => $query->where('is_visible', $visibility === 'visible'))
            ->with('translations')
            ->withCount('projects')
            ->orderBy('name')
            ->orderBy('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminTechnologyResource::collection($technologies);
    }

    public function show(Technology $technology): AdminTechnologyResource
    {
        return new AdminTechnologyResource($this->loadDetail($technology));
    }

    public function store(TechnologyRequest $request, SaveTechnology $save): JsonResponse
    {
        $technology = $save->handle(null, $request->validated());

        return (new AdminTechnologyResource($this->loadDetail($technology)))->response()->setStatusCode(201);
    }

    public function update(TechnologyRequest $request, Technology $technology, SaveTechnology $save): AdminTechnologyResource
    {
        // is_visible has no rule on update, and SaveTechnology never changes it there.
        $save->handle($technology, $request->validated());

        return new AdminTechnologyResource($this->loadDetail($technology));
    }

    private function loadDetail(Technology $technology): Technology
    {
        return $technology->load('translations')->loadCount('projects');
    }
}
