<?php

namespace App\Http\Controllers\Admin;

use App\Actions\Projects\ChangeProjectStatus;
use App\Actions\Projects\SaveProject;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\ProjectIndexRequest;
use App\Http\Requests\Admin\ProjectRequest;
use App\Http\Requests\Admin\ProjectStatusRequest;
use App\Http\Resources\Admin\AdminProjectDetailResource;
use App\Http\Resources\Admin\AdminProjectResource;
use App\Models\Project;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Project management for the administration (routes/admin.php, "admin" middleware).
 * There is deliberately no delete action in this phase, and images are read-only.
 * Saving and publishing go through App\Actions\Projects (shared with the Filament panel).
 */
class ProjectController extends Controller
{
    public function index(ProjectIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));
        $status = $request->validated('status');
        $category = $request->validated('category');

        $projects = Project::query()
            ->when($search !== '', fn (Builder $query) => $query->whereHas(
                'translations',
                fn (Builder $translation) => $translation->where('title', 'like', '%'.addcslashes($search, '\\%_').'%'),
            ))
            ->when($status !== null, fn (Builder $query) => $query->where('status', $status))
            ->when($category !== null, fn (Builder $query) => $query->whereHas(
                'categories',
                fn (Builder $categories) => $categories->whereKey($category),
            ))
            ->with(['translations', 'categories' => fn ($query) => $query->orderBy('categories.sort_order'), 'categories.translations'])
            ->orderByDesc('updated_at')
            ->orderByDesc('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminProjectResource::collection($projects);
    }

    public function show(Project $project): AdminProjectDetailResource
    {
        return new AdminProjectDetailResource($this->loadDetail($project));
    }

    public function store(ProjectRequest $request, SaveProject $save): JsonResponse
    {
        $project = $save->handle(null, $request->validated());

        return (new AdminProjectDetailResource($this->loadDetail($project)))->response()->setStatusCode(201);
    }

    public function update(ProjectRequest $request, Project $project, SaveProject $save): AdminProjectDetailResource
    {
        $save->handle($project, $request->validated());

        return new AdminProjectDetailResource($this->loadDetail($project));
    }

    /**
     * Publish or unpublish. Publishing is refused unless both languages are complete.
     */
    public function updateStatus(ProjectStatusRequest $request, Project $project, ChangeProjectStatus $change): AdminProjectResource
    {
        $change->handle($project, $request->status());

        return new AdminProjectResource($project->load(['translations', 'categories.translations']));
    }

    private function loadDetail(Project $project): Project
    {
        return $project->load(['translations', 'categories', 'technologies'])->loadCount('images');
    }
}
