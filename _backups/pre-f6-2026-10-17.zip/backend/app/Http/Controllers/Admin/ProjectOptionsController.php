<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Locale;
use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Technology;
use Illuminate\Http\JsonResponse;

/**
 * Read-only choices for the project form: existing categories (names in both languages)
 * and technologies (hidden ones included, flagged). Managing them is a later phase.
 */
class ProjectOptionsController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $categories = Category::query()
            ->with('translations')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get()
            ->map(function (Category $category) {
                $names = [];
                foreach (Locale::cases() as $locale) {
                    $names[$locale->value] = $category->translations->first(fn ($t) => $t->locale === $locale)?->name;
                }

                return ['id' => $category->id, 'name' => $names];
            });

        $technologies = Technology::query()
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get()
            ->map(fn (Technology $technology) => [
                'id' => $technology->id,
                'name' => $technology->name,
                'group' => $technology->group->value,
                'is_visible' => (bool) $technology->is_visible,
            ]);

        return response()->json(['data' => ['categories' => $categories, 'technologies' => $technologies]]);
    }
}
