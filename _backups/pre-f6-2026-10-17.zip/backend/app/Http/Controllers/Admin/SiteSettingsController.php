<?php

namespace App\Http\Controllers\Admin;

use App\Actions\Settings\SaveSiteSettings;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SiteSettingsRequest;
use Illuminate\Http\JsonResponse;

/**
 * Site settings for the administration (A6). Reads and writes only the keys listed by
 * SiteSettingsForm (taken from SiteSettingsRegistry), through App\Actions\Settings\SaveSiteSettings
 * (shared with the Filament panel). Nothing is deleted, and image settings are shown read-only
 * without their storage paths.
 */
class SiteSettingsController extends Controller
{
    public function show(): JsonResponse
    {
        return response()->json(['data' => SaveSiteSettings::snapshot()]);
    }

    public function update(SiteSettingsRequest $request, SaveSiteSettings $save): JsonResponse
    {
        $save->handle(
            (array) ($request->validated('texts') ?? []),
            (array) ($request->validated('values') ?? []),
        );

        return response()->json(['data' => SaveSiteSettings::snapshot()]);
    }
}
