<?php

namespace App\Http\Controllers\Admin;

use App\Actions\Catalog\SaveCategory;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CategoryIndexRequest;
use App\Http\Requests\Admin\CategoryRequest;
use App\Http\Resources\Admin\AdminCategoryResource;
use App\Models\Category;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Category management for the administration (routes/admin.php, "admin" middleware).
 * There is deliberately no delete action in this phase (A5).
 */
class CategoryController extends Controller
{
    public function index(CategoryIndexRequest $request): AnonymousResourceCollection
    {
        $search = trim((string) $request->validated('q'));

        $categories = Category::query()
            ->when($search !== '', fn (Builder $query) => $query->whereHas(
                'translations',
                fn (Builder $translation) => $translation->where('name', 'like', '%'.addcslashes($search, '\\%_').'%'),
            ))
            ->with('translations')
            ->withCount('projects')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->paginate($request->perPage())
            ->withQueryString();

        return AdminCategoryResource::collection($categories);
    }

    public function show(Category $category): AdminCategoryResource
    {
        return new AdminCategoryResource($this->loadDetail($category));
    }

    public function store(CategoryRequest $request, SaveCategory $save): JsonResponse
    {
        $category = $save->handle(null, $request->validated());

        return (new AdminCategoryResource($this->loadDetail($category)))->response()->setStatusCode(201);
    }

    public function update(CategoryRequest $request, Category $category, SaveCategory $save): AdminCategoryResource
    {
        $save->handle($category, $request->validated());

        return new AdminCategoryResource($this->loadDetail($category));
    }

    private function loadDetail(Category $category): Category
    {
        return $category->load('translations')->loadCount('projects');
    }
}
