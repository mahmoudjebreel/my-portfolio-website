<?php

namespace App\Http\Requests\Admin;

use App\Enums\TechnologyGroup;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Query of the admin technology list: search by name, group and visibility filters,
 * server-side pagination.
 */
class TechnologyIndexRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'q' => ['sometimes', 'nullable', 'string', 'max:100'],
            'group' => ['sometimes', 'nullable', Rule::enum(TechnologyGroup::class)],
            'visibility' => ['sometimes', 'nullable', Rule::in(['visible', 'hidden'])],
            'page' => ['sometimes', 'integer', 'min:1', 'max:100000'],
            'per_page' => ['sometimes', 'integer', 'between:5,50'],
        ];
    }

    public function perPage(): int
    {
        return (int) $this->validated('per_page', 10);
    }
}
