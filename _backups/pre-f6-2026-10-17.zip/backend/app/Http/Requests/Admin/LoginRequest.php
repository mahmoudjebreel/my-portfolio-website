<?php

namespace App\Http\Requests\Admin;

use App\Support\RateLimitAddress;
use Illuminate\Auth\Events\Lockout;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Admin sign-in: email + password only. Any other field in the request (for
 * example `is_admin` or `remember`) is ignored.
 *
 * Failed attempts are limited per email + IP address (5 per minute; IPv6 per /64);
 * the route also has a per-IP limit (see AppServiceProvider). The limiter key is
 * a hash, so neither the email nor the password is stored in the cache.
 */
class LoginRequest extends FormRequest
{
    public const MAX_ATTEMPTS = 5;

    public const DECAY_SECONDS = 60;

    /** The same message for an unknown email, a wrong password and a non-admin account. */
    public const FAILED_MESSAGE = 'These credentials do not match our records.';

    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'string', 'email', 'max:254'],
            // Long enough for any passphrase, short enough to keep hashing cheap.
            'password' => ['required', 'string', 'max:1000'],
        ];
    }

    /**
     * Signs the administrator in on the "web" (session) guard, without "remember me".
     *
     * @throws ValidationException|ThrottleRequestsException
     */
    public function authenticate(): void
    {
        $this->ensureIsNotRateLimited();

        $credentials = [
            'email' => (string) $this->validated('email'),
            'password' => (string) $this->validated('password'),
            // Server-side constraint: only administrators can sign in here. A regular
            // account is treated exactly like an unknown email (same message, same timing).
            'is_admin' => true,
        ];

        if (! Auth::guard('web')->attempt($credentials, remember: false)) {
            RateLimiter::hit($this->throttleKey(), self::DECAY_SECONDS);

            throw ValidationException::withMessages(['email' => self::FAILED_MESSAGE]);
        }

        RateLimiter::clear($this->throttleKey());
    }

    /**
     * @throws ThrottleRequestsException
     */
    private function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), self::MAX_ATTEMPTS)) {
            return;
        }

        event(new Lockout($this));

        $seconds = RateLimiter::availableIn($this->throttleKey());

        throw new ThrottleRequestsException(
            'Too many login attempts. Please try again later.',
            headers: ['Retry-After' => $seconds],
        );
    }

    private function throttleKey(): string
    {
        return self::throttleKeyFor((string) $this->input('email'), $this->ip());
    }

    /**
     * Failed-attempt key for one email and client address. IPv6 clients are grouped
     * by /64 (RateLimitAddress); IPv4 keys are unchanged.
     */
    public static function throttleKeyFor(string $email, ?string $ip): string
    {
        return 'admin-login:'.hash('sha256', Str::lower(trim($email)).'|'.RateLimitAddress::for($ip));
    }
}
