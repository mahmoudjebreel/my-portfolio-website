<?php

namespace App\Http\Requests\Admin;

use App\Enums\MessageStatus;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Mark a contact message as read or unread. "archived" exists in the data model but is not
 * set from the administration in this phase.
 */
class MessageStatusRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'status' => ['required', Rule::in([MessageStatus::Read->value, MessageStatus::Unread->value])],
        ];
    }

    public function status(): MessageStatus
    {
        return MessageStatus::from($this->validated('status'));
    }
}
