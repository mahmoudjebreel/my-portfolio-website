<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Query of the admin media list: search (project title or file name), project and kind
 * (cover / gallery) filters, server-side pagination.
 */
class MediaIndexRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'q' => ['sometimes', 'nullable', 'string', 'max:100'],
            'project' => ['sometimes', 'nullable', 'integer', 'min:1'],
            'kind' => ['sometimes', 'nullable', Rule::in(['cover', 'gallery'])],
            'page' => ['sometimes', 'integer', 'min:1', 'max:100000'],
            'per_page' => ['sometimes', 'integer', 'between:6,48'],
        ];
    }

    public function perPage(): int
    {
        return (int) $this->validated('per_page', 12);
    }
}
