<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

/**
 * Query of the admin category list: search by name (either language), server-side pagination.
 */
class CategoryIndexRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // the "admin" middleware has already checked the session
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'q' => ['sometimes', 'nullable', 'string', 'max:100'],
            'page' => ['sometimes', 'integer', 'min:1', 'max:100000'],
            'per_page' => ['sometimes', 'integer', 'between:5,50'],
        ];
    }

    public function perPage(): int
    {
        return (int) $this->validated('per_page', 10);
    }
}
