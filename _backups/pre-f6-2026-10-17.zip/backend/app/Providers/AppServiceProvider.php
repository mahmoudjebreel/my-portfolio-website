<?php

namespace App\Providers;

use App\Support\RateLimitAddress;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Applied once to the public read-only API (routes/api.php). The framework's
        // "api" group has no limiter of its own, so requests are not throttled twice.
        RateLimiter::for('public-api', fn (Request $request) => Limit::perMinute(60)->by($request->ip()));

        // Admin API (routes/admin.php): per signed-in user, or per IP before sign-in.
        // IPv6 clients are grouped by /64 (RateLimitAddress); IPv4 keys are unchanged.
        RateLimiter::for('admin', function (Request $request) {
            $userId = $request->user('web')?->getAuthIdentifier();

            return Limit::perMinute(120)->by($userId !== null ? 'user:'.$userId : 'ip:'.RateLimitAddress::for($request->ip()));
        });

        // Login requests per IP, whatever the email: stops spraying many accounts from one
        // address. Failed attempts per email + IP are limited separately in LoginRequest.
        RateLimiter::for('admin-login', fn (Request $request) => Limit::perMinute(20)->by('ip:'.RateLimitAddress::for($request->ip())));
    }
}
