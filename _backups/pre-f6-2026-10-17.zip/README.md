# Developer Portfolio

Personal 3D portfolio: a React + TypeScript + Three.js front end (`frontend/`) and a Laravel 13 API (`backend/`) on MySQL.

> Work in progress. Sections below are added as each phase is approved.

## Local environment (Laragon)

Always call Laragon's PHP explicitly. The `php` on the system PATH is a different install (lower upload limits, missing extensions).

```powershell
$PHP = "C:\laragon\bin\php\php-8.3.30-Win32-vs16-x64\php.exe"
```

Inside the Laragon terminal (Cmder), `php` already resolves to Laragon's PHP.

## Database

| Database | Purpose |
|---|---|
| `jebreel_portfolio` | Development data. Changes to it need an explicit decision. |
| `jebreel_portfolio_test` | Automated tests only. Wiped and rebuilt by every test run. |

The application connects as the restricted user `jebreel_dev`, which has privileges on these two databases only. Credentials live in `backend/.env`, which is never committed. Never use `root` for the application.

### Safe commands (run from `backend/`)

```powershell
& $PHP artisan migrate:status   # read-only: shows which migrations ran
& $PHP artisan migrate          # applies pending migrations only; does not drop tables
& $PHP artisan test             # runs only against jebreel_portfolio_test (guarded)
```

### Destructive commands: do not run on the development database without a deliberate decision

> **Warning:** the commands below drop or empty tables. All data in `jebreel_portfolio` is lost, including projects, messages and settings.

| Command | Effect |
|---|---|
| `migrate:fresh` | Drops **all** tables, then re-runs every migration |
| `migrate:refresh` | Rolls back **all** migrations, then runs them again |
| `migrate:reset` | Rolls back **all** migrations |
| `migrate:rollback` | Rolls back the last batch (drops those tables) |
| `db:wipe` | Drops **all** tables, views and types |

Take a backup before any of them:

```powershell
& "C:\laragon\bin\mysql\mysql-8.4.3-winx64\bin\mysqldump.exe" -u root -h 127.0.0.1 jebreel_portfolio > jebreel_portfolio_backup.sql
```

### Seeding

- `database/seeders/DatabaseSeeder.php` contains only reviewed, approved initial data. It is empty for now, and it never creates users.
- Model factories (`database/factories`) are **test-only**. They throw an exception outside the `testing` environment, so `db:seed`, `migrate --seed` or tinker cannot insert fake users or data into a real database.
- The admin account is created by its owner with `php artisan admin:create` (see [Admin authentication](#admin-authentication)). No default credentials exist.

### Tests

`phpunit.xml` forces `DB_CONNECTION=mysql` and `DB_DATABASE=jebreel_portfolio_test`. In addition, `tests/TestCase.php` refuses to run any test, before any query, unless the connection points at `jebreel_portfolio_test`.

## Admin authentication

The admin API uses Laravel's own session authentication (`web` guard, no Sanctum, no tokens). Routes live in `backend/routes/admin.php`, are registered in `bootstrap/app.php` under `/api/admin` with the `web` middleware group (cookies, session, CSRF), and are reached through the same origin as the site (the Vite proxy forwards `/api` in development).

| Method | Path | Access | Purpose |
|---|---|---|---|
| GET | `/api/admin/csrf-cookie` | anyone | Sets the `XSRF-TOKEN` cookie (and the session cookie). `204` |
| POST | `/api/admin/login` | anyone (CSRF, rate limited) | `{ email, password }` → `200 { data: { id, name, email } }`. Any failure → `422` with one generic message |
| POST | `/api/admin/logout` | anyone (CSRF) | Signs out and destroys the session. `204` |
| GET | `/api/admin/me` | administrator | Current administrator. `401` without a valid session, `403` if the account is not an administrator |

- **Administrators only**: `users.is_admin` is read from the database on every request by the `admin` middleware (`App\Http\Middleware\EnsureUserIsAdmin`). It is not mass assignable, and nothing sent by the client is used. A non-admin account cannot sign in here (same response as a wrong password).
- **Sessions**: 120 minutes of inactivity (`SESSION_LIFETIME`), no "remember me". Signing in regenerates the session id and the CSRF token; signing out destroys the session.
- **Rate limiting**: 5 failed attempts per email + IP address per minute (`429` with `Retry-After`), and 20 login requests per IP per minute whatever the email. The limiter uses the default cache store (`database` locally, so counters go to the `cache` table of the configured database when the app runs; tests use the in-memory `array` store).
- **CSRF** (Laravel 13 `PreventRequestForgery`): a state-changing request is accepted when the browser marks it `Sec-Fetch-Site: same-origin`, or when it carries a valid token. The SPA should still always send the token: call `GET /api/admin/csrf-cookie` once, then send the value of the `XSRF-TOKEN` cookie in an `X-XSRF-TOKEN` header with every POST/PUT/PATCH/DELETE (`credentials: 'same-origin'`). After sign-in or sign-out the cookie changes, so read it before each request. `419` means the session or token expired: fetch the cookie again and sign in.

### Creating the administrator (run by the owner)

```powershell
cd backend
& $PHP artisan admin:create
```

The command asks for the name, the email and the password (typed twice, hidden). The password needs at least 12 characters (72 bytes at most); it is never accepted as an argument, printed or logged. If the email already belongs to an account, the command stops without changing anything. It writes to the database configured in `backend/.env`.

### Production checklist (not testable locally)

- HTTPS, with `SESSION_SECURE_COOKIE=true` so cookies are only sent over HTTPS (leave it unset locally on plain HTTP).
- `APP_DEBUG=false` (otherwise error responses include traces).
- The SPA and the API on the same origin; `CORS_ALLOWED_ORIGINS` stays empty.

Tests: `& $PHP artisan test tests/Feature/Admin` (CSRF is verified for real in `AdminCsrfTest`: Laravel skips CSRF checks under PHPUnit unless the middleware is swapped as done there).

> **Pending verification:** the database tests have not been run since the A1 security adjustments (`auth.timebox_duration` = 500 ms, IPv6 rate-limit keys grouped by /64), because MySQL was stopped. They must be run on `jebreel_portfolio_test` (`& $PHP artisan test`) before relying on those changes. The database-free tests (`tests/Unit`, `AdminRateLimitKeysTest`, `TestDatabaseGuardRejectsTest`) passed.

## Admin interface (`/admin`)

The React administration lives in `frontend/src/admin` and is loaded on demand (its own chunks; the public site never downloads it). It uses the admin API above through the same origin and never stores credentials or session data itself: `GET /api/admin/me` decides who is signed in, and every protection is enforced by Laravel.

- `/admin/login`: sign-in form (email + password, no "remember me"). Wrong credentials, a non-admin account or an unknown email all show the same message; `429` shows the waiting time.
- `/admin`: overview after sign-in (no figures yet). Other sections are listed as planned.
- Session states: checking, server unreachable (with retry), expired (detected when the tab becomes visible again or on `401`/`419`), signed out.
- CSRF: the client fetches `/api/admin/csrf-cookie` when there is no `XSRF-TOKEN` cookie, sends the cookie value in `X-XSRF-TOKEN` with every POST, and on a `419` fetches a fresh cookie and retries once.
- Language: English or Arabic (RTL), switched in the interface and remembered in this browser (`localStorage`), independent of the URL. Admin pages ask search engines not to index them.

The admin pages always call the real API, never the mock data source; without a running backend they show "The administration is unavailable".
