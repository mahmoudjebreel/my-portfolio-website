/**
 * Admin API (Laravel, routes/admin.php). Authentication is Laravel's session: this module
 * only calls the endpoints; nothing about the session is stored in the browser by us.
 *
 * CSRF: Laravel sets the XSRF-TOKEN cookie (GET /admin/csrf-cookie); apiSend sends it back
 * in X-XSRF-TOKEN. The cookie changes at sign-in and sign-out, and it is read again before
 * every request. A 419 (token or session expired) gets one fresh cookie and one retry.
 */
import { ApiError, apiGet, apiRequest, apiSend, readCookie, type RequestOptions } from '../api/client'

export interface AdminUser {
  id: number
  name: string
  email: string
}

export async function fetchCsrfCookie(options?: RequestOptions): Promise<void> {
  await apiRequest('GET', '/admin/csrf-cookie', { ...options, requireData: false })
}

export async function withCsrf<T>(send: () => Promise<T>): Promise<T> {
  if (!readCookie('XSRF-TOKEN')) await fetchCsrfCookie()
  try {
    return await send()
  } catch (error) {
    if (!(error instanceof ApiError) || error.kind !== 'csrf') throw error
    await fetchCsrfCookie()
    return send()
  }
}

const isAdminUser = (value: unknown): value is AdminUser =>
  typeof value === 'object' &&
  value !== null &&
  typeof (value as AdminUser).id === 'number' &&
  typeof (value as AdminUser).name === 'string' &&
  typeof (value as AdminUser).email === 'string'

function userFrom(body: { data?: unknown } | null): AdminUser {
  if (!isAdminUser(body?.data)) throw new ApiError('invalid_response', 'The server returned an unexpected response.')
  return body.data
}

/** The signed-in administrator. 401 = no session, 403 = signed in but not an administrator. */
export async function fetchCurrentAdmin(options?: RequestOptions): Promise<AdminUser> {
  return userFrom(await apiGet<{ data: unknown }>('/admin/me', {}, options))
}

/** Email + password only. Any failure of the credentials is a 422 with one generic message. */
export async function signIn(email: string, password: string): Promise<AdminUser> {
  return userFrom(await withCsrf(() => apiSend<{ data: unknown }>('POST', '/admin/login', { email, password })))
}

export async function signOut(): Promise<void> {
  await withCsrf(() => apiSend('POST', '/admin/logout'))
}
