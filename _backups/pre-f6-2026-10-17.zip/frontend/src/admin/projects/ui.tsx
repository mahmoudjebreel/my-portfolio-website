import type { ReactNode } from 'react'
import type { Locale } from '../../i18n/config'
import { useAdminText } from '../i18n'
import type { ByLocale, ProjectStatus } from '../projectsApi'

export function StatusBadge({ status }: { status: ProjectStatus }) {
  const a = useAdminText()
  const published = status === 'published'
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap ${
        published ? 'border-emerald-300/25 bg-emerald-400/10 text-emerald-200' : 'border-amber-300/25 bg-amber-400/10 text-amber-200'
      }`}
    >
      <span aria-hidden="true" className={`size-1.5 rounded-full ${published ? 'bg-emerald-300' : 'bg-amber-300'}`} />
      {a.projects.statuses[status]}
    </span>
  )
}

/** EN / AR chips: filled when that language is complete. */
export function LanguageChips({ complete }: { complete: ByLocale<boolean> }) {
  const a = useAdminText()
  return (
    <span className="inline-flex gap-1.5">
      {(['en', 'ar'] as Locale[]).map((locale) => (
        <span
          key={locale}
          title={`${locale.toUpperCase()}: ${complete[locale] ? a.projects.complete : a.projects.incomplete}`}
          className={`rounded-md border px-1.5 py-0.5 font-mono text-[0.7rem] font-semibold ${
            complete[locale] ? 'border-cyan-300/30 bg-cyan-300/10 text-cyan-100' : 'border-white/10 text-slate-500 line-through'
          }`}
        >
          {locale.toUpperCase()}
          <span className="sr-only"> {complete[locale] ? a.projects.complete : a.projects.incomplete}</span>
        </span>
      ))}
    </span>
  )
}

export function Notice({
  tone,
  children,
  onDismiss,
  dismissLabel,
}: {
  tone: 'success' | 'error'
  children: ReactNode
  onDismiss?: () => void
  dismissLabel?: string
}) {
  return (
    <div
      role={tone === 'error' ? 'alert' : 'status'}
      className={`flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm ${
        tone === 'success' ? 'border-emerald-300/25 bg-emerald-400/[0.08] text-emerald-100' : 'border-rose-300/25 bg-rose-500/10 text-rose-100'
      }`}
    >
      <p className="flex-1">{children}</p>
      {onDismiss && (
        <button type="button" onClick={onDismiss} aria-label={dismissLabel} className="rounded-full px-1 text-current opacity-70 transition hover:opacity-100">
          <span aria-hidden="true">×</span>
        </button>
      )}
    </div>
  )
}

export const fieldClass =
  'w-full rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 transition focus:border-cyan-300/60 focus:bg-white/[0.07] focus:outline-none aria-[invalid=true]:border-rose-400/60'

export const buttonPrimary =
  'inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2.5 text-sm font-semibold text-ink-950 transition hover:brightness-110 disabled:opacity-60'

export const buttonGhost =
  'inline-flex items-center justify-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-cyan-300/40 hover:bg-white/10 hover:text-white disabled:opacity-50'
