import { useId, useState, type FormEvent } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { ApiError } from '../../api/client'
import { Skeleton } from '../../components/ui/DataStates'
import type { Locale } from '../../i18n/config'
import { useI18n } from '../../i18n/I18nProvider'
import { useAdminAuth } from '../AdminAuth'
import {
  createTechnology,
  getTechnology,
  ICON_PATTERN,
  TECHNOLOGY_GROUPS,
  updateTechnology,
  type AdminTechnology,
  type TechnologyGroup,
  type TechnologyPayload,
} from '../catalogApi'
import { BackLink, Card, focusFirstError, isSortOrder, mapServerErrors, TextField, UsageCard, VisibilityBadge, type Errors } from '../catalog/ui'
import { useAdminText, type AdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, fieldClass, Notice } from '../projects/ui'
import { SLUG_PATTERN, slugify, type ByLocale } from '../projectsApi'
import { useAdminData } from '../useAdminData'

const LOCALES: Locale[] = ['en', 'ar']
/** Same limits as backend/app/Http/Requests/Admin/TechnologyRequest.php. */
const MAX = { name: 60, slug: 80, icon: 60, display_name: 60, description: 300 } as const
const maxFor = (key: string): number | undefined => (MAX as Record<string, number>)[key.split('.').pop() ?? '']

type Texts = { display_name: string; description: string }
interface FormState {
  name: string
  slug: string
  group: TechnologyGroup | ''
  icon: string
  sort_order: string
  is_visible: boolean
  translations: ByLocale<Texts>
}

/** Mirrors the server rules (the server stays the authority). */
function validate(form: FormState, detail: AdminTechnology | undefined, a: AdminText): Errors {
  const c = a.catalog
  const errors: Errors = {}
  const name = form.name.trim()
  const slug = form.slug.trim()
  const icon = form.icon.trim()

  if (!name) errors.name = c.required
  else if (name.length > MAX.name) errors.name = c.tooLong(MAX.name)

  if (!slug) errors.slug = c.required
  else if (slug.length > MAX.slug) errors.slug = c.tooLong(MAX.slug)
  else if (slug !== detail?.slug && !SLUG_PATTERN.test(slug)) errors.slug = c.invalidSlug

  if (!form.group) errors.group = c.required

  if (icon.length > MAX.icon) errors.icon = c.tooLong(MAX.icon)
  else if (icon && icon !== detail?.icon && !ICON_PATTERN.test(icon)) errors.icon = a.technologies.form.invalidIcon

  if (!isSortOrder(form.sort_order)) errors.sort_order = c.invalidNumber

  for (const locale of LOCALES) {
    for (const field of ['display_name', 'description'] as const) {
      const value = form.translations[locale][field].trim()
      if (value.length > MAX[field]) errors[`translations.${locale}.${field}`] = c.tooLong(MAX[field])
    }
  }
  return errors
}

function toPayload(form: FormState, creating: boolean): TechnologyPayload {
  const translations = {} as TechnologyPayload['translations']
  for (const locale of LOCALES) {
    const texts = form.translations[locale]
    translations[locale] = { display_name: texts.display_name.trim() || null, description: texts.description.trim() || null }
  }
  return {
    name: form.name.trim(),
    slug: form.slug.trim(),
    group: form.group as TechnologyGroup,
    icon: form.icon.trim() || null,
    sort_order: Number(form.sort_order),
    translations,
    ...(creating ? { is_visible: form.is_visible } : {}),
  }
}

export function AdminTechnologyFormPage() {
  const a = useAdminText()
  const f = a.technologies.form
  const { id } = useParams()
  const editing = id !== undefined
  const technologyId = Number(id)
  const validId = !editing || (Number.isInteger(technologyId) && technologyId > 0)
  useAdminPage(editing ? a.technologies.editTitle : a.technologies.newTitle)

  const detail = useAdminData(editing && validId ? `admin-technology:${technologyId}` : null, (signal) => getTechnology(technologyId, { signal }))
  const back = <BackLink to="/admin/technologies">{f.back}</BackLink>

  if (!validId || (editing && detail.status === 'error')) {
    const notFound = !validId || detail.error?.kind === 'not_found'
    return (
      <div className="mx-auto max-w-3xl space-y-6">
        {back}
        <Notice tone="error">
          {notFound ? f.notFound : f.loadFailed}{' '}
          {!notFound && (
            <button type="button" onClick={detail.reload} className="font-semibold underline underline-offset-4">
              {a.catalog.retry}
            </button>
          )}
        </Notice>
      </div>
    )
  }

  if (editing && detail.status !== 'success') {
    return (
      <div data-testid="technology-form-loading" className="mx-auto max-w-5xl space-y-4" aria-busy="true">
        {back}
        <Skeleton className="h-64 w-full rounded-3xl" />
      </div>
    )
  }

  return <TechnologyForm key={detail.data?.id ?? 'new'} detail={detail.data} />
}

function TechnologyForm({ detail }: { detail: AdminTechnology | undefined }) {
  const a = useAdminText()
  const c = a.catalog
  const f = a.technologies.form
  const { t } = useI18n()
  const { handleAuthError } = useAdminAuth()
  const navigate = useNavigate()
  const formId = useId()

  const [form, setForm] = useState<FormState>(() => ({
    name: detail?.name ?? '',
    slug: detail?.slug ?? '',
    group: detail?.group ?? '',
    icon: detail?.icon ?? '',
    sort_order: String(detail?.sort_order ?? 0),
    is_visible: false,
    translations: {
      en: { display_name: detail?.translations.en?.display_name ?? '', description: detail?.translations.en?.description ?? '' },
      ar: { display_name: detail?.translations.ar?.display_name ?? '', description: detail?.translations.ar?.description ?? '' },
    },
  }))
  const [errors, setErrors] = useState<Errors>({})
  const [failure, setFailure] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const fieldId = (key: string) => `${formId}-${key.replace(/\./g, '-')}`
  const order = [
    'name',
    'slug',
    'group',
    'icon',
    'sort_order',
    ...LOCALES.flatMap((locale) => ['display_name', 'description'].map((field) => `translations.${locale}.${field}`)),
  ].map((key) => ({ key, id: fieldId(key) }))

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((current) => ({ ...current, [key]: value }))
  const setTexts = (locale: Locale, field: keyof Texts, value: string) =>
    setForm((current) => ({ ...current, translations: { ...current.translations, [locale]: { ...current.translations[locale], [field]: value } } }))

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (saving) return
    const nextErrors = validate(form, detail, a)
    setErrors(nextErrors)
    setFailure(null)
    if (Object.keys(nextErrors).length > 0) {
      setFailure(c.errorsSummary)
      focusFirstError(order, nextErrors)
      return
    }

    setSaving(true)
    try {
      const payload = toPayload(form, !detail)
      if (detail) await updateTechnology(detail.id, payload)
      else await createTechnology(payload)
      navigate('/admin/technologies', { state: { flash: detail ? a.technologies.saved : a.technologies.created } })
    } catch (error) {
      setSaving(false)
      if (handleAuthError(error)) return
      if (error instanceof ApiError && error.kind === 'validation') {
        const mapped = mapServerErrors(
          error.fieldErrors,
          { ...c, failed: f.saveFailed },
          {
            taken: (key) => (key === 'name' ? f.nameTaken : key === 'slug' ? f.slugTaken : undefined),
            max: maxFor,
            invalid: (key) => (key === 'icon' ? f.invalidIcon : key === 'group' ? c.required : undefined),
          },
        )
        setErrors(mapped)
        setFailure(c.errorsSummary)
        focusFirstError(order, mapped)
      } else if (error instanceof ApiError && error.kind === 'not_found') {
        setFailure(f.notFound)
      } else {
        setFailure(f.saveFailed)
      }
    }
  }

  const groupId = fieldId('group')

  return (
    <form noValidate onSubmit={onSubmit} className="mx-auto max-w-5xl space-y-6" aria-describedby={failure ? `${formId}-failure` : undefined}>
      <BackLink to="/admin/technologies">{f.back}</BackLink>

      {failure && (
        <div id={`${formId}-failure`}>
          <Notice tone="error">{failure}</Notice>
        </div>
      )}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <div className="min-w-0 space-y-6">
          <Card title={f.details} labelledBy={`${formId}-details`}>
            <div className="space-y-4">
              <TextField
                id={fieldId('name')}
                label={f.name}
                value={form.name}
                onChange={(value) => set('name', value)}
                error={errors.name}
                hint={f.nameHint}
                max={MAX.name}
                dir="ltr"
              />
              <TextField
                id={fieldId('slug')}
                label={f.slug}
                value={form.slug}
                onChange={(value) => set('slug', value)}
                error={errors.slug}
                hint={c.slugHint}
                max={MAX.slug}
                dir="ltr"
                lang="en"
                action={
                  <button
                    type="button"
                    className="text-xs font-medium text-cyan-300 transition hover:text-cyan-200"
                    onClick={() => {
                      const generated = slugify(form.name).slice(0, MAX.slug).replace(/-+$/, '')
                      if (generated) set('slug', generated)
                    }}
                  >
                    {c.generateSlug}
                  </button>
                }
              />
              <div>
                <label htmlFor={groupId} className="mb-1.5 block text-sm font-medium text-slate-200">
                  {f.group}
                </label>
                <select
                  id={groupId}
                  value={form.group}
                  onChange={(event) => set('group', event.target.value as TechnologyGroup | '')}
                  aria-invalid={Boolean(errors.group)}
                  aria-describedby={errors.group ? `${groupId}-error` : undefined}
                  className={`${fieldClass} bg-ink-900`}
                >
                  <option value="">{f.chooseGroup}</option>
                  {TECHNOLOGY_GROUPS.map((value) => (
                    <option key={value} value={value}>
                      {t.skills.groups[value]}
                    </option>
                  ))}
                </select>
                {errors.group && (
                  <p id={`${groupId}-error`} className="mt-1 text-xs text-rose-300">
                    {errors.group}
                  </p>
                )}
              </div>
              <TextField
                id={fieldId('icon')}
                label={f.icon}
                value={form.icon}
                onChange={(value) => set('icon', value)}
                error={errors.icon}
                hint={f.iconHint}
                max={MAX.icon}
                optional
                dir="ltr"
                lang="en"
              />
            </div>
          </Card>

          {LOCALES.map((locale) => {
            const language = locale === 'en' ? c.english : c.arabic
            const dir = locale === 'ar' ? 'rtl' : 'ltr'
            return (
              <Card key={locale} title={f.translations(language)} labelledBy={`${formId}-${locale}-heading`}>
                <p className="-mt-2 mb-4 text-xs text-slate-400">{f.translationsHelp}</p>
                <div className="space-y-4">
                  <TextField
                    id={fieldId(`translations.${locale}.display_name`)}
                    label={f.displayName}
                    value={form.translations[locale].display_name}
                    onChange={(value) => setTexts(locale, 'display_name', value)}
                    error={errors[`translations.${locale}.display_name`]}
                    max={MAX.display_name}
                    optional
                    dir={dir}
                    lang={locale}
                  />
                  <TextField
                    id={fieldId(`translations.${locale}.description`)}
                    label={f.description}
                    value={form.translations[locale].description}
                    onChange={(value) => setTexts(locale, 'description', value)}
                    error={errors[`translations.${locale}.description`]}
                    max={MAX.description}
                    optional
                    multiline
                    dir={dir}
                    lang={locale}
                  />
                </div>
              </Card>
            )
          })}
        </div>

        <aside className="min-w-0 space-y-6">
          <Card title={f.visibilityTitle}>
            {detail ? (
              <>
                <VisibilityBadge visible={detail.is_visible} />
                <p className="mt-3 text-xs leading-relaxed text-slate-400">{f.visibilityLocked}</p>
              </>
            ) : (
              <>
                <label className="flex items-center gap-3 text-sm text-slate-200">
                  <input type="checkbox" checked={form.is_visible} onChange={(event) => set('is_visible', event.target.checked)} className="size-4 accent-cyan-400" />
                  {f.showOnSite}
                </label>
                <p className="mt-3 text-xs leading-relaxed text-slate-400">{f.visibilityNew}</p>
              </>
            )}
          </Card>
          <Card title={c.settings}>
            <TextField
              id={fieldId('sort_order')}
              label={c.sortOrder}
              value={form.sort_order}
              onChange={(value) => set('sort_order', value)}
              error={errors.sort_order}
              hint={c.sortOrderHint}
              dir="ltr"
              inputMode="numeric"
            />
          </Card>
          {detail && <UsageCard count={detail.projects_count} />}
        </aside>
      </div>

      <div className="sticky bottom-0 z-10 -mx-5 flex flex-wrap items-center justify-end gap-3 border-t border-white/10 bg-ink-950/85 px-5 py-4 backdrop-blur-xl sm:-mx-8 sm:px-8">
        <Link to="/admin/technologies" className={buttonGhost}>
          {c.cancel}
        </Link>
        <button type="submit" disabled={saving} aria-busy={saving} className={buttonPrimary}>
          {saving ? c.saving : f.save}
        </button>
      </div>
    </form>
  )
}
