import type { ReactNode } from 'react'
import { EmptyState } from '../../components/ui/DataStates'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { useAdminAuth } from '../AdminAuth'
import { useAdminText } from '../i18n'
import { AdminIcon, type AdminIconName } from '../icons'
import { mockMessages, mockProjects, mockStats } from '../mockDashboard'
import { useAdminPage } from '../pageTitle'

/**
 * Dashboard home. All figures and lists are MOCK DATA (src/admin/mockDashboard.ts) and are
 * labelled as such on screen; they will come from the API in a later phase.
 */
export function AdminHomePage() {
  const a = useAdminText()
  const { user } = useAdminAuth()
  useAdminPage(a.dashboard.title)

  const stats: { label: string; value: number; icon: AdminIconName; accent: string }[] = [
    { label: a.dashboard.stats.total, value: mockStats.totalProjects, icon: 'projects', accent: 'from-violet-500/25 text-violet-200' },
    { label: a.dashboard.stats.published, value: mockStats.publishedProjects, icon: 'published', accent: 'from-emerald-500/20 text-emerald-200' },
    { label: a.dashboard.stats.drafts, value: mockStats.draftProjects, icon: 'draft', accent: 'from-amber-500/20 text-amber-200' },
    { label: a.dashboard.stats.newMessages, value: mockStats.newMessages, icon: 'messages', accent: 'from-cyan-500/20 text-cyan-200' },
  ]

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-display text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            <span className="text-gradient">{a.dashboard.welcome(user?.name ?? '')}</span>
          </p>
          <p className="mt-2 max-w-2xl text-sm text-slate-400">{a.dashboard.intro}</p>
        </div>
        <MockBadge />
      </div>

      <p role="note" className="flex items-start gap-3 rounded-2xl border border-amber-300/20 bg-amber-400/[0.06] px-4 py-3 text-sm text-amber-100">
        <span aria-hidden="true" className="mt-1 size-2 shrink-0 rounded-full bg-amber-300" />
        {a.dashboard.mockNotice}
      </p>

      <section aria-labelledby="admin-stats">
        <h2 id="admin-stats" className="sr-only">
          {a.dashboard.statsTitle}
        </h2>
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => (
            <li key={stat.label} className="glass group relative overflow-hidden rounded-3xl p-5 transition hover:border-white/20">
              <div className={`absolute -end-8 -top-8 size-28 rounded-full bg-gradient-to-br ${stat.accent} to-transparent blur-2xl`} aria-hidden="true" />
              <div className="relative flex items-start justify-between gap-3">
                <p className="text-sm text-slate-400">{stat.label}</p>
                <span className={`grid size-10 place-items-center rounded-2xl border border-white/10 bg-gradient-to-br ${stat.accent} to-white/[0.02]`}>
                  <AdminIcon name={stat.icon} className="size-5" />
                </span>
              </div>
              <p className="relative mt-4 font-display text-4xl font-bold text-white">{stat.value}</p>
            </li>
          ))}
        </ul>
      </section>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <LatestProjects />
        <LatestMessages />
      </div>
    </div>
  )
}

function MockBadge() {
  const a = useAdminText()
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-400/10 px-3 py-1 text-xs font-semibold text-amber-200">
      <span aria-hidden="true" className="size-1.5 rounded-full bg-amber-300" />
      {a.dashboard.mockBadge}
    </span>
  )
}

function Panel({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  return (
    // min-w-0: as a grid item the panel must not grow with the table; the table scrolls inside it.
    <section aria-labelledby={id} className="glass flex min-w-0 flex-col rounded-3xl">
      <div className="flex items-center justify-between gap-3 border-b border-white/10 px-5 py-4 sm:px-6">
        <h2 id={id} className="font-display text-lg font-semibold text-white">
          {title}
        </h2>
        <MockBadge />
      </div>
      <div className="flex-1 p-2 sm:p-3">{children}</div>
    </section>
  )
}

function ProjectStatus({ status }: { status: 'published' | 'draft' }) {
  const a = useAdminText()
  return status === 'published' ? (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300/25 bg-emerald-400/10 px-2.5 py-0.5 text-xs font-medium text-emerald-200">
      <span aria-hidden="true" className="size-1.5 rounded-full bg-emerald-300" />
      {a.dashboard.status.published}
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-300/25 bg-amber-400/10 px-2.5 py-0.5 text-xs font-medium text-amber-200">
      <span aria-hidden="true" className="size-1.5 rounded-full bg-amber-300" />
      {a.dashboard.status.draft}
    </span>
  )
}

function LatestProjects() {
  const a = useAdminText()
  const { locale } = useI18n()

  return (
    <Panel id="admin-latest-projects" title={a.dashboard.latestProjects.title}>
      {mockProjects.length === 0 ? (
        <div className="p-3">
          <EmptyState>{a.dashboard.latestProjects.empty}</EmptyState>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[34rem] text-sm">
            <thead>
              <tr className="text-start text-xs text-slate-500">
                <th scope="col" className="px-3 py-2 text-start font-medium">
                  {a.dashboard.latestProjects.name}
                </th>
                <th scope="col" className="px-3 py-2 text-start font-medium">
                  {a.dashboard.latestProjects.category}
                </th>
                <th scope="col" className="px-3 py-2 text-start font-medium">
                  {a.dashboard.latestProjects.status}
                </th>
                <th scope="col" className="px-3 py-2 text-start font-medium">
                  {a.dashboard.latestProjects.updated}
                </th>
              </tr>
            </thead>
            <tbody>
              {mockProjects.map((project) => (
                <tr key={project.id} className="border-t border-white/5 transition hover:bg-white/[0.03]">
                  <td className="px-3 py-3 font-medium text-slate-100">{project.title[locale]}</td>
                  <td className="px-3 py-3 text-slate-400">{project.category[locale]}</td>
                  <td className="px-3 py-3">
                    <ProjectStatus status={project.status} />
                  </td>
                  <td className="px-3 py-3 whitespace-nowrap text-slate-400">
                    <time dateTime={project.updatedAt}>{formatDate(project.updatedAt, locale)}</time>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Panel>
  )
}

function LatestMessages() {
  const a = useAdminText()
  const { locale } = useI18n()

  return (
    <Panel id="admin-latest-messages" title={a.dashboard.latestMessages.title}>
      {mockMessages.length === 0 ? (
        <div className="p-3">
          <EmptyState>{a.dashboard.latestMessages.empty}</EmptyState>
        </div>
      ) : (
        <ul className="divide-y divide-white/5">
          {mockMessages.map((message) => (
            <li key={message.id} className="flex items-start gap-3 rounded-2xl px-3 py-3 transition hover:bg-white/[0.03]">
              <span
                aria-hidden="true"
                className={`mt-1.5 size-2 shrink-0 rounded-full ${message.read ? 'bg-slate-600' : 'bg-cyan-300 shadow-[0_0_10px] shadow-cyan-300/70'}`}
              />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                  <p className={`truncate text-sm ${message.read ? 'text-slate-300' : 'font-semibold text-white'}`}>{message.sender[locale]}</p>
                  <time dateTime={message.receivedAt} className="text-xs whitespace-nowrap text-slate-500">
                    {formatDate(message.receivedAt, locale)}
                  </time>
                </div>
                <p className="mt-0.5 truncate text-sm text-slate-400">{message.subject[locale]}</p>
                <p className="mt-1.5">
                  <span
                    className={`rounded-full border px-2 py-0.5 text-[0.7rem] ${
                      message.read ? 'border-white/10 text-slate-400' : 'border-cyan-300/30 bg-cyan-300/10 text-cyan-100'
                    }`}
                  >
                    {message.read ? a.dashboard.latestMessages.read : a.dashboard.latestMessages.unread}
                  </span>
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Panel>
  )
}
