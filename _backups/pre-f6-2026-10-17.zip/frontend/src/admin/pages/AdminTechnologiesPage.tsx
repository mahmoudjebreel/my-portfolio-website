import { Link } from 'react-router'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { listTechnologies, TECHNOLOGY_GROUPS, type TechnologyGroup } from '../catalogApi'
import { ListPanel, SearchField, td, th, useFlash, useListParams, VisibilityBadge } from '../catalog/ui'
import { useAdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, fieldClass, Notice } from '../projects/ui'
import { useAdminData } from '../useAdminData'

const PER_PAGE = 10

export function AdminTechnologiesPage() {
  const a = useAdminText()
  const c = a.catalog
  const s = a.technologies
  const { locale, t } = useI18n()
  useAdminPage(s.title)

  const { params, q, page, search, setSearch, update, clear } = useListParams()
  const rawGroup = params.get('group')
  const group = TECHNOLOGY_GROUPS.includes(rawGroup as TechnologyGroup) ? (rawGroup as TechnologyGroup) : undefined
  const rawVisibility = params.get('visibility')
  const visibility = rawVisibility === 'visible' || rawVisibility === 'hidden' ? rawVisibility : undefined

  const [notice, setNotice] = useFlash()
  const list = useAdminData(`admin-technologies:${q}:${group ?? ''}:${visibility ?? ''}:${page}`, (signal) =>
    listTechnologies({ q: q || undefined, group, visibility, page, perPage: PER_PAGE }, { signal }),
  )

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-2xl text-sm text-slate-400">{s.intro}</p>
        <Link to="/admin/technologies/new" className={buttonPrimary}>
          <span aria-hidden="true" className="text-base leading-none">+</span>
          {s.add}
        </Link>
      </div>

      {notice && (
        <Notice tone={notice.tone} onDismiss={() => setNotice(null)} dismissLabel={c.dismiss}>
          {notice.text}
        </Notice>
      )}

      <div role="search" className="glass grid gap-3 rounded-3xl p-4 sm:grid-cols-[minmax(0,1fr)_12rem_13rem]">
        <SearchField value={search} onChange={setSearch} label={s.search} placeholder={s.searchPlaceholder} />
        <label className="block">
          <span className="sr-only">{s.group}</span>
          <select value={group ?? ''} onChange={(event) => update({ group: event.target.value || undefined })} className={`${fieldClass} bg-ink-900`}>
            <option value="">{s.allGroups}</option>
            {TECHNOLOGY_GROUPS.map((value) => (
              <option key={value} value={value}>
                {t.skills.groups[value]}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="sr-only">{s.visibility}</span>
          <select value={visibility ?? ''} onChange={(event) => update({ visibility: event.target.value || undefined })} className={`${fieldClass} bg-ink-900`}>
            <option value="">{s.allVisibility}</option>
            <option value="visible">{s.visible}</option>
            <option value="hidden">{s.hidden}</option>
          </select>
        </label>
      </div>

      <ListPanel
        label={s.title}
        list={list}
        filtered={Boolean(q || group || visibility)}
        onClear={clear}
        onPage={(next) => update({ page: next > 1 ? String(next) : undefined })}
        texts={s}
        testId="technologies"
      >
        {(technologies) => (
          <table className="w-full min-w-[44rem] text-sm">
            <thead>
              <tr className="text-xs text-slate-500">
                {(['name', 'group', 'icon', 'status', 'projects', 'updated'] as const).map((column) => (
                  <th key={column} scope="col" className={th}>
                    {s.columns[column]}
                  </th>
                ))}
                <th scope="col" className={`${th} text-end`}>
                  {s.columns.actions}
                </th>
              </tr>
            </thead>
            <tbody>
              {technologies.map((technology) => {
                const translated = technology.translations[locale]?.display_name
                return (
                  <tr key={technology.id} className="border-t border-white/5 transition hover:bg-white/[0.03]">
                    <td className={td}>
                      <span dir="auto" className="block font-medium text-slate-100">
                        {technology.name}
                      </span>
                      {translated && translated !== technology.name && (
                        <span dir="auto" lang={locale} className="block text-xs text-slate-400">
                          {translated}
                        </span>
                      )}
                      <span dir="ltr" className="block font-mono text-xs text-slate-500">
                        {technology.slug}
                      </span>
                    </td>
                    <td className={`${td} text-slate-300`}>{t.skills.groups[technology.group]}</td>
                    <td className={td}>
                      {technology.icon ? (
                        <code dir="ltr" className="rounded-md border border-white/10 bg-white/[0.04] px-1.5 py-0.5 font-mono text-xs text-slate-200">
                          {technology.icon}
                        </code>
                      ) : (
                        <span className="text-slate-500">{s.noIcon}</span>
                      )}
                    </td>
                    <td className={td}>
                      <VisibilityBadge visible={technology.is_visible} />
                    </td>
                    <td className={`${td} text-slate-300`}>
                      <span title={technology.in_use ? c.linkedProjects(technology.projects_count) : c.notLinked}>{technology.projects_count}</span>
                    </td>
                    <td className={`${td} whitespace-nowrap text-slate-400`}>
                      {technology.updated_at ? <time dateTime={technology.updated_at}>{formatDate(technology.updated_at, locale)}</time> : '—'}
                    </td>
                    <td className={td}>
                      <div className="flex justify-end">
                        <Link to={`/admin/technologies/${technology.id}/edit`} className={buttonGhost} aria-label={`${c.edit}: ${technology.name}`}>
                          {c.edit}
                        </Link>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </ListPanel>
    </div>
  )
}
