import { Link } from 'react-router'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { ListPanel, MessageStatusBadge, SearchField, td, th, useListParams } from '../catalog/ui'
import { useAdminText } from '../i18n'
import { listMessages, type MessageStatus } from '../messagesApi'
import { useAdminPage } from '../pageTitle'
import { fieldClass } from '../projects/ui'
import { useAdminData } from '../useAdminData'

const PER_PAGE = 15
const STATUSES: MessageStatus[] = ['unread', 'read', 'archived']

export function AdminMessagesPage() {
  const s = useAdminText().messages
  const { locale } = useI18n()
  useAdminPage(s.title)

  const { params, q, page, search, setSearch, update, clear } = useListParams()
  const rawStatus = params.get('status')
  const status = STATUSES.includes(rawStatus as MessageStatus) ? (rawStatus as MessageStatus) : undefined

  const list = useAdminData(`admin-messages:${q}:${status ?? ''}:${page}`, (signal) =>
    listMessages({ q: q || undefined, status, page, perPage: PER_PAGE }, { signal }),
  )
  const unread = list.data?.unread_count

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-2xl text-sm text-slate-400">{s.intro}</p>
        {unread !== undefined && (
          <p role="status" className={`rounded-full border px-3 py-1 text-sm ${unread > 0 ? 'border-cyan-300/30 bg-cyan-300/10 text-cyan-100' : 'border-white/10 text-slate-400'}`}>
            {s.unreadCount(unread)}
          </p>
        )}
      </div>

      <div role="search" className="glass grid gap-3 rounded-3xl p-4 sm:grid-cols-[minmax(0,1fr)_13rem]">
        <SearchField value={search} onChange={setSearch} label={s.search} placeholder={s.searchPlaceholder} />
        <label className="block">
          <span className="sr-only">{s.status}</span>
          <select value={status ?? ''} onChange={(event) => update({ status: event.target.value || undefined })} className={`${fieldClass} bg-ink-900`}>
            <option value="">{s.allStatuses}</option>
            {STATUSES.map((value) => (
              <option key={value} value={value}>
                {s.statuses[value]}
              </option>
            ))}
          </select>
        </label>
      </div>

      <ListPanel
        label={s.title}
        list={list}
        filtered={Boolean(q || status)}
        onClear={clear}
        onPage={(next) => update({ page: next > 1 ? String(next) : undefined })}
        texts={s}
        testId="messages"
      >
        {(messages) => (
          <table className="w-full min-w-[40rem] text-sm">
            <thead>
              <tr className="text-xs text-slate-500">
                {(['from', 'subject', 'received', 'status'] as const).map((column) => (
                  <th key={column} scope="col" className={th}>
                    {s.columns[column]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {messages.map((message) => {
                const unreadRow = message.status === 'unread'
                return (
                  <tr key={message.id} className={`border-t border-white/5 transition hover:bg-white/[0.03] ${unreadRow ? 'bg-cyan-300/[0.03]' : ''}`}>
                    <td className={`${td} max-w-[14rem]`}>
                      <Link
                        to={`/admin/messages/${message.id}`}
                        aria-label={s.open(message.name)}
                        className={`block truncate hover:text-cyan-200 ${unreadRow ? 'font-semibold text-white' : 'text-slate-200'}`}
                      >
                        <span dir="auto">{message.name}</span>
                      </Link>
                      <span dir="ltr" className="block truncate text-xs text-slate-500">
                        {message.email}
                      </span>
                    </td>
                    <td className={`${td} max-w-[22rem]`}>
                      <span dir="auto" className={`block truncate ${unreadRow ? 'font-medium text-slate-100' : 'text-slate-300'}`}>
                        {message.subject || s.noSubject}
                      </span>
                      <span dir="auto" className="block truncate text-xs text-slate-500">
                        {message.excerpt}
                      </span>
                    </td>
                    <td className={`${td} whitespace-nowrap text-slate-400`}>
                      {message.created_at ? <time dateTime={message.created_at}>{formatDate(message.created_at, locale)}</time> : '—'}
                    </td>
                    <td className={td}>
                      <MessageStatusBadge status={message.status} />
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </ListPanel>
    </div>
  )
}
