import { useEffect, useId, useState } from 'react'
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router'
import { ApiError } from '../../api/client'
import { EmptyState, Skeleton } from '../../components/ui/DataStates'
import type { Locale } from '../../i18n/config'
import { otherLocale } from '../../i18n/config'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { useAdminAuth } from '../AdminAuth'
import { useAdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, fieldClass, LanguageChips, Notice, StatusBadge } from '../projects/ui'
import {
  getProjectOptions,
  listProjects,
  setProjectStatus,
  type AdminProjectListItem,
  type ByLocale,
  type ProjectStatus,
} from '../projectsApi'
import { useAdminData } from '../useAdminData'

const PER_PAGE = 10

/** Title in the interface language, else the other language. */
export function projectTitle(title: ByLocale<string | null>, locale: Locale): string | null {
  return title[locale] ?? title[otherLocale(locale)] ?? null
}

function readFilters(params: URLSearchParams) {
  const status = params.get('status')
  const category = Number(params.get('category'))
  const page = Number(params.get('page'))
  return {
    q: (params.get('q') ?? '').slice(0, 100),
    status: status === 'draft' || status === 'published' ? (status as ProjectStatus) : undefined,
    category: Number.isInteger(category) && category > 0 ? category : undefined,
    page: Number.isInteger(page) && page > 1 ? page : 1,
  }
}

export function AdminProjectsPage() {
  const a = useAdminText()
  const { locale } = useI18n()
  const { handleAuthError } = useAdminAuth()
  useAdminPage(a.projects.title)

  const [params, setParams] = useSearchParams()
  const filters = readFilters(params)
  const location = useLocation()
  const navigate = useNavigate()
  const ids = useId()

  // Success message handed over by the form after saving (shown once).
  const [notice, setNotice] = useState<{ tone: 'success' | 'error'; text: string } | null>(() => {
    const flash = (location.state as { flash?: string } | null)?.flash
    return flash ? { tone: 'success', text: flash } : null
  })
  useEffect(() => {
    if ((location.state as { flash?: string } | null)?.flash) navigate(`${location.pathname}${location.search}`, { replace: true, state: null })
  }, [location, navigate])

  const [search, setSearch] = useState(filters.q)
  const update = (changes: Partial<Record<'q' | 'status' | 'category' | 'page', string | undefined>>) => {
    const next = new URLSearchParams(params)
    for (const [key, value] of Object.entries(changes)) {
      if (value) next.set(key, value)
      else next.delete(key)
    }
    if (!('page' in changes)) next.delete('page')
    setParams(next)
  }

  // Search as you type, after a short pause.
  useEffect(() => {
    const value = search.trim()
    if (value === filters.q) return
    const timer = window.setTimeout(() => {
      const next = new URLSearchParams(params)
      if (value) next.set('q', value)
      else next.delete('q')
      next.delete('page')
      setParams(next)
    }, 350)
    return () => window.clearTimeout(timer)
  }, [search, filters.q, params, setParams])

  const key = `admin-projects:${filters.q}:${filters.status ?? ''}:${filters.category ?? ''}:${filters.page}`
  const list = useAdminData(key, (signal) =>
    listProjects({ q: filters.q || undefined, status: filters.status, category: filters.category, page: filters.page, perPage: PER_PAGE }, { signal }),
  )
  const options = useAdminData('admin-project-options', (signal) => getProjectOptions({ signal }))

  const [working, setWorking] = useState<number | null>(null)
  const toggleStatus = async (project: AdminProjectListItem) => {
    const next: ProjectStatus = project.status === 'published' ? 'draft' : 'published'
    const title = projectTitle(project.title, locale) ?? a.projects.untitled
    setWorking(project.id)
    setNotice(null)
    try {
      const updated = await setProjectStatus(project.id, next)
      list.setData((current) => ({ ...current, data: current.data.map((item) => (item.id === updated.id ? updated : item)) }))
      setNotice({ tone: 'success', text: next === 'published' ? a.projects.published(title) : a.projects.unpublished(title) })
    } catch (error) {
      if (handleAuthError(error)) return
      const blocked = error instanceof ApiError && error.kind === 'validation'
      setNotice({ tone: 'error', text: blocked ? a.projects.publishBlocked : a.projects.actionFailed })
    } finally {
      setWorking(null)
    }
  }

  const filtered = Boolean(filters.q || filters.status || filters.category)
  const meta = list.data?.meta
  const projects = list.data?.data ?? []

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-2xl text-sm text-slate-400">{a.projects.intro}</p>
        <Link to="/admin/projects/new" className={buttonPrimary}>
          <span aria-hidden="true" className="text-base leading-none">+</span>
          {a.projects.add}
        </Link>
      </div>

      {notice && (
        <Notice tone={notice.tone} onDismiss={() => setNotice(null)} dismissLabel={a.projects.dismiss}>
          {notice.text}
        </Notice>
      )}

      <div role="search" className="glass grid gap-3 rounded-3xl p-4 sm:grid-cols-[minmax(0,1fr)_12rem_14rem]">
        <label className="block">
          <span className="sr-only">{a.projects.search}</span>
          <input
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder={a.projects.searchPlaceholder}
            maxLength={100}
            className={fieldClass}
          />
        </label>
        <label className="block">
          <span className="sr-only">{a.projects.status}</span>
          <select
            id={`${ids}-status`}
            value={filters.status ?? ''}
            onChange={(event) => update({ status: event.target.value || undefined })}
            className={`${fieldClass} bg-ink-900`}
          >
            <option value="">{a.projects.allStatuses}</option>
            <option value="published">{a.projects.statuses.published}</option>
            <option value="draft">{a.projects.statuses.draft}</option>
          </select>
        </label>
        <label className="block">
          <span className="sr-only">{a.projects.category}</span>
          <select
            value={filters.category ? String(filters.category) : ''}
            onChange={(event) => update({ category: event.target.value || undefined })}
            className={`${fieldClass} bg-ink-900`}
          >
            <option value="">{a.projects.allCategories}</option>
            {(options.data?.categories ?? []).map((category) => (
              <option key={category.id} value={category.id}>
                {projectTitle(category.name, locale) ?? `#${category.id}`}
              </option>
            ))}
          </select>
        </label>
      </div>

      <section aria-label={a.projects.title} className="glass min-w-0 rounded-3xl">
        {list.status === 'loading' && (
          <div data-testid="projects-loading" className="space-y-3 p-5" aria-busy="true">
            {[0, 1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        )}

        {list.status === 'error' && (
          <div className="p-5">
            <Notice tone="error">
              {a.projects.loadFailed}{' '}
              <button type="button" onClick={list.reload} className="font-semibold underline underline-offset-4">
                {a.projects.retry}
              </button>
            </Notice>
          </div>
        )}

        {list.status === 'success' && projects.length === 0 && (
          <div className="flex flex-col items-center gap-4 p-5">
            <div className="w-full">
              <EmptyState>{filtered ? a.projects.noResults : a.projects.empty}</EmptyState>
            </div>
            {filtered && (
              <button
                type="button"
                className={buttonGhost}
                onClick={() => {
                  setSearch('')
                  setParams(new URLSearchParams())
                }}
              >
                {a.projects.clearFilters}
              </button>
            )}
          </div>
        )}

        {list.status === 'success' && projects.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[40rem] text-sm">
              <thead>
                <tr className="text-xs text-slate-500">
                  {(['project', 'languages', 'categories', 'status', 'updated'] as const).map((column) => (
                    <th key={column} scope="col" className="px-4 py-3 text-start font-medium">
                      {a.projects.columns[column]}
                    </th>
                  ))}
                  <th scope="col" className="px-4 py-3 text-end font-medium">
                    {a.projects.columns.actions}
                  </th>
                </tr>
              </thead>
              <tbody>
                {projects.map((project) => {
                  const title = projectTitle(project.title, locale)
                  return (
                    <tr key={project.id} className="border-t border-white/5 transition hover:bg-white/[0.03]">
                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-100">{title ?? a.projects.untitled}</span>
                        {project.is_featured && <span className="ms-2 text-xs text-cyan-300" aria-label={a.projects.form.featured}>★</span>}
                      </td>
                      <td className="px-4 py-3">
                        <LanguageChips complete={project.complete} />
                      </td>
                      <td className="px-4 py-3 text-slate-400">
                        {project.categories.map((category) => projectTitle(category.name, locale)).filter(Boolean).join(locale === 'ar' ? '، ' : ', ') || '—'}
                      </td>
                      <td className="px-4 py-3">
                        <StatusBadge status={project.status} />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-slate-400">
                        {project.updated_at ? <time dateTime={project.updated_at}>{formatDate(project.updated_at, locale)}</time> : '—'}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap justify-end gap-2">
                          <Link to={`/admin/projects/${project.id}/edit`} className={buttonGhost} aria-label={`${a.projects.edit}: ${title ?? a.projects.untitled}`}>
                            {a.projects.edit}
                          </Link>
                          <button
                            type="button"
                            onClick={() => toggleStatus(project)}
                            disabled={working !== null}
                            aria-busy={working === project.id}
                            aria-label={`${project.status === 'published' ? a.projects.unpublish : a.projects.publish}: ${title ?? a.projects.untitled}`}
                            className={buttonGhost}
                          >
                            {working === project.id ? a.projects.working : project.status === 'published' ? a.projects.unpublish : a.projects.publish}
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {meta && meta.total > 0 && (
          <nav aria-label={a.projects.pageOf(meta.current_page, meta.last_page)} className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 px-4 py-3 text-sm text-slate-400">
            <p>
              {a.projects.total(meta.total)} · {a.projects.pageOf(meta.current_page, meta.last_page)}
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                className={buttonGhost}
                disabled={meta.current_page <= 1}
                onClick={() => update({ page: meta.current_page - 1 > 1 ? String(meta.current_page - 1) : undefined })}
              >
                {a.projects.previous}
              </button>
              <button
                type="button"
                className={buttonGhost}
                disabled={meta.current_page >= meta.last_page}
                onClick={() => update({ page: String(meta.current_page + 1) })}
              >
                {a.projects.next}
              </button>
            </div>
          </nav>
        )}
      </section>
    </div>
  )
}
