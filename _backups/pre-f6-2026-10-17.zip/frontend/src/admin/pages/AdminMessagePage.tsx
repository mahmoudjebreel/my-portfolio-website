import { useState } from 'react'
import { useParams } from 'react-router'
import { ApiError } from '../../api/client'
import { Skeleton } from '../../components/ui/DataStates'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { useAdminAuth } from '../AdminAuth'
import { BackLink, MessageStatusBadge, type Flash } from '../catalog/ui'
import { useAdminText } from '../i18n'
import { getMessage, replyLink, setMessageStatus } from '../messagesApi'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, Notice } from '../projects/ui'
import { useAdminData } from '../useAdminData'

/**
 * One contact message. The visitor's text is rendered as plain text (React text nodes,
 * whitespace kept) — never as HTML. Opening the page does not change the message; only the
 * read / unread button does.
 */
export function AdminMessagePage() {
  const a = useAdminText()
  const s = a.messages
  const { locale } = useI18n()
  const { handleAuthError } = useAdminAuth()
  const { id } = useParams()
  const messageId = Number(id)
  const validId = Number.isInteger(messageId) && messageId > 0
  useAdminPage(s.title)

  const detail = useAdminData(validId ? `admin-message:${messageId}` : null, (signal) => getMessage(messageId, { signal }))
  const [notice, setNotice] = useState<Flash>(null)
  const [working, setWorking] = useState(false)
  const back = <BackLink to="/admin/messages">{s.back}</BackLink>

  if (!validId || detail.status === 'error') {
    const notFound = !validId || detail.error?.kind === 'not_found'
    return (
      <div className="mx-auto max-w-3xl space-y-6">
        {back}
        <Notice tone="error">
          {notFound ? s.notFound : s.detailFailed}{' '}
          {!notFound && (
            <button type="button" onClick={detail.reload} className="font-semibold underline underline-offset-4">
              {a.catalog.retry}
            </button>
          )}
        </Notice>
      </div>
    )
  }

  if (detail.status !== 'success' || !detail.data) {
    return (
      <div data-testid="message-loading" className="mx-auto max-w-3xl space-y-4" aria-busy="true">
        {back}
        <Skeleton className="h-72 w-full rounded-3xl" />
      </div>
    )
  }

  const message = detail.data.data
  const next = message.status === 'unread' ? 'read' : 'unread'

  const toggle = async () => {
    setWorking(true)
    setNotice(null)
    try {
      const updated = await setMessageStatus(message.id, next)
      detail.setData(() => updated)
      setNotice({ tone: 'success', text: next === 'read' ? s.markedRead : s.markedUnread })
    } catch (error) {
      if (handleAuthError(error)) return
      const archived = error instanceof ApiError && error.status === 409
      setNotice({ tone: 'error', text: archived ? s.archivedNote : s.actionFailed })
    } finally {
      setWorking(false)
    }
  }

  const facts: [string, string | null][] = [
    [s.received, message.created_at ? formatDate(message.created_at, locale) : null],
    [s.language, message.locale ? s.languages[message.locale] : null],
    [s.readAt, message.read_at ? formatDate(message.read_at, locale) : null],
  ]

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      {back}

      {notice && (
        <Notice tone={notice.tone} onDismiss={() => setNotice(null)} dismissLabel={a.catalog.dismiss}>
          {notice.text}
        </Notice>
      )}

      <article aria-labelledby="message-subject" className="glass space-y-6 rounded-3xl p-5 sm:p-7">
        <header className="space-y-3">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <h2 id="message-subject" dir="auto" className="min-w-0 font-display text-xl font-semibold break-words text-white">
              {message.subject || s.noSubject}
            </h2>
            <MessageStatusBadge status={message.status} />
          </div>
          <p className="text-sm text-slate-300">
            <span dir="auto" className="font-medium text-slate-100">
              {message.name}
            </span>{' '}
            <span className="text-slate-500">·</span>{' '}
            <span dir="ltr" className="break-all">
              {message.email}
            </span>
          </p>
          <dl className="grid gap-2 text-sm sm:grid-cols-3">
            {facts.map(([label, value]) => (
              <div key={label}>
                <dt className="text-xs text-slate-500">{label}</dt>
                <dd className="text-slate-200">{value ?? '—'}</dd>
              </div>
            ))}
          </dl>
        </header>

        <div
          data-testid="message-body"
          dir="auto"
          lang={message.locale ?? undefined}
          className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-sm leading-relaxed break-words whitespace-pre-wrap text-slate-100"
        >
          {message.message}
        </div>

        <footer className="flex flex-wrap items-center gap-3 border-t border-white/10 pt-5">
          {message.reply_email ? (
            <a href={replyLink(message.reply_email, message.subject)} className={buttonPrimary}>
              {s.reply}
            </a>
          ) : (
            <p className="text-xs text-amber-200">{s.noReply}</p>
          )}
          {message.status !== 'archived' ? (
            <button type="button" onClick={toggle} disabled={working} aria-busy={working} className={buttonGhost}>
              {working ? s.working : next === 'read' ? s.markRead : s.markUnread}
            </button>
          ) : (
            <p className="text-xs text-slate-400">{s.archivedNote}</p>
          )}
          {message.reply_email && <p className="w-full text-xs text-slate-500">{s.replyNote}</p>}
          <p className="w-full text-xs text-slate-500">{s.keptNote}</p>
        </footer>
      </article>
    </div>
  )
}
