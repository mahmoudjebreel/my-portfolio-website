import { useId, useState, type FormEvent } from 'react'
import { Link } from 'react-router'
import { ApiError } from '../../api/client'
import type { Locale } from '../../i18n/config'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { useAdminAuth } from '../AdminAuth'
import { Card, ListPanel, SearchField, type Errors, type Flash, useListParams } from '../catalog/ui'
import { useAdminText } from '../i18n'
import {
  listMedia,
  uploadMedia,
  UPLOAD_EXTENSIONS,
  UPLOAD_MAX_BYTES,
  UPLOAD_TYPES,
  type AdminMediaItem,
  type MediaKind,
  type MediaProjectOption,
} from '../mediaApi'
import { useAdminPage } from '../pageTitle'
import { buttonPrimary, fieldClass, Notice } from '../projects/ui'
import type { ByLocale } from '../projectsApi'
import { useAdminData } from '../useAdminData'

const PER_PAGE = 12
const LOCALES: Locale[] = ['en', 'ar']

const titleIn = (title: ByLocale<string | null>, locale: Locale) => title[locale] ?? title[locale === 'en' ? 'ar' : 'en'] ?? null

export function AdminMediaPage() {
  const a = useAdminText()
  const m = a.media
  const { locale } = useI18n()
  useAdminPage(m.title)

  const { params, q, page, search, setSearch, update, clear } = useListParams()
  const rawProject = Number(params.get('project'))
  const project = Number.isInteger(rawProject) && rawProject > 0 ? rawProject : undefined
  const rawKind = params.get('kind')
  const kind = rawKind === 'cover' || rawKind === 'gallery' ? (rawKind as MediaKind) : undefined

  const list = useAdminData(`admin-media:${q}:${project ?? ''}:${kind ?? ''}:${page}`, (signal) =>
    listMedia({ q: q || undefined, project, kind, page, perPage: PER_PAGE }, { signal }),
  )
  const [projects, setProjects] = useState<MediaProjectOption[]>([])
  // Keep the project choices while another page or filter is loading.
  const latestProjects = list.data?.projects
  if (latestProjects && latestProjects !== projects) setProjects(latestProjects)

  const [selectedKey, setSelectedKey] = useState<string | null>(null)
  const [notice, setNotice] = useState<Flash>(null)
  const [uploading, setUploading] = useState(false)
  const items = list.data?.data ?? []
  const selected = items.find((item) => item.key === selectedKey) ?? null

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-2xl text-sm text-slate-400">{m.intro}</p>
        <button type="button" className={buttonPrimary} aria-expanded={uploading} onClick={() => setUploading((open) => !open)}>
          <span aria-hidden="true" className="text-base leading-none">{uploading ? '×' : '+'}</span>
          {uploading ? m.closeUpload : m.upload}
        </button>
      </div>

      {notice && (
        <Notice tone={notice.tone} onDismiss={() => setNotice(null)} dismissLabel={a.catalog.dismiss}>
          {notice.text}
        </Notice>
      )}

      {uploading && (
        <UploadForm
          projects={projects}
          defaultProject={project}
          onUploaded={(item) => {
            setUploading(false)
            setNotice({ tone: 'success', text: m.form.uploaded(titleIn(item.project.title, locale) ?? m.untitled) })
            setSelectedKey(item.key)
            list.reload()
          }}
        />
      )}

      <div role="search" className="glass grid gap-3 rounded-3xl p-4 sm:grid-cols-[minmax(0,1fr)_14rem_12rem]">
        <SearchField value={search} onChange={setSearch} label={m.search} placeholder={m.searchPlaceholder} />
        <label className="block">
          <span className="sr-only">{m.project}</span>
          <select value={project ? String(project) : ''} onChange={(event) => update({ project: event.target.value || undefined })} className={`${fieldClass} bg-ink-900`}>
            <option value="">{m.allProjects}</option>
            {projects.map((option) => (
              <option key={option.id} value={option.id}>
                {titleIn(option.title, locale) ?? `#${option.id}`}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="sr-only">{m.kind}</span>
          <select value={kind ?? ''} onChange={(event) => update({ kind: event.target.value || undefined })} className={`${fieldClass} bg-ink-900`}>
            <option value="">{m.allKinds}</option>
            <option value="cover">{m.kinds.cover}</option>
            <option value="gallery">{m.kinds.gallery}</option>
          </select>
        </label>
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <ListPanel
          label={m.title}
          list={list}
          filtered={Boolean(q || project || kind)}
          onClear={clear}
          onPage={(next) => update({ page: next > 1 ? String(next) : undefined })}
          texts={m}
          testId="media"
        >
          {(media) => (
            <ul className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-3">
              {media.map((item) => (
                <li key={item.key}>
                  <MediaTile item={item} selected={item.key === selectedKey} onSelect={() => setSelectedKey(item.key)} />
                </li>
              ))}
            </ul>
          )}
        </ListPanel>

        <aside className="min-w-0">
          <div className="lg:sticky lg:top-24">{selected ? <MediaDetails item={selected} /> : <p className="glass rounded-3xl p-5 text-sm text-slate-400">{m.noSelection}</p>}</div>
        </aside>
      </div>
    </div>
  )
}

function MediaTile({ item, selected, onSelect }: { item: AdminMediaItem; selected: boolean; onSelect: () => void }) {
  const m = useAdminText().media
  const { locale } = useI18n()
  const name = item.file_name ?? m.unavailable
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      aria-label={m.select(name)}
      className={`group block w-full overflow-hidden rounded-2xl border text-start transition ${
        selected ? 'border-cyan-300/60 bg-cyan-300/[0.06]' : 'border-white/10 bg-white/[0.03] hover:border-white/25'
      }`}
    >
      <Thumbnail item={item} className="aspect-[4/3]" />
      <span className="block space-y-1 p-3">
        <span dir="ltr" className="block truncate font-mono text-xs text-slate-200">
          {name}
        </span>
        <span className="flex items-center justify-between gap-2 text-xs text-slate-400">
          <span className="truncate">{titleIn(item.project.title, locale) ?? m.untitled}</span>
          <span className="shrink-0 rounded-full border border-white/10 px-2 py-0.5 text-[0.7rem]">{m.kinds[item.kind]}</span>
        </span>
      </span>
    </button>
  )
}

function Thumbnail({ item, className = '' }: { item: AdminMediaItem; className?: string }) {
  const m = useAdminText().media
  const { locale } = useI18n()
  if (!item.preview_url) {
    return <span className={`grid place-items-center bg-white/[0.04] px-2 text-center text-xs text-slate-500 ${className}`}>{m.unavailable}</span>
  }
  return <img src={item.preview_url} alt={item.alt[locale] ?? ''} loading="lazy" decoding="async" className={`w-full bg-white/[0.04] object-cover ${className}`} />
}

function MediaDetails({ item }: { item: AdminMediaItem }) {
  const a = useAdminText()
  const m = a.media
  const { locale } = useI18n()
  const rows: [string, string | null][] = [
    [m.fileName, item.file_name],
    [m.kind, m.kinds[item.kind]],
    [m.type, item.mime_type],
    [m.size, item.size !== null ? m.bytes(item.size) : null],
    [m.dimensions, item.width && item.height ? `${item.width} × ${item.height}` : null],
    [m.updated, item.updated_at ? formatDate(item.updated_at, locale) : null],
  ]

  return (
    <section aria-label={m.details} className="glass space-y-4 rounded-3xl p-5">
      <h2 className="font-display text-lg font-semibold text-white">{m.details}</h2>
      <Thumbnail item={item} className="max-h-64 rounded-xl object-contain" />
      {!item.available && <p className="text-xs text-amber-200">{m.missingNote}</p>}
      <dl className="space-y-2 text-sm">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between gap-3">
            <dt className="text-slate-400">{label}</dt>
            <dd dir="auto" className="min-w-0 truncate text-end text-slate-100">
              {value ?? '—'}
            </dd>
          </div>
        ))}
        <div className="flex justify-between gap-3">
          <dt className="text-slate-400">{m.linkedProject}</dt>
          <dd className="min-w-0 text-end">
            <Link to={`/admin/projects/${item.project.id}/edit`} className="text-cyan-300 underline-offset-4 hover:underline">
              {titleIn(item.project.title, locale) ?? m.untitled}
            </Link>
          </dd>
        </div>
      </dl>
      <div className="space-y-2 border-t border-white/10 pt-4 text-sm">
        {LOCALES.map((lang) => (
          <div key={lang}>
            <p className="text-xs text-slate-400">{m.altText(lang === 'en' ? a.catalog.english : a.catalog.arabic)}</p>
            <p lang={lang} dir={lang === 'ar' ? 'rtl' : 'ltr'} className={item.alt[lang] ? 'text-slate-100' : 'text-slate-500 italic'}>
              {item.alt[lang] ?? m.noAlt}
            </p>
          </div>
        ))}
      </div>
      <p className="border-t border-white/10 pt-4 text-xs text-slate-400">{m.keptNote}</p>
    </section>
  )
}

function UploadForm({ projects, defaultProject, onUploaded }: { projects: MediaProjectOption[]; defaultProject?: number; onUploaded: (item: AdminMediaItem) => void }) {
  const a = useAdminText()
  const f = a.media.form
  const { locale } = useI18n()
  const { handleAuthError } = useAdminAuth()
  const formId = useId()
  const [projectId, setProjectId] = useState(defaultProject ? String(defaultProject) : '')
  const [file, setFile] = useState<File | null>(null)
  const [alt, setAlt] = useState<ByLocale<string>>({ en: '', ar: '' })
  const [errors, setErrors] = useState<Errors>({})
  const [failure, setFailure] = useState<string | null>(null)
  const [sending, setSending] = useState(false)

  const validate = (): Errors => {
    const next: Errors = {}
    if (!projectId) next.project_id = f.required
    if (!file) next.file = f.required
    else if (!UPLOAD_TYPES.includes(file.type) && !UPLOAD_EXTENSIONS.test(file.name)) next.file = f.invalidType
    else if (file.size > UPLOAD_MAX_BYTES) next.file = f.tooLarge
    for (const lang of LOCALES) if (alt[lang].trim().length > 200) next[`alt.${lang}`] = f.tooLong
    return next
  }

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (sending) return
    const next = validate()
    setErrors(next)
    setFailure(null)
    if (Object.keys(next).length > 0) return

    setSending(true)
    try {
      const item = await uploadMedia({ projectId: Number(projectId), file: file!, alt })
      onUploaded(item)
    } catch (error) {
      setSending(false)
      if (handleAuthError(error)) return
      if (error instanceof ApiError && error.kind === 'validation') {
        const mapped: Errors = {}
        for (const [key, messages] of Object.entries(error.fieldErrors)) {
          const message = (messages[0] ?? '').toLowerCase()
          if (key === 'file') {
            mapped.file = message.includes('5 mb')
              ? f.tooLarge
              : message.includes('only')
                ? f.invalidType
                : message.includes('server allows') || message.includes('failed to upload')
                  ? f.serverLimit
                  : f.invalidImage
          } else if (key === 'project_id') mapped.project_id = f.required
          else mapped[key] = f.tooLong
        }
        setErrors(mapped)
      } else if (error instanceof ApiError && error.status === 413) {
        setErrors({ file: f.serverLimit })
      } else {
        setFailure(f.failed)
      }
    }
  }

  const describe = (key: string) => (errors[key] ? `${formId}-${key}-error` : undefined)
  const errorText = (key: string) =>
    errors[key] ? (
      <p id={`${formId}-${key}-error`} className="mt-1 text-xs text-rose-300">
        {errors[key]}
      </p>
    ) : null

  return (
    <Card title={f.title} labelledBy={`${formId}-title`}>
      <form noValidate onSubmit={onSubmit} className="space-y-4">
        <p className="text-sm text-slate-400">{f.help}</p>
        {failure && <Notice tone="error">{failure}</Notice>}
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label htmlFor={`${formId}-project`} className="mb-1.5 block text-sm font-medium text-slate-200">
              {f.project}
            </label>
            <select
              id={`${formId}-project`}
              value={projectId}
              onChange={(event) => setProjectId(event.target.value)}
              aria-invalid={Boolean(errors.project_id)}
              aria-describedby={describe('project_id')}
              className={`${fieldClass} bg-ink-900`}
            >
              <option value="">{f.chooseProject}</option>
              {projects.map((option) => (
                <option key={option.id} value={option.id}>
                  {titleIn(option.title, locale) ?? `#${option.id}`}
                </option>
              ))}
            </select>
            {errorText('project_id')}
          </div>
          <div>
            <label htmlFor={`${formId}-file`} className="mb-1.5 block text-sm font-medium text-slate-200">
              {f.file}
            </label>
            <input
              id={`${formId}-file`}
              type="file"
              accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
              onChange={(event) => setFile(event.target.files?.[0] ?? null)}
              aria-invalid={Boolean(errors.file)}
              aria-describedby={describe('file')}
              className={`${fieldClass} file:me-3 file:rounded-full file:border-0 file:bg-white/10 file:px-3 file:py-1 file:text-sm file:text-white`}
            />
            {errorText('file')}
          </div>
          {LOCALES.map((lang) => (
            <div key={lang}>
              <label htmlFor={`${formId}-alt-${lang}`} className="mb-1.5 block text-sm font-medium text-slate-200">
                {a.media.altText(lang === 'en' ? a.catalog.english : a.catalog.arabic)}
                <span className="ms-1.5 text-xs font-normal text-slate-500">({a.catalog.optional})</span>
              </label>
              <input
                id={`${formId}-alt-${lang}`}
                value={alt[lang]}
                onChange={(event) => setAlt((current) => ({ ...current, [lang]: event.target.value }))}
                dir={lang === 'ar' ? 'rtl' : 'ltr'}
                lang={lang}
                maxLength={250}
                aria-invalid={Boolean(errors[`alt.${lang}`])}
                aria-describedby={describe(`alt.${lang}`)}
                className={fieldClass}
              />
              {errorText(`alt.${lang}`)}
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500">{f.altHelp}</p>
        <div className="flex justify-end">
          <button type="submit" disabled={sending} aria-busy={sending} className={buttonPrimary}>
            {sending ? f.uploading : f.submit}
          </button>
        </div>
      </form>
    </Card>
  )
}
