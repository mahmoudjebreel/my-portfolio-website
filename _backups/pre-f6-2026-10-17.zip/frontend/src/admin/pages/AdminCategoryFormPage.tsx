import { useId, useState, type FormEvent } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { ApiError } from '../../api/client'
import { Skeleton } from '../../components/ui/DataStates'
import type { Locale } from '../../i18n/config'
import { useAdminAuth } from '../AdminAuth'
import { createCategory, getCategory, updateCategory, type AdminCategory, type CategoryPayload } from '../catalogApi'
import { BackLink, Card, focusFirstError, isSortOrder, mapServerErrors, TextField, UsageCard, type Errors } from '../catalog/ui'
import { useAdminText, type AdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, Notice } from '../projects/ui'
import { SLUG_PATTERN, slugify, type ByLocale } from '../projectsApi'
import { useAdminData } from '../useAdminData'

const LOCALES: Locale[] = ['en', 'ar']
/** Same limits as backend/app/Http/Requests/Admin/CategoryRequest.php. */
const MAX = { name: 80, slug: 100 }

type Names = { name: string; slug: string }
interface FormState {
  sort_order: string
  translations: ByLocale<Names>
}

const filled = (names: Names) => names.name.trim() !== '' || names.slug.trim() !== ''

/** Mirrors the server rules (the server stays the authority). */
function validate(form: FormState, detail: AdminCategory | undefined, a: AdminText): Errors {
  const c = a.catalog
  const errors: Errors = {}
  for (const locale of LOCALES) {
    const names = form.translations[locale]
    const stored = detail?.translations[locale]
    const required = filled(names) || Boolean(stored)
    const name = names.name.trim()
    const slug = names.slug.trim()
    const key = `translations.${locale}`

    if (!name) {
      if (required) errors[`${key}.name`] = c.required
    } else if (name.length > MAX.name) errors[`${key}.name`] = c.tooLong(MAX.name)

    if (!slug) {
      if (required) errors[`${key}.slug`] = c.required
    } else if (slug.length > MAX.slug) errors[`${key}.slug`] = c.tooLong(MAX.slug)
    else if (slug !== stored?.slug && !SLUG_PATTERN.test(slug)) errors[`${key}.slug`] = c.invalidSlug
  }
  if (!LOCALES.some((locale) => filled(form.translations[locale]))) errors.translations = a.categories.form.oneLanguage
  if (!isSortOrder(form.sort_order)) errors.sort_order = c.invalidNumber
  return errors
}

function toPayload(form: FormState): CategoryPayload {
  const translations = {} as CategoryPayload['translations']
  for (const locale of LOCALES) {
    const names = form.translations[locale]
    translations[locale] = filled(names) ? { name: names.name.trim(), slug: names.slug.trim() } : null
  }
  return { sort_order: Number(form.sort_order), translations }
}

export function AdminCategoryFormPage() {
  const a = useAdminText()
  const f = a.categories.form
  const { id } = useParams()
  const editing = id !== undefined
  const categoryId = Number(id)
  const validId = !editing || (Number.isInteger(categoryId) && categoryId > 0)
  useAdminPage(editing ? a.categories.editTitle : a.categories.newTitle)

  const detail = useAdminData(editing && validId ? `admin-category:${categoryId}` : null, (signal) => getCategory(categoryId, { signal }))
  const back = <BackLink to="/admin/categories">{f.back}</BackLink>

  if (!validId || (editing && detail.status === 'error')) {
    const notFound = !validId || detail.error?.kind === 'not_found'
    return (
      <div className="mx-auto max-w-3xl space-y-6">
        {back}
        <Notice tone="error">
          {notFound ? f.notFound : f.loadFailed}{' '}
          {!notFound && (
            <button type="button" onClick={detail.reload} className="font-semibold underline underline-offset-4">
              {a.catalog.retry}
            </button>
          )}
        </Notice>
      </div>
    )
  }

  if (editing && detail.status !== 'success') {
    return (
      <div data-testid="category-form-loading" className="mx-auto max-w-5xl space-y-4" aria-busy="true">
        {back}
        <Skeleton className="h-48 w-full rounded-3xl" />
      </div>
    )
  }

  return <CategoryForm key={detail.data?.id ?? 'new'} detail={detail.data} />
}

function CategoryForm({ detail }: { detail: AdminCategory | undefined }) {
  const a = useAdminText()
  const c = a.catalog
  const f = a.categories.form
  const { handleAuthError } = useAdminAuth()
  const navigate = useNavigate()
  const formId = useId()

  const [form, setForm] = useState<FormState>(() => ({
    sort_order: String(detail?.sort_order ?? 0),
    translations: {
      en: { name: detail?.translations.en?.name ?? '', slug: detail?.translations.en?.slug ?? '' },
      ar: { name: detail?.translations.ar?.name ?? '', slug: detail?.translations.ar?.slug ?? '' },
    },
  }))
  const [errors, setErrors] = useState<Errors>({})
  const [failure, setFailure] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)

  const fieldId = (key: string) => `${formId}-${key.replace(/\./g, '-')}`
  const order = [...LOCALES.flatMap((locale) => ['name', 'slug'].map((field) => `translations.${locale}.${field}`)), 'sort_order'].map((key) => ({ key, id: fieldId(key) }))

  const setNames = (locale: Locale, field: keyof Names, value: string) =>
    setForm((current) => ({ ...current, translations: { ...current.translations, [locale]: { ...current.translations[locale], [field]: value } } }))

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (saving) return
    const nextErrors = validate(form, detail, a)
    setErrors(nextErrors)
    setFailure(null)
    if (Object.keys(nextErrors).length > 0) {
      setFailure(c.errorsSummary)
      focusFirstError(order, nextErrors)
      return
    }

    setSaving(true)
    try {
      const payload = toPayload(form)
      if (detail) await updateCategory(detail.id, payload)
      else await createCategory(payload)
      navigate('/admin/categories', { state: { flash: detail ? a.categories.saved : a.categories.created } })
    } catch (error) {
      setSaving(false)
      if (handleAuthError(error)) return
      if (error instanceof ApiError && error.kind === 'validation') {
        const mapped = mapServerErrors(
          error.fieldErrors,
          { ...c, failed: f.saveFailed },
          {
            taken: (key) => (key.endsWith('.name') ? f.nameTaken : key.endsWith('.slug') ? f.slugTaken : undefined),
            max: (key) => (key.endsWith('.name') ? MAX.name : key.endsWith('.slug') ? MAX.slug : undefined),
            invalid: (key) => (key === 'translations' ? f.oneLanguage : undefined),
          },
        )
        setErrors(mapped)
        setFailure(c.errorsSummary)
        focusFirstError(order, mapped)
      } else if (error instanceof ApiError && error.kind === 'not_found') {
        setFailure(f.notFound)
      } else {
        setFailure(f.saveFailed)
      }
    }
  }

  return (
    <form noValidate onSubmit={onSubmit} className="mx-auto max-w-5xl space-y-6" aria-describedby={failure ? `${formId}-failure` : undefined}>
      <BackLink to="/admin/categories">{f.back}</BackLink>

      {failure && (
        <div id={`${formId}-failure`}>
          <Notice tone="error">{failure}</Notice>
        </div>
      )}
      {errors.translations && <Notice tone="error">{errors.translations}</Notice>}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <div className="min-w-0 space-y-6">
          <p className="text-sm text-slate-400">{f.languagesHelp}</p>
          {LOCALES.map((locale) => {
            const names = form.translations[locale]
            const language = locale === 'en' ? c.english : c.arabic
            const dir = locale === 'ar' ? 'rtl' : 'ltr'
            return (
              <Card key={locale} title={f.names(language)} labelledBy={`${formId}-${locale}-heading`}>
                <div className="space-y-4">
                  <TextField
                    id={fieldId(`translations.${locale}.name`)}
                    label={f.name}
                    value={names.name}
                    onChange={(value) => setNames(locale, 'name', value)}
                    error={errors[`translations.${locale}.name`]}
                    max={MAX.name}
                    dir={dir}
                    lang={locale}
                  />
                  <TextField
                    id={fieldId(`translations.${locale}.slug`)}
                    label={f.slug}
                    value={names.slug}
                    onChange={(value) => setNames(locale, 'slug', value)}
                    error={errors[`translations.${locale}.slug`]}
                    hint={c.slugHint}
                    max={MAX.slug}
                    dir="ltr"
                    lang="en"
                    action={
                      <button
                        type="button"
                        className="text-xs font-medium text-cyan-300 transition hover:text-cyan-200"
                        onClick={() => {
                          const generated = (slugify(names.name) || slugify(form.translations.en.name)).slice(0, MAX.slug).replace(/-+$/, '')
                          if (generated) setNames(locale, 'slug', generated)
                        }}
                      >
                        {c.generateSlug}
                      </button>
                    }
                  />
                </div>
              </Card>
            )
          })}
        </div>

        <aside className="min-w-0 space-y-6">
          <Card title={c.settings}>
            <TextField
              id={fieldId('sort_order')}
              label={c.sortOrder}
              value={form.sort_order}
              onChange={(value) => setForm((current) => ({ ...current, sort_order: value }))}
              error={errors.sort_order}
              hint={c.sortOrderHint}
              dir="ltr"
              inputMode="numeric"
            />
          </Card>
          {detail && <UsageCard count={detail.projects_count} />}
        </aside>
      </div>

      <div className="sticky bottom-0 z-10 -mx-5 flex flex-wrap items-center justify-end gap-3 border-t border-white/10 bg-ink-950/85 px-5 py-4 backdrop-blur-xl sm:-mx-8 sm:px-8">
        <Link to="/admin/categories" className={buttonGhost}>
          {c.cancel}
        </Link>
        <button type="submit" disabled={saving} aria-busy={saving} className={buttonPrimary}>
          {saving ? c.saving : f.save}
        </button>
      </div>
    </form>
  )
}
