import { useId, useState, type FormEvent } from 'react'
import { ApiError } from '../../api/client'
import { Skeleton } from '../../components/ui/DataStates'
import type { Locale } from '../../i18n/config'
import { useAdminAuth } from '../AdminAuth'
import { Card, focusFirstError, TextField, type Errors, type Flash } from '../catalog/ui'
import { useAdminText, type AdminText } from '../i18n'
import {
  getSiteSettings,
  saveSiteSettings,
  SETTINGS_TEXT_KEYS,
  SETTINGS_VALUE_KEYS,
  type AdminSiteSettings,
  type SettingsImageKey,
  type SettingsTextKey,
  type SettingsValueKey,
  type SiteSettingsPayload,
} from '../mediaApi'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, Notice } from '../projects/ui'
import type { ByLocale } from '../projectsApi'
import { useAdminData } from '../useAdminData'

const LOCALES: Locale[] = ['en', 'ar']

const TEXT_GROUPS: { group: 'identity' | 'hero' | 'about' | 'footer' | 'seo'; keys: SettingsTextKey[] }[] = [
  { group: 'identity', keys: ['display_name', 'professional_title'] },
  { group: 'hero', keys: ['hero_eyebrow', 'hero_headline', 'hero_description'] },
  { group: 'about', keys: ['about_text', 'experience_text'] },
  { group: 'footer', keys: ['footer_text'] },
  { group: 'seo', keys: ['seo_default_title', 'seo_default_description'] },
]
const MULTILINE: SettingsTextKey[] = ['hero_description', 'about_text', 'experience_text', 'seo_default_description']
const EMAIL_KEYS: SettingsValueKey[] = ['contact_email', 'notification_email']
const IMAGE_KEYS: SettingsImageKey[] = ['profile_image_path', 'og_default_image_path']

interface FormState {
  texts: Record<SettingsTextKey, ByLocale<string>>
  values: Record<SettingsValueKey, string>
}

function toForm(settings: AdminSiteSettings): FormState {
  const texts = {} as FormState['texts']
  for (const key of SETTINGS_TEXT_KEYS) texts[key] = { en: settings.texts[key]?.en ?? '', ar: settings.texts[key]?.ar ?? '' }
  const values = {} as FormState['values']
  for (const key of SETTINGS_VALUE_KEYS) values[key] = settings.values[key] ?? ''
  return { texts, values }
}

function toPayload(form: FormState): SiteSettingsPayload {
  const texts = {} as SiteSettingsPayload['texts']
  for (const key of SETTINGS_TEXT_KEYS) texts[key] = { en: form.texts[key].en.trim() || null, ar: form.texts[key].ar.trim() || null }
  const values = {} as SiteSettingsPayload['values']
  for (const key of SETTINGS_VALUE_KEYS) values[key] = form.values[key].trim() || null
  return { texts, values }
}

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const isHttpUrl = (value: string) => {
  try {
    const url = new URL(value)
    return url.protocol === 'http:' || url.protocol === 'https:'
  } catch {
    return false
  }
}

/** Mirrors the server rules (the server stays the authority). */
function validate(form: FormState, limits: AdminSiteSettings['limits'], a: AdminText): Errors {
  const s = a.settings
  const errors: Errors = {}
  for (const key of SETTINGS_TEXT_KEYS) {
    for (const locale of LOCALES) {
      if (form.texts[key][locale].trim().length > limits.texts[key]) errors[`texts.${key}.${locale}`] = s.tooLong(limits.texts[key])
    }
  }
  for (const key of SETTINGS_VALUE_KEYS) {
    const value = form.values[key].trim()
    if (!value) continue
    const email = EMAIL_KEYS.includes(key)
    const max = email ? limits.email : limits.url
    if (value.length > max) errors[`values.${key}`] = s.tooLong(max)
    else if (email && !EMAIL.test(value)) errors[`values.${key}`] = s.invalidEmail
    else if (!email && !isHttpUrl(value)) errors[`values.${key}`] = s.invalidUrl
  }
  return errors
}

export function AdminSettingsPage() {
  const a = useAdminText()
  useAdminPage(a.settings.title)
  const settings = useAdminData('admin-site-settings', (signal) => getSiteSettings({ signal }))

  if (settings.status === 'error') {
    return (
      <div className="mx-auto max-w-3xl">
        <Notice tone="error">
          {a.settings.loadFailed}{' '}
          <button type="button" onClick={settings.reload} className="font-semibold underline underline-offset-4">
            {a.catalog.retry}
          </button>
        </Notice>
      </div>
    )
  }
  if (settings.status !== 'success' || !settings.data) {
    return (
      <div data-testid="settings-loading" className="mx-auto max-w-5xl space-y-4" aria-busy="true">
        <Skeleton className="h-48 w-full rounded-3xl" />
        <Skeleton className="h-48 w-full rounded-3xl" />
      </div>
    )
  }
  return <SettingsForm initial={settings.data} />
}

function SettingsForm({ initial }: { initial: AdminSiteSettings }) {
  const a = useAdminText()
  const s = a.settings
  const c = a.catalog
  const { handleAuthError } = useAdminAuth()
  const formId = useId()

  const [saved, setSaved] = useState<AdminSiteSettings>(initial)
  const [form, setForm] = useState<FormState>(() => toForm(initial))
  const [errors, setErrors] = useState<Errors>({})
  const [notice, setNotice] = useState<Flash>(null)
  const [saving, setSaving] = useState(false)
  const dirty = JSON.stringify(toPayload(form)) !== JSON.stringify(toPayload(toForm(saved)))

  const fieldId = (key: string) => `${formId}-${key.replace(/\./g, '-')}`
  const order = [
    ...SETTINGS_TEXT_KEYS.flatMap((key) => LOCALES.map((locale) => `texts.${key}.${locale}`)),
    ...SETTINGS_VALUE_KEYS.map((key) => `values.${key}`),
  ].map((key) => ({ key, id: fieldId(key) }))

  const setText = (key: SettingsTextKey, locale: Locale, value: string) =>
    setForm((current) => ({ ...current, texts: { ...current.texts, [key]: { ...current.texts[key], [locale]: value } } }))
  const setValue = (key: SettingsValueKey, value: string) => setForm((current) => ({ ...current, values: { ...current.values, [key]: value } }))

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (saving) return
    const next = validate(form, saved.limits, a)
    setErrors(next)
    setNotice(null)
    if (Object.keys(next).length > 0) {
      setNotice({ tone: 'error', text: s.errorsSummary })
      focusFirstError(order, next)
      return
    }

    setSaving(true)
    try {
      const result = await saveSiteSettings(toPayload(form))
      setSaved(result)
      setForm(toForm(result))
      setNotice({ tone: 'success', text: s.saved })
    } catch (error) {
      if (handleAuthError(error)) return
      if (error instanceof ApiError && error.kind === 'validation') {
        const mapped: Errors = {}
        for (const [key, messages] of Object.entries(error.fieldErrors)) {
          const message = (messages[0] ?? '').toLowerCase()
          const [, name] = key.split('.') as [string, string]
          if (message.includes('greater than')) {
            const max = key.startsWith('texts.') ? saved.limits.texts[name as SettingsTextKey] : EMAIL_KEYS.includes(name as SettingsValueKey) ? saved.limits.email : saved.limits.url
            mapped[key] = s.tooLong(max)
          } else if (key.startsWith('values.')) mapped[key] = EMAIL_KEYS.includes(name as SettingsValueKey) ? s.invalidEmail : s.invalidUrl
          else mapped[key] = s.invalid
        }
        setErrors(mapped)
        setNotice({ tone: 'error', text: s.errorsSummary })
        focusFirstError(order, mapped)
      } else {
        setNotice({ tone: 'error', text: s.failed })
      }
    } finally {
      setSaving(false)
    }
  }

  return (
    <form noValidate onSubmit={onSubmit} className="mx-auto max-w-5xl space-y-6">
      <p className="max-w-3xl text-sm text-slate-400">{s.intro}</p>
      {notice && (
        <Notice tone={notice.tone} onDismiss={() => setNotice(null)} dismissLabel={c.dismiss}>
          {notice.text}
        </Notice>
      )}

      {TEXT_GROUPS.map(({ group, keys }) => (
        <Card key={group} title={s.groups[group]} labelledBy={`${formId}-${group}`}>
          <div className="space-y-6">
            {keys.map((key) => (
              <fieldset key={key} className="grid gap-4 md:grid-cols-2">
                <legend className="mb-2 text-sm font-semibold text-white md:col-span-2">{s.fields[key]}</legend>
                {LOCALES.map((locale) => (
                  <TextField
                    key={locale}
                    id={fieldId(`texts.${key}.${locale}`)}
                    label={locale === 'en' ? s.english : s.arabic}
                    value={form.texts[key][locale]}
                    onChange={(value) => setText(key, locale, value)}
                    error={errors[`texts.${key}.${locale}`]}
                    max={saved.limits.texts[key]}
                    multiline={MULTILINE.includes(key)}
                    dir={locale === 'ar' ? 'rtl' : 'ltr'}
                    lang={locale}
                  />
                ))}
              </fieldset>
            ))}
            <p className="text-xs text-slate-500">{s.emptyNote}</p>
          </div>
        </Card>
      ))}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title={s.groups.contact} labelledBy={`${formId}-contact`}>
          <div className="space-y-4">
            {(['contact_email', 'github_url', 'linkedin_url'] as const).map((key) => (
              <TextField
                key={key}
                id={fieldId(`values.${key}`)}
                label={s.fields[key]}
                value={form.values[key]}
                onChange={(value) => setValue(key, value)}
                error={errors[`values.${key}`]}
                optional
                dir="ltr"
                lang="en"
              />
            ))}
          </div>
        </Card>
        <div className="space-y-6">
          <Card title={s.groups.private} labelledBy={`${formId}-private`}>
            <TextField
              id={fieldId('values.notification_email')}
              label={s.fields.notification_email}
              value={form.values.notification_email}
              onChange={(value) => setValue('notification_email', value)}
              error={errors['values.notification_email']}
              hint={s.privateNote}
              optional
              dir="ltr"
              lang="en"
            />
          </Card>
          <Card title={s.groups.images} labelledBy={`${formId}-images`}>
            <ul className="space-y-3">
              {IMAGE_KEYS.map((key) => {
                const image = saved.images[key]
                return (
                  <li key={key} className="flex items-center gap-3">
                    {image.url ? (
                      <img src={image.url} alt="" className="size-14 shrink-0 rounded-xl border border-white/10 object-cover" />
                    ) : (
                      <span aria-hidden="true" className="size-14 shrink-0 rounded-xl border border-dashed border-white/15" />
                    )}
                    <span className="min-w-0">
                      <span className="block text-sm text-slate-100">{s.fields[key]}</span>
                      <span className="block text-xs text-slate-400">{!image.set ? s.imageNotSet : image.url ? s.imageSet : s.imageMissing}</span>
                    </span>
                  </li>
                )
              })}
            </ul>
            <p className="mt-4 text-xs text-slate-500">{s.imagesNote}</p>
          </Card>
        </div>
      </div>

      <div className="sticky bottom-0 z-10 -mx-5 flex flex-wrap items-center justify-end gap-3 border-t border-white/10 bg-ink-950/85 px-5 py-4 backdrop-blur-xl sm:-mx-8 sm:px-8">
        {dirty && <p className="me-auto text-sm text-amber-200">{s.unsaved}</p>}
        <button
          type="button"
          className={buttonGhost}
          disabled={!dirty || saving}
          onClick={() => {
            setForm(toForm(saved))
            setErrors({})
            setNotice(null)
          }}
        >
          {s.reset}
        </button>
        <button type="submit" disabled={saving} aria-busy={saving} className={buttonPrimary}>
          {saving ? s.saving : s.save}
        </button>
      </div>
    </form>
  )
}
