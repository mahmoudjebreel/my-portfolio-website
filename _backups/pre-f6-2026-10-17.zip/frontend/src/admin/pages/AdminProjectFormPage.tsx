import { useId, useState, type FormEvent, type ReactNode } from 'react'
import { Link, useNavigate, useParams } from 'react-router'
import { ApiError } from '../../api/client'
import { Skeleton } from '../../components/ui/DataStates'
import type { Locale } from '../../i18n/config'
import { useI18n } from '../../i18n/I18nProvider'
import { useAdminAuth } from '../AdminAuth'
import { useAdminText, type AdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, fieldClass, Notice } from '../projects/ui'
import {
  CONTENT_FIELDS,
  REQUIRED_FIELDS,
  SLUG_PATTERN,
  createProject,
  getProject,
  getProjectOptions,
  isComplete,
  isFilled,
  slugify,
  updateProject,
  type AdminProjectDetail,
  type ByLocale,
  type ContentField,
  type ProjectOptions,
  type ProjectPayload,
  type ProjectStatus,
} from '../projectsApi'
import { projectTitle } from './AdminProjectsPage'
import { useAdminData } from '../useAdminData'

const LOCALES: Locale[] = ['en', 'ar']

/** Same limits as backend/app/Http/Requests/Admin/ProjectRequest.php. */
const MAX: Record<ContentField, number> = {
  title: 150,
  slug: 160,
  short_description: 300,
  description: 20000,
  problem: 20000,
  solution: 20000,
  cover_image_alt: 200,
}

const MULTILINE: ContentField[] = ['description', 'problem', 'solution']

type Content = Record<ContentField, string>
type Errors = Record<string, string>

interface FormState {
  status: ProjectStatus
  is_featured: boolean
  sort_order: string
  github_url: string
  live_url: string
  category_ids: number[]
  technology_ids: number[]
  translations: ByLocale<Content>
}

function initialState(detail?: AdminProjectDetail): FormState {
  const content = (locale: Locale): Content => {
    const source = detail?.translations[locale]
    return Object.fromEntries(CONTENT_FIELDS.map((field) => [field, source?.[field] ?? ''])) as Content
  }
  return {
    status: detail?.status ?? 'draft',
    is_featured: detail?.is_featured ?? false,
    sort_order: String(detail?.sort_order ?? 0),
    github_url: detail?.github_url ?? '',
    live_url: detail?.live_url ?? '',
    category_ids: detail?.category_ids ?? [],
    technology_ids: detail?.technology_ids ?? [],
    translations: { en: content('en'), ar: content('ar') },
  }
}

const isHttpUrl = (value: string) => {
  try {
    const url = new URL(value)
    return (url.protocol === 'http:' || url.protocol === 'https:') && value.length <= 500
  } catch {
    return false
  }
}

/** Mirrors the server rules (the server stays the authority). */
function validate(form: FormState, existing: ByLocale<boolean>, a: AdminText): Errors {
  const f = a.projects.form
  const errors: Errors = {}
  const publishing = form.status === 'published'

  for (const locale of LOCALES) {
    const content = form.translations[locale]
    const required = publishing || isFilled(content) || existing[locale]
    for (const field of CONTENT_FIELDS) {
      const value = content[field].trim()
      const key = `translations.${locale}.${field}`
      if (!value) {
        if (required && (REQUIRED_FIELDS as readonly string[]).includes(field)) errors[key] = f.required
        continue
      }
      if (value.length > MAX[field]) errors[key] = f.tooLong(MAX[field])
      else if (field === 'slug' && !SLUG_PATTERN.test(value)) errors[key] = f.invalidSlug
    }
  }

  if (!LOCALES.some((locale) => isFilled(form.translations[locale]))) errors.translations = f.oneLanguage
  if (publishing && !LOCALES.every((locale) => isComplete(form.translations[locale]))) errors.status = f.bothLanguages

  for (const field of ['live_url', 'github_url'] as const) {
    const value = form[field].trim()
    if (value && !isHttpUrl(value)) errors[field] = f.invalidUrl
  }
  if (!/^\d{1,6}$/.test(form.sort_order.trim()) || Number(form.sort_order) > 100000) errors.sort_order = f.invalidNumber

  return errors
}

/** Server field errors → localized messages (the server's own texts are English only). */
function serverErrors(error: ApiError, a: AdminText): Errors {
  const f = a.projects.form
  const errors: Errors = {}
  for (const [key, messages] of Object.entries(error.fieldErrors)) {
    const message = (messages[0] ?? '').toLowerCase()
    if (key === 'status') errors.status = f.bothLanguages
    else if (key === 'translations') errors.translations = f.oneLanguage
    else if (key.endsWith('_url')) errors[key] = f.invalidUrl
    else if (key === 'sort_order') errors[key] = f.invalidNumber
    else if (key.endsWith('.slug') && message.includes('already')) errors[key] = f.slugTaken
    else if (key.endsWith('.slug') && !message.includes('required')) errors[key] = f.invalidSlug
    else if (message.includes('required')) errors[key] = f.required
    else if (message.includes('may not be greater') || message.includes('must not be greater')) {
      const field = key.split('.').pop() as ContentField
      errors[key] = f.tooLong(MAX[field] ?? 0)
    } else errors[key] = f.saveFailed
  }
  return errors
}

function toPayload(form: FormState): ProjectPayload {
  const translations = {} as ProjectPayload['translations']
  for (const locale of LOCALES) {
    const content = form.translations[locale]
    translations[locale] = isFilled(content)
      ? (Object.fromEntries(CONTENT_FIELDS.map((field) => [field, content[field].trim() || null])) as ProjectPayload['translations'][Locale])
      : null
  }
  return {
    status: form.status,
    is_featured: form.is_featured,
    sort_order: Number(form.sort_order) || 0,
    github_url: form.github_url.trim() || null,
    live_url: form.live_url.trim() || null,
    category_ids: form.category_ids,
    technology_ids: form.technology_ids,
    translations,
  }
}

export function AdminProjectFormPage() {
  const a = useAdminText()
  const { id } = useParams()
  const editing = id !== undefined
  const projectId = Number(id)
  const validId = !editing || (Number.isInteger(projectId) && projectId > 0)
  useAdminPage(editing ? a.projects.editTitle : a.projects.newTitle)

  const options = useAdminData('admin-project-options', (signal) => getProjectOptions({ signal }))
  const detail = useAdminData(editing && validId ? `admin-project:${projectId}` : null, (signal) => getProject(projectId, { signal }))

  const back = (
    <Link to="/admin/projects" className="inline-flex items-center gap-2 text-sm text-slate-400 transition hover:text-white">
      <span aria-hidden="true" className="rtl:-scale-x-100">←</span>
      {a.projects.form.back}
    </Link>
  )

  if (!validId || (editing && detail.status === 'error')) {
    const notFound = !validId || detail.error?.kind === 'not_found'
    return (
      <div className="mx-auto max-w-3xl space-y-6">
        {back}
        <Notice tone="error">
          {notFound ? a.projects.form.notFound : a.projects.form.loadFailed}{' '}
          {!notFound && (
            <button type="button" onClick={detail.reload} className="font-semibold underline underline-offset-4">
              {a.projects.retry}
            </button>
          )}
        </Notice>
      </div>
    )
  }

  if (editing && detail.status !== 'success') {
    return (
      <div data-testid="project-form-loading" className="mx-auto max-w-6xl space-y-4" aria-busy="true">
        {back}
        <Skeleton className="h-64 w-full rounded-3xl" />
        <Skeleton className="h-64 w-full rounded-3xl" />
      </div>
    )
  }

  // Keyed so the form starts from the loaded project (or empty for a new one).
  return (
    <ProjectForm
      key={detail.data?.id ?? 'new'}
      back={back}
      detail={detail.data}
      options={options.data}
      optionsFailed={options.status === 'error'}
    />
  )
}

function ProjectForm({
  back,
  detail,
  options,
  optionsFailed,
}: {
  back: ReactNode
  detail: AdminProjectDetail | undefined
  options: ProjectOptions | undefined
  optionsFailed: boolean
}) {
  const a = useAdminText()
  const f = a.projects.form
  const { locale: uiLocale, t } = useI18n()
  const { handleAuthError } = useAdminAuth()
  const navigate = useNavigate()
  const formId = useId()

  const [form, setForm] = useState<FormState>(() => initialState(detail))
  const [errors, setErrors] = useState<Errors>({})
  const [failure, setFailure] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const existing: ByLocale<boolean> = { en: Boolean(detail?.translations.en), ar: Boolean(detail?.translations.ar) }

  const setContent = (locale: Locale, field: ContentField, value: string) =>
    setForm((current) => ({ ...current, translations: { ...current.translations, [locale]: { ...current.translations[locale], [field]: value } } }))

  const toggle = (key: 'category_ids' | 'technology_ids', value: number) =>
    setForm((current) => ({
      ...current,
      [key]: current[key].includes(value) ? current[key].filter((item) => item !== value) : [...current[key], value],
    }))

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (saving) return
    const nextErrors = validate(form, existing, a)
    setErrors(nextErrors)
    setFailure(null)
    if (Object.keys(nextErrors).length > 0) {
      setFailure(f.errorsSummary)
      focusFirstError(formId, nextErrors)
      return
    }

    setSaving(true)
    try {
      const payload = toPayload(form)
      if (detail) await updateProject(detail.id, payload)
      else await createProject(payload)
      navigate('/admin/projects', { state: { flash: detail ? a.projects.saved : a.projects.created } })
    } catch (error) {
      setSaving(false)
      if (handleAuthError(error)) return
      if (error instanceof ApiError && error.kind === 'validation') {
        const mapped = serverErrors(error, a)
        setErrors(mapped)
        setFailure(f.errorsSummary)
        focusFirstError(formId, mapped)
      } else if (error instanceof ApiError && error.kind === 'not_found') {
        setFailure(f.notFound)
      } else {
        setFailure(f.saveFailed)
      }
    }
  }

  const error = (key: string) =>
    errors[key] ? (
      <p id={`${formId}-${key}-error`} className="mt-1.5 text-xs text-rose-300">
        {errors[key]}
      </p>
    ) : null

  const groups = ['frontend', 'backend', 'database', 'tools'] as const

  return (
    <form noValidate onSubmit={onSubmit} className="mx-auto max-w-6xl space-y-6" aria-describedby={failure ? `${formId}-failure` : undefined}>
      {back}

      {failure && (
        <div id={`${formId}-failure`}>
          <Notice tone="error">{failure}</Notice>
        </div>
      )}
      {errors.translations && <Notice tone="error">{errors.translations}</Notice>}

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="min-w-0 space-y-6">
          {LOCALES.map((locale) => (
            <section
              key={locale}
              aria-labelledby={`${formId}-${locale}-heading`}
              className="glass rounded-3xl p-5 sm:p-6"
            >
              <div className="mb-5 flex items-center justify-between gap-3">
                <h2 id={`${formId}-${locale}-heading`} className="font-display text-lg font-semibold text-white">
                  {f.content(locale === 'en' ? f.english : f.arabic)}
                </h2>
                <span
                  className={`rounded-md border px-1.5 py-0.5 font-mono text-[0.7rem] font-semibold ${
                    isComplete(form.translations[locale]) ? 'border-cyan-300/30 bg-cyan-300/10 text-cyan-100' : 'border-white/10 text-slate-500'
                  }`}
                >
                  {locale.toUpperCase()} · {isComplete(form.translations[locale]) ? a.projects.complete : a.projects.incomplete}
                </span>
              </div>

              <div className="space-y-4" lang={locale} dir={locale === 'ar' ? 'rtl' : 'ltr'}>
                {CONTENT_FIELDS.map((field) => {
                  const key = `translations.${locale}.${field}`
                  const id = `${formId}-${locale}-${field}`
                  const value = form.translations[locale][field]
                  const optional = !(REQUIRED_FIELDS as readonly string[]).includes(field)
                  const Control = MULTILINE.includes(field) ? 'textarea' : 'input'
                  return (
                    <div key={field} lang={uiLocale} dir={uiLocale === 'ar' ? 'rtl' : 'ltr'}>
                      <div className="mb-1.5 flex items-center justify-between gap-3">
                        <label htmlFor={id} className="text-sm font-medium text-slate-200">
                          {f.fields[field]}
                          {optional && <span className="ms-1.5 text-xs font-normal text-slate-500">({f.optional})</span>}
                        </label>
                        {field === 'slug' && (
                          <button
                            type="button"
                            className="text-xs font-medium text-cyan-300 transition hover:text-cyan-200"
                            onClick={() => {
                              const generated = slugify(form.translations[locale].title)
                              if (generated) setContent(locale, 'slug', generated)
                            }}
                          >
                            {f.generateSlug}
                          </button>
                        )}
                      </div>
                      <Control
                        id={id}
                        name={key}
                        value={value}
                        onChange={(event: { target: { value: string } }) => setContent(locale, field, event.target.value)}
                        lang={field === 'slug' ? 'en' : locale}
                        dir={field === 'slug' || locale === 'en' ? 'ltr' : 'rtl'}
                        spellCheck={field !== 'slug'}
                        rows={field === 'description' ? 6 : 4}
                        aria-invalid={Boolean(errors[key])}
                        aria-describedby={[errors[key] ? `${id}-error` : '', field === 'slug' ? `${id}-hint` : ''].filter(Boolean).join(' ') || undefined}
                        className={`${fieldClass} ${MULTILINE.includes(field) ? 'min-h-24 resize-y' : ''}`}
                      />
                      <div className="mt-1 flex justify-between gap-3 text-xs text-slate-500">
                        <span id={field === 'slug' ? `${id}-hint` : undefined}>{field === 'slug' ? f.slugHint : ''}</span>
                        {MAX[field] <= 300 && (
                          <span className={value.length > MAX[field] ? 'text-rose-300' : ''}>
                            {value.length}/{MAX[field]}
                          </span>
                        )}
                      </div>
                      {errors[key] && (
                        <p id={`${id}-error`} className="mt-1 text-xs text-rose-300">
                          {errors[key]}
                        </p>
                      )}
                    </div>
                  )
                })}
              </div>
            </section>
          ))}
        </div>

        <aside className="min-w-0 space-y-6">
          <Card title={f.publishing}>
            <fieldset>
              <legend className="sr-only">{a.projects.status}</legend>
              <div className="grid grid-cols-2 gap-2">
                {(['draft', 'published'] as const).map((status) => (
                  <label
                    key={status}
                    className={`flex cursor-pointer items-center justify-center gap-2 rounded-xl border px-3 py-2 text-sm transition has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-cyan-300 ${
                      form.status === status ? 'border-cyan-300/50 bg-cyan-300/10 font-semibold text-white' : 'border-white/10 text-slate-300 hover:bg-white/5'
                    }`}
                  >
                    <input
                      id={status === 'draft' ? `${formId}-status` : undefined}
                      type="radio"
                      name="status"
                      value={status}
                      checked={form.status === status}
                      onChange={() => setForm((current) => ({ ...current, status }))}
                      className="sr-only"
                    />
                    {a.projects.statuses[status]}
                  </label>
                ))}
              </div>
            </fieldset>
            <p className="mt-3 text-xs leading-relaxed text-slate-400">{f.statusHelp}</p>
            {error('status')}

            <label className="mt-4 flex items-center gap-3 text-sm text-slate-200">
              <input
                type="checkbox"
                checked={form.is_featured}
                onChange={(event) => setForm((current) => ({ ...current, is_featured: event.target.checked }))}
                className="size-4 accent-cyan-400"
              />
              {f.featured}
            </label>

            <div className="mt-4">
              <label htmlFor={`${formId}-sort_order`} className="mb-1.5 block text-sm font-medium text-slate-200">
                {f.sortOrder}
              </label>
              <input
                id={`${formId}-sort_order`}
                inputMode="numeric"
                dir="ltr"
                value={form.sort_order}
                onChange={(event) => setForm((current) => ({ ...current, sort_order: event.target.value }))}
                aria-invalid={Boolean(errors.sort_order)}
                className={`${fieldClass} rtl:text-right`}
              />
              <p className="mt-1 text-xs text-slate-500">{f.sortOrderHint}</p>
              {error('sort_order')}
            </div>
          </Card>

          <Card title={f.links}>
            {(['live_url', 'github_url'] as const).map((field) => (
              <div key={field} className="mt-3 first:mt-0">
                <label htmlFor={`${formId}-${field}`} className="mb-1.5 block text-sm font-medium text-slate-200">
                  {field === 'live_url' ? f.liveUrl : f.githubUrl}
                  <span className="ms-1.5 text-xs font-normal text-slate-500">({f.optional})</span>
                </label>
                <input
                  id={`${formId}-${field}`}
                  type="url"
                  dir="ltr"
                  inputMode="url"
                  placeholder="https://"
                  value={form[field]}
                  onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.value }))}
                  aria-invalid={Boolean(errors[field])}
                  className={`${fieldClass} rtl:text-right`}
                />
                {error(field)}
              </div>
            ))}
          </Card>

          <Card title={f.categories}>
            {optionsFailed ? (
              <p className="text-sm text-rose-200">{a.projects.loadFailed}</p>
            ) : !options ? (
              <Skeleton className="h-16 w-full" />
            ) : options.categories.length === 0 ? (
              <p className="text-sm text-slate-500">{f.noOptions}</p>
            ) : (
              <ul className="space-y-2">
                {options.categories.map((category) => (
                  <li key={category.id}>
                    <label className="flex items-center gap-3 text-sm text-slate-200">
                      <input
                        type="checkbox"
                        checked={form.category_ids.includes(category.id)}
                        onChange={() => toggle('category_ids', category.id)}
                        className="size-4 accent-cyan-400"
                      />
                      {projectTitle(category.name, uiLocale) ?? `#${category.id}`}
                    </label>
                  </li>
                ))}
              </ul>
            )}
            {error('category_ids')}
          </Card>

          <Card title={f.technologies}>
            {optionsFailed ? (
              <p className="text-sm text-rose-200">{a.projects.loadFailed}</p>
            ) : !options ? (
              <Skeleton className="h-16 w-full" />
            ) : options.technologies.length === 0 ? (
              <p className="text-sm text-slate-500">{f.noOptions}</p>
            ) : (
              <div className="space-y-4">
                {groups.map((group) => {
                  const items = options.technologies.filter((tech) => tech.group === group)
                  if (items.length === 0) return null
                  return (
                    <fieldset key={group}>
                      <legend className="mb-2 text-xs font-semibold tracking-wider text-slate-500 uppercase rtl:tracking-normal">{t.skills.groups[group]}</legend>
                      <ul className="flex flex-wrap gap-2">
                        {items.map((tech) => {
                          const checked = form.technology_ids.includes(tech.id)
                          return (
                            <li key={tech.id}>
                              <label
                                className={`flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1 text-xs transition has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-cyan-300 ${
                                  checked ? 'border-cyan-300/50 bg-cyan-300/10 text-white' : 'border-white/10 text-slate-300 hover:bg-white/5'
                                }`}
                              >
                                <input type="checkbox" checked={checked} onChange={() => toggle('technology_ids', tech.id)} className="sr-only" />
                                <span dir="auto">{tech.name}</span>
                                {!tech.is_visible && <span className="text-slate-500">({f.hidden})</span>}
                              </label>
                            </li>
                          )
                        })}
                      </ul>
                    </fieldset>
                  )
                })}
              </div>
            )}
            {error('technology_ids')}
          </Card>

          <Card title={f.images}>
            <p className="text-xs leading-relaxed text-slate-400">{f.imagesNote}</p>
            {detail?.cover ? (
              <figure className="mt-3">
                <img src={detail.cover.url} alt="" className="aspect-[16/10] w-full rounded-xl border border-white/10 object-cover" />
                <figcaption className="mt-1 text-xs text-slate-500">{f.cover}</figcaption>
              </figure>
            ) : (
              <p className="mt-3 text-sm text-slate-500">{f.noCover}</p>
            )}
            {detail && <p className="mt-2 text-sm text-slate-400">{f.galleryCount(detail.images_count)}</p>}
          </Card>
        </aside>
      </div>

      <div className="sticky bottom-0 z-10 -mx-5 flex flex-wrap items-center justify-end gap-3 border-t border-white/10 bg-ink-950/85 px-5 py-4 backdrop-blur-xl sm:-mx-8 sm:px-8">
        <Link to="/admin/projects" className={buttonGhost}>
          {f.cancel}
        </Link>
        <button type="submit" disabled={saving} aria-busy={saving} className={buttonPrimary}>
          {saving ? f.saving : f.save}
        </button>
      </div>
    </form>
  )
}

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="glass rounded-3xl p-5">
      <h2 className="mb-4 font-display text-base font-semibold text-white">{title}</h2>
      {children}
    </section>
  )
}

function focusFirstError(formId: string, errors: Errors) {
  const order = [
    ...LOCALES.flatMap((locale) => CONTENT_FIELDS.map((field) => `translations.${locale}.${field}`)),
    'status',
    'sort_order',
    'live_url',
    'github_url',
  ]
  const first = order.find((key) => errors[key])
  if (!first) return
  const id = first.startsWith('translations.') ? `${formId}-${first.split('.')[1]}-${first.split('.')[2]}` : `${formId}-${first}`
  window.setTimeout(() => document.getElementById(id)?.focus(), 0)
}
