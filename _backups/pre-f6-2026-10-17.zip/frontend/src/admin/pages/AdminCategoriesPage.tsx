import { Link } from 'react-router'
import { useI18n } from '../../i18n/I18nProvider'
import { formatDate } from '../../lib/formatDate'
import { listCategories } from '../catalogApi'
import { ListPanel, SearchField, td, th, useFlash, useListParams } from '../catalog/ui'
import { useAdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'
import { buttonGhost, buttonPrimary, Notice } from '../projects/ui'
import { useAdminData } from '../useAdminData'

const PER_PAGE = 10

export function AdminCategoriesPage() {
  const a = useAdminText()
  const c = a.catalog
  const s = a.categories
  const { locale } = useI18n()
  useAdminPage(s.title)

  const { q, page, search, setSearch, update, clear } = useListParams()
  const [notice, setNotice] = useFlash()
  const list = useAdminData(`admin-categories:${q}:${page}`, (signal) => listCategories({ q: q || undefined, page, perPage: PER_PAGE }, { signal }))

  return (
    <div className="mx-auto max-w-6xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <p className="max-w-2xl text-sm text-slate-400">{s.intro}</p>
        <Link to="/admin/categories/new" className={buttonPrimary}>
          <span aria-hidden="true" className="text-base leading-none">+</span>
          {s.add}
        </Link>
      </div>

      {notice && (
        <Notice tone={notice.tone} onDismiss={() => setNotice(null)} dismissLabel={c.dismiss}>
          {notice.text}
        </Notice>
      )}

      <div role="search" className="glass rounded-3xl p-4">
        <SearchField value={search} onChange={setSearch} label={s.search} placeholder={s.searchPlaceholder} />
      </div>

      <ListPanel
        label={s.title}
        list={list}
        filtered={Boolean(q)}
        onClear={clear}
        onPage={(next) => update({ page: next > 1 ? String(next) : undefined })}
        texts={s}
        testId="categories"
      >
        {(categories) => (
          <table className="w-full min-w-[40rem] text-sm">
            <thead>
              <tr className="text-xs text-slate-500">
                {(['en', 'ar', 'projects', 'order', 'updated'] as const).map((column) => (
                  <th key={column} scope="col" className={th}>
                    {s.columns[column]}
                  </th>
                ))}
                <th scope="col" className={`${th} text-end`}>
                  {s.columns.actions}
                </th>
              </tr>
            </thead>
            <tbody>
              {categories.map((category) => {
                const label = category.translations[locale]?.name ?? category.translations.en?.name ?? category.translations.ar?.name ?? `#${category.id}`
                return (
                  <tr key={category.id} className="border-t border-white/5 transition hover:bg-white/[0.03]">
                    {(['en', 'ar'] as const).map((lang) => {
                      const names = category.translations[lang]
                      return (
                        <td key={lang} className={td}>
                          {names ? (
                            <span lang={lang} dir={lang === 'ar' ? 'rtl' : 'ltr'} className="block">
                              <span className="font-medium text-slate-100">{names.name}</span>
                              <span dir="ltr" className="block font-mono text-xs text-slate-500">
                                {names.slug}
                              </span>
                            </span>
                          ) : (
                            <span className="text-slate-500 italic">{c.notTranslated}</span>
                          )}
                        </td>
                      )
                    })}
                    <td className={`${td} text-slate-300`}>
                      <span title={category.in_use ? c.linkedProjects(category.projects_count) : c.notLinked}>{category.projects_count}</span>
                    </td>
                    <td className={`${td} text-slate-400`}>{category.sort_order}</td>
                    <td className={`${td} whitespace-nowrap text-slate-400`}>
                      {category.updated_at ? <time dateTime={category.updated_at}>{formatDate(category.updated_at, locale)}</time> : '—'}
                    </td>
                    <td className={td}>
                      <div className="flex justify-end">
                        <Link to={`/admin/categories/${category.id}/edit`} className={buttonGhost} aria-label={`${c.edit}: ${label}`}>
                          {c.edit}
                        </Link>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </ListPanel>
    </div>
  )
}
