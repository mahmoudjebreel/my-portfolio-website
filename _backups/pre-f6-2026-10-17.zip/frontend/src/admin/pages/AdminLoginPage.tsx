import { useId, useRef, useState, type FormEvent } from 'react'
import { Link, Navigate, useLocation } from 'react-router'
import { ApiError } from '../../api/client'
import { useI18n } from '../../i18n/I18nProvider'
import { useDocumentMeta } from '../../lib/useDocumentMeta'
import { useAdminAuth, type GuestReason } from '../AdminAuth'
import { AdminBackdrop, AdminBrand, AdminLanguageToggle, AdminSessionChecking, AdminUnavailable } from '../components'
import { useAdminText, type AdminText } from '../i18n'

type Field = 'email' | 'password'

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

/** Only admin pages are accepted as the page to return to (no open redirect, no loop). */
export function safeAdminPath(value: unknown): string {
  if (typeof value !== 'string' || !/^\/admin(?:[/?#]|$)/.test(value) || /^\/admin\/login(?:[/?#]|$)/.test(value)) return '/admin'
  return value
}

function failureMessage(error: unknown, a: AdminText): string {
  if (!(error instanceof ApiError)) return a.login.error
  switch (error.kind) {
    case 'validation':
      // One generic message: never says whether the email exists.
      return a.login.failed
    case 'rate_limited':
      return error.retryAfter ? a.login.rateLimited(error.retryAfter) : a.login.rateLimitedSoon
    case 'network':
    case 'timeout':
      return a.login.unreachable
    default:
      return error.kind === 'http' && [502, 503, 504].includes(error.status ?? 0) ? a.login.unreachable : a.login.error
  }
}

function reasonMessage(reason: GuestReason, a: AdminText): string | null {
  if (reason === 'expired') return a.login.expired
  if (reason === 'signedOut') return a.login.signedOut
  if (reason === 'forbidden') return a.login.forbidden
  return null
}

export function AdminLoginPage() {
  const a = useAdminText()
  const { status } = useAdminAuth()
  const location = useLocation()
  useDocumentMeta(`${a.login.pageTitle} · ${a.brand}`)

  const from = safeAdminPath((location.state as { from?: unknown } | null)?.from)

  if (status === 'checking') return <AdminSessionChecking />
  if (status === 'unavailable') return <AdminUnavailable />
  if (status === 'authenticated') return <Navigate to={from} replace />
  // After a successful sign-in the status becomes "authenticated" and the Navigate above runs.
  return <LoginForm />
}

function LoginForm() {
  const a = useAdminText()
  const { locale } = useI18n()
  const { reason, signIn } = useAdminAuth()
  const formId = useId()
  const passwordRef = useRef<HTMLInputElement>(null)

  const [values, setValues] = useState({ email: '', password: '' })
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({})
  const [failure, setFailure] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [showPassword, setShowPassword] = useState(false)

  const notice = failure === null ? reasonMessage(reason, a) : null

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (submitting) return

    const email = values.email.trim()
    const nextErrors: Partial<Record<Field, string>> = {}
    if (!email) nextErrors.email = a.login.required
    else if (!EMAIL_PATTERN.test(email)) nextErrors.email = a.login.invalidEmail
    if (!values.password) nextErrors.password = a.login.required
    setErrors(nextErrors)
    setFailure(null)

    const firstInvalid = (['email', 'password'] as const).find((field) => nextErrors[field])
    if (firstInvalid) {
      document.getElementById(`${formId}-${firstInvalid}`)?.focus()
      return
    }

    setSubmitting(true)
    try {
      await signIn(email, values.password)
    } catch (error) {
      setFailure(failureMessage(error, a))
      setValues((current) => ({ ...current, password: '' }))
      setSubmitting(false)
      passwordRef.current?.focus()
    }
  }

  const input =
    'w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-white placeholder:text-slate-500 transition focus:border-cyan-300/60 focus:bg-white/[0.07] focus:outline-none aria-[invalid=true]:border-rose-400/60'

  const fieldError = (field: Field) =>
    errors[field] ? (
      <p id={`${formId}-${field}-error`} className="mt-2 text-sm text-rose-300">
        {errors[field]}
      </p>
    ) : null

  return (
    <AdminBackdrop>
      <div className="absolute end-5 top-5">
        <AdminLanguageToggle />
      </div>

      <main className="w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <AdminBrand />
        </div>

        <form noValidate onSubmit={onSubmit} aria-labelledby={`${formId}-title`} className="glass rounded-3xl p-6 sm:p-8">
          <h1 id={`${formId}-title`} className="font-display text-2xl font-semibold text-white">
            {a.login.title}
          </h1>
          <p className="mt-1 text-sm text-slate-400">{a.login.subtitle}</p>

          {notice && (
            <p role="status" className="mt-6 rounded-xl border border-cyan-300/20 bg-cyan-300/[0.06] px-4 py-3 text-sm text-cyan-100">
              {notice}
            </p>
          )}
          {failure && (
            <p role="alert" className="mt-6 rounded-xl border border-rose-300/25 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
              {failure}
            </p>
          )}

          <div className="mt-6 space-y-5">
            <div>
              <label htmlFor={`${formId}-email`} className="mb-2 block text-sm font-medium text-slate-200">
                {a.login.email}
              </label>
              <input
                id={`${formId}-email`}
                name="email"
                type="email"
                dir="ltr"
                autoComplete="username"
                inputMode="email"
                spellCheck={false}
                value={values.email}
                onChange={(event) => setValues((current) => ({ ...current, email: event.target.value }))}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? `${formId}-email-error` : undefined}
                className={`${input} rtl:text-right`}
              />
              {fieldError('email')}
            </div>

            <div>
              <label htmlFor={`${formId}-password`} className="mb-2 block text-sm font-medium text-slate-200">
                {a.login.password}
              </label>
              <div className="relative">
                <input
                  ref={passwordRef}
                  id={`${formId}-password`}
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  dir="ltr"
                  autoComplete="current-password"
                  value={values.password}
                  onChange={(event) => setValues((current) => ({ ...current, password: event.target.value }))}
                  aria-invalid={Boolean(errors.password)}
                  aria-describedby={errors.password ? `${formId}-password-error` : undefined}
                  className={`${input} pe-12 rtl:text-right`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((value) => !value)}
                  aria-label={showPassword ? a.login.hidePassword : a.login.showPassword}
                  aria-pressed={showPassword}
                  className="absolute inset-y-0 end-0 grid w-12 place-items-center rounded-e-xl text-slate-400 transition hover:text-white"
                >
                  <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
                    <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z" />
                    <circle cx="12" cy="12" r="3" />
                    {showPassword && <path d="M4 4l16 16" />}
                  </svg>
                </button>
              </div>
              {fieldError('password')}
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            aria-busy={submitting}
            className="mt-8 inline-flex w-full items-center justify-center rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-7 py-3.5 font-semibold text-ink-950 transition hover:brightness-110 disabled:opacity-60"
          >
            {submitting ? a.login.submitting : a.login.submit}
          </button>
        </form>

        <p className="mt-6 text-center text-sm">
          <Link to={`/${locale}`} className="text-slate-400 transition hover:text-white">
            {a.login.backToSite}
          </Link>
        </p>
      </main>
    </AdminBackdrop>
  )
}
