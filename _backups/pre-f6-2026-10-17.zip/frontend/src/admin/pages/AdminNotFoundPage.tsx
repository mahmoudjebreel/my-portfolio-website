import { Link } from 'react-router'
import { useAdminText } from '../i18n'
import { useAdminPage } from '../pageTitle'

export function AdminNotFoundPage() {
  const a = useAdminText()
  useAdminPage(a.notFound.title)

  return (
    <section aria-labelledby="admin-not-found" className="glass mx-auto max-w-md rounded-3xl px-6 py-12 text-center">
      <p className="font-display text-6xl font-bold text-gradient" aria-hidden="true">
        404
      </p>
      <h2 id="admin-not-found" className="mt-4 font-display text-2xl font-semibold text-white">
        {a.notFound.title}
      </h2>
      <p className="mt-2 text-slate-400">{a.notFound.text}</p>
      <Link
        to="/admin"
        className="glass mt-8 inline-flex rounded-full px-6 py-3 font-medium text-white transition hover:border-cyan-300/40 hover:bg-white/10"
      >
        {a.notFound.back}
      </Link>
    </section>
  )
}
