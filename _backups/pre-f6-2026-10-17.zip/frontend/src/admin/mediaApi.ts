/**
 * Admin media & site settings API (Laravel, routes/admin.php — A6). Every call needs an
 * administrator session; state-changing calls send the CSRF token (withCsrf).
 * Nothing here deletes, detaches or replaces a file.
 */
import { apiGet, apiSend, type RequestOptions } from '../api/client'
import type { Paginated } from '../api/types'
import { withCsrf } from './api'
import type { ByLocale } from './projectsApi'

export type MediaKind = 'cover' | 'gallery'

export interface AdminMediaItem {
  key: string
  kind: MediaKind
  id: number
  file_name: string | null
  mime_type: string | null
  size: number | null
  width: number | null
  height: number | null
  sort_order: number | null
  alt: ByLocale<string | null>
  /** False when the stored file is missing or its path is unsafe. */
  available: boolean
  /** Admin-only preview (session required); null when unavailable. */
  preview_url: string | null
  project: { id: number; status: 'draft' | 'published'; title: ByLocale<string | null> }
  updated_at: string | null
}

export interface MediaProjectOption {
  id: number
  title: ByLocale<string | null>
}

export type MediaPage = Paginated<AdminMediaItem> & { projects: MediaProjectOption[] }

export interface MediaListParams {
  q?: string
  project?: number
  kind?: MediaKind
  page?: number
  perPage?: number
}

export function listMedia(params: MediaListParams, options?: RequestOptions): Promise<MediaPage> {
  return apiGet<MediaPage>(
    '/admin/media',
    { q: params.q, project: params.project, kind: params.kind, page: params.page, per_page: params.perPage },
    options,
  )
}

/** Same limits as the API (MediaUploadRequest / WebpImage). */
export const UPLOAD_MAX_BYTES = 5 * 1024 * 1024
export const UPLOAD_TYPES = ['image/jpeg', 'image/png', 'image/webp']
export const UPLOAD_EXTENSIONS = /\.(jpe?g|png|webp)$/i

export interface UploadPayload {
  projectId: number
  file: File
  alt: ByLocale<string>
}

/** Adds a gallery image to a project. The server re-encodes it to WebP and names it. */
export async function uploadMedia({ projectId, file, alt }: UploadPayload): Promise<AdminMediaItem> {
  const form = new FormData()
  form.append('project_id', String(projectId))
  form.append('file', file)
  for (const [locale, text] of Object.entries(alt)) {
    if (text.trim()) form.append(`alt[${locale}]`, text.trim())
  }
  // Uploads can take longer than ordinary requests.
  const body = await withCsrf(() => apiSend<{ data: AdminMediaItem }>('POST', '/admin/media', form, { timeoutMs: 60_000 }))
  return body!.data
}

export type SettingsTextKey =
  | 'display_name'
  | 'professional_title'
  | 'hero_eyebrow'
  | 'hero_headline'
  | 'hero_description'
  | 'about_text'
  | 'experience_text'
  | 'footer_text'
  | 'seo_default_title'
  | 'seo_default_description'

export type SettingsValueKey = 'contact_email' | 'github_url' | 'linkedin_url' | 'notification_email'
export type SettingsImageKey = 'profile_image_path' | 'og_default_image_path'

export const SETTINGS_TEXT_KEYS: SettingsTextKey[] = [
  'display_name',
  'professional_title',
  'hero_eyebrow',
  'hero_headline',
  'hero_description',
  'about_text',
  'experience_text',
  'footer_text',
  'seo_default_title',
  'seo_default_description',
]
export const SETTINGS_VALUE_KEYS: SettingsValueKey[] = ['contact_email', 'github_url', 'linkedin_url', 'notification_email']

export interface AdminSiteSettings {
  texts: Record<SettingsTextKey, ByLocale<string | null>>
  values: Record<SettingsValueKey, string | null>
  images: Record<SettingsImageKey, { set: boolean; url: string | null }>
  limits: { texts: Record<SettingsTextKey, number>; email: number; url: number }
  /** Saved but never shown on the public website. */
  private_keys: string[]
}

export interface SiteSettingsPayload {
  texts: Record<SettingsTextKey, ByLocale<string | null>>
  values: Record<SettingsValueKey, string | null>
}

export async function getSiteSettings(options?: RequestOptions): Promise<AdminSiteSettings> {
  return (await apiGet<{ data: AdminSiteSettings }>('/admin/site-settings', {}, options)).data
}

export async function saveSiteSettings(payload: SiteSettingsPayload): Promise<AdminSiteSettings> {
  const body = await withCsrf(() => apiSend<{ data: AdminSiteSettings }>('PUT', '/admin/site-settings', payload))
  return body!.data
}
