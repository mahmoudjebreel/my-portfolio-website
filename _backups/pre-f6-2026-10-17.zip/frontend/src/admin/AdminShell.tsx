import { useEffect, useState } from 'react'
import { Link, Navigate, NavLink, Outlet, useLocation } from 'react-router'
import { useI18n } from '../i18n/I18nProvider'
import { useAdminAuth } from './AdminAuth'
import { AdminBrand, AdminLanguageToggle, AdminSessionChecking, AdminUnavailable } from './components'
import { useAdminText } from './i18n'
import { AdminIcon, type AdminIconName } from './icons'
import { AdminPageTitleProvider, useAdminPageTitle } from './pageTitle'

/** Administration sections (A4–A7). */
const SECTIONS: { key: 'projects' | 'categories' | 'technologies' | 'media' | 'messages' | 'settings'; icon: AdminIconName }[] = [
  { key: 'projects', icon: 'projects' },
  { key: 'categories', icon: 'categories' },
  { key: 'technologies', icon: 'technologies' },
  { key: 'media', icon: 'media' },
  { key: 'messages', icon: 'messages' },
  { key: 'settings', icon: 'settings' },
]

/**
 * Protected part of /admin. Shows the pages only for a session that Laravel confirmed as an
 * administrator; otherwise redirects to the sign-in page (remembering the requested page).
 * This only decides what to display: every admin API route is protected on the server.
 */
export function AdminShell() {
  const { status } = useAdminAuth()
  const location = useLocation()

  if (status === 'checking') return <AdminSessionChecking />
  if (status === 'unavailable') return <AdminUnavailable />
  if (status !== 'authenticated') {
    return <Navigate to="/admin/login" replace state={{ from: `${location.pathname}${location.search}` }} />
  }
  return (
    <AdminPageTitleProvider>
      <AdminLayout />
    </AdminPageTitleProvider>
  )
}

function AdminLayout() {
  const a = useAdminText()
  const { t } = useI18n()
  const { signOut } = useAdminAuth()
  const [menuOpen, setMenuOpen] = useState(false)
  const [signingOut, setSigningOut] = useState(false)
  const [signOutFailed, setSignOutFailed] = useState(false)
  const location = useLocation()
  const [lastPath, setLastPath] = useState(location.pathname)

  // Close the mobile menu after navigating (state adjusted during render, not in an effect).
  if (lastPath !== location.pathname) {
    setLastPath(location.pathname)
    setMenuOpen(false)
  }

  useEffect(() => {
    if (!menuOpen) return
    const onKey = (event: KeyboardEvent) => event.key === 'Escape' && setMenuOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [menuOpen])

  const onSignOut = async () => {
    setSigningOut(true)
    setSignOutFailed(false)
    try {
      await signOut() // the shell then redirects to the sign-in page
    } catch {
      setSignOutFailed(true)
      setSigningOut(false)
    }
  }

  return (
    <div className="min-h-[100svh] lg:grid lg:grid-cols-[17rem_minmax(0,1fr)]">
      <a
        href="#admin-main"
        className="fixed start-4 top-4 z-[60] -translate-y-24 rounded-full bg-white px-4 py-2 text-sm font-semibold text-ink-950 transition focus:translate-y-0"
      >
        {t.skipToContent}
      </a>

      {/* Sidebar: fixed column on large screens, drawer on small ones. */}
      <aside
        id="admin-sidebar"
        className={`${menuOpen ? 'flex' : 'hidden'} fixed inset-y-0 start-0 z-50 w-72 max-w-[85vw] flex-col border-e border-white/10 bg-ink-900/95 backdrop-blur-xl lg:sticky lg:top-0 lg:z-auto lg:flex lg:h-[100svh] lg:w-auto lg:max-w-none`}
      >
        <div className="flex h-16 shrink-0 items-center justify-between gap-3 border-b border-white/10 px-5">
          <Link to="/admin" className="rounded-lg">
            <AdminBrand />
          </Link>
          <button
            type="button"
            onClick={() => setMenuOpen(false)}
            aria-label={a.shell.closeMenu}
            className="glass inline-grid size-9 place-items-center rounded-full text-white lg:hidden"
          >
            <AdminIcon name="close" className="size-4" />
          </button>
        </div>
        <AdminSidebar signingOut={signingOut} onSignOut={onSignOut} />
      </aside>
      {menuOpen && (
        <button
          type="button"
          tabIndex={-1}
          aria-hidden="true"
          onClick={() => setMenuOpen(false)}
          className="fixed inset-0 z-40 bg-ink-950/70 backdrop-blur-sm lg:hidden"
        />
      )}

      <div className="flex min-w-0 flex-col">
        <AdminHeader menuOpen={menuOpen} onOpenMenu={() => setMenuOpen(true)} />
        {signOutFailed && (
          <p role="alert" className="border-b border-rose-300/20 bg-rose-500/10 px-5 py-2.5 text-sm text-rose-100 sm:px-8">
            {a.shell.signOutFailed}
          </p>
        )}
        <main id="admin-main" tabIndex={-1} className="flex-1 px-5 py-8 sm:px-8 lg:py-10">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

const navItem = 'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition'
const activeItem = 'bg-gradient-to-r from-violet-500/20 to-cyan-400/10 font-semibold text-white shadow-[inset_0_0_0_1px] shadow-white/10'
const idleItem = 'text-slate-300 hover:bg-white/5 hover:text-white'

function AdminSidebar({ signingOut, onSignOut }: { signingOut: boolean; onSignOut: () => void }) {
  const a = useAdminText()
  const { locale } = useI18n()

  return (
    <nav aria-label={a.shell.nav} className="flex flex-1 flex-col overflow-y-auto px-4 py-6">
      <ul className="space-y-1">
        <li>
          <NavLink
            to="/admin"
            end
            className={({ isActive }) => `${navItem} ${isActive ? activeItem : idleItem}`}
          >
            <AdminIcon name="dashboard" className="size-5 text-cyan-300" />
            {a.shell.dashboard}
          </NavLink>
        </li>
        {SECTIONS.map(({ key, icon }) => (
          <li key={key}>
            <NavLink to={`/admin/${key}`} className={({ isActive }) => `${navItem} ${isActive ? activeItem : idleItem}`}>
              <AdminIcon name={icon} className="size-5 text-cyan-300" />
              {a.shell.sections[key]}
            </NavLink>
          </li>
        ))}
      </ul>

      <div className="mt-auto space-y-1 border-t border-white/10 pt-4">
        <a href={`/${locale}`} target="_blank" rel="noopener" className={`${navItem} text-slate-300 hover:bg-white/5 hover:text-white`}>
          <AdminIcon name="external" className="size-5 rtl:-scale-x-100" />
          {a.shell.viewSite}
        </a>
        <button
          type="button"
          onClick={onSignOut}
          disabled={signingOut}
          aria-busy={signingOut}
          className={`${navItem} w-full text-slate-300 hover:bg-rose-500/10 hover:text-rose-100 disabled:opacity-60`}
        >
          <AdminIcon name="logout" className="size-5 rtl:-scale-x-100" />
          {signingOut ? a.shell.signingOut : a.shell.signOut}
        </button>
      </div>
    </nav>
  )
}

function AdminHeader({ menuOpen, onOpenMenu }: { menuOpen: boolean; onOpenMenu: () => void }) {
  const a = useAdminText()
  const { user } = useAdminAuth()
  const title = useAdminPageTitle()
  const initial = user?.name.trim().charAt(0).toLocaleUpperCase()

  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-ink-950/75 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-3 px-5 sm:px-8">
        <button
          type="button"
          onClick={onOpenMenu}
          aria-expanded={menuOpen}
          aria-controls="admin-sidebar"
          aria-label={a.shell.openMenu}
          className="glass inline-grid size-10 shrink-0 place-items-center rounded-full text-white lg:hidden"
        >
          <AdminIcon name="menu" />
        </button>

        <h1 className="min-w-0 flex-1 truncate font-display text-lg font-semibold text-white sm:text-xl">{title ?? a.brand}</h1>

        <div className="flex shrink-0 items-center gap-2">
          <AdminLanguageToggle />
          {user && (
            <span
              title={`${a.shell.signedInAs} ${user.name}`}
              className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] py-1 ps-1 pe-3 text-sm text-slate-200 sm:inline-flex"
            >
              <span
                aria-hidden="true"
                className="grid size-8 place-items-center rounded-full bg-gradient-to-br from-violet-500 to-cyan-400 font-display text-xs font-bold text-ink-950"
              >
                {initial}
              </span>
              <span className="sr-only">{a.shell.signedInAs} </span>
              <span className="max-w-40 truncate">{user.name}</span>
            </span>
          )}
        </div>
      </div>
    </header>
  )
}
