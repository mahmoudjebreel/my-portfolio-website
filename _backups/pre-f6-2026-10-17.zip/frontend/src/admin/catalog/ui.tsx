/**
 * Building blocks shared by the category and technology pages (A5). The visual language is
 * the one of the project pages (A4): same notices, fields, buttons, skeletons and empty states.
 */
import { useEffect, useState, type ReactNode } from 'react'
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router'
import type { Paginated } from '../../api/types'
import { EmptyState, Skeleton } from '../../components/ui/DataStates'
import { useAdminText } from '../i18n'
import { buttonGhost, fieldClass, Notice } from '../projects/ui'
import type { MessageStatus } from '../messagesApi'
import type { AdminData } from '../useAdminData'

export type Errors = Record<string, string>
export type Flash = { tone: 'success' | 'error'; text: string } | null

/**
 * Search box + filters kept in the address (?q=…&page=…&<filters>), so a list can be
 * reloaded or shared. Typing searches after a short pause; changing a filter resets the page.
 */
export function useListParams() {
  const [params, setParams] = useSearchParams()
  const q = (params.get('q') ?? '').slice(0, 100)
  const rawPage = Number(params.get('page'))
  const page = Number.isInteger(rawPage) && rawPage > 1 ? rawPage : 1
  const [search, setSearch] = useState(q)

  const update = (changes: Record<string, string | undefined>) => {
    const next = new URLSearchParams(params)
    for (const [key, value] of Object.entries(changes)) {
      if (value) next.set(key, value)
      else next.delete(key)
    }
    if (!('page' in changes)) next.delete('page')
    setParams(next)
  }

  useEffect(() => {
    const value = search.trim()
    if (value === q) return
    const timer = window.setTimeout(() => {
      const next = new URLSearchParams(params)
      if (value) next.set('q', value)
      else next.delete('q')
      next.delete('page')
      setParams(next)
    }, 350)
    return () => window.clearTimeout(timer)
  }, [search, q, params, setParams])

  const clear = () => {
    setSearch('')
    setParams(new URLSearchParams())
  }

  return { params, q, page, search, setSearch, update, clear }
}

/** Success message handed over by a form through the navigation state (shown once). */
export function useFlash(): [Flash, (flash: Flash) => void] {
  const location = useLocation()
  const navigate = useNavigate()
  const [flash, setFlash] = useState<Flash>(() => {
    const text = (location.state as { flash?: string } | null)?.flash
    return text ? { tone: 'success', text } : null
  })
  useEffect(() => {
    if ((location.state as { flash?: string } | null)?.flash) navigate(`${location.pathname}${location.search}`, { replace: true, state: null })
  }, [location, navigate])
  return [flash, setFlash]
}

export function SearchField({ value, onChange, label, placeholder }: { value: string; onChange: (value: string) => void; label: string; placeholder: string }) {
  return (
    <label className="block">
      <span className="sr-only">{label}</span>
      <input type="search" value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} maxLength={100} className={fieldClass} />
    </label>
  )
}

/**
 * The list card: loading skeleton, error with retry, empty / no-results state, the table
 * (children) and server-side pagination.
 */
export function ListPanel<T>({
  label,
  list,
  filtered,
  onClear,
  onPage,
  texts,
  testId,
  children,
}: {
  label: string
  list: Pick<AdminData<Paginated<T>>, 'status' | 'data' | 'reload'>
  filtered: boolean
  onClear: () => void
  onPage: (page: number) => void
  texts: { empty: string; noResults: string; loadFailed: string; total: (count: number) => string }
  testId: string
  children: (items: T[]) => ReactNode
}) {
  const c = useAdminText().catalog
  const items = list.data?.data ?? []
  const meta = list.data?.meta

  return (
    <section aria-label={label} className="glass min-w-0 rounded-3xl">
      {list.status === 'loading' && (
        <div data-testid={`${testId}-loading`} className="space-y-3 p-5" aria-busy="true">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-10 w-full" />
          ))}
        </div>
      )}

      {list.status === 'error' && (
        <div className="p-5">
          <Notice tone="error">
            {texts.loadFailed}{' '}
            <button type="button" onClick={list.reload} className="font-semibold underline underline-offset-4">
              {c.retry}
            </button>
          </Notice>
        </div>
      )}

      {list.status === 'success' && items.length === 0 && (
        <div className="flex flex-col items-center gap-4 p-5">
          <div className="w-full">
            <EmptyState>{filtered ? texts.noResults : texts.empty}</EmptyState>
          </div>
          {filtered && (
            <button type="button" className={buttonGhost} onClick={onClear}>
              {c.clearFilters}
            </button>
          )}
        </div>
      )}

      {list.status === 'success' && items.length > 0 && <div className="overflow-x-auto">{children(items)}</div>}

      {list.status === 'success' && meta && meta.total > 0 && (
        <nav aria-label={c.pageOf(meta.current_page, meta.last_page)} className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 px-4 py-3 text-sm text-slate-400">
          <p>
            {texts.total(meta.total)} · {c.pageOf(meta.current_page, meta.last_page)}
          </p>
          <div className="flex gap-2">
            <button type="button" className={buttonGhost} disabled={meta.current_page <= 1} onClick={() => onPage(meta.current_page - 1)}>
              {c.previous}
            </button>
            <button type="button" className={buttonGhost} disabled={meta.current_page >= meta.last_page} onClick={() => onPage(meta.current_page + 1)}>
              {c.next}
            </button>
          </div>
        </nav>
      )}
    </section>
  )
}

export const th = 'px-4 py-3 text-start font-medium'
export const td = 'px-4 py-3'

export function BackLink({ to, children }: { to: string; children: ReactNode }) {
  return (
    <Link to={to} className="inline-flex items-center gap-2 text-sm text-slate-400 transition hover:text-white">
      <span aria-hidden="true" className="rtl:-scale-x-100">←</span>
      {children}
    </Link>
  )
}

export function Card({ title, children, labelledBy }: { title: ReactNode; children: ReactNode; labelledBy?: string }) {
  return (
    <section aria-labelledby={labelledBy} className="glass rounded-3xl p-5 sm:p-6">
      <h2 id={labelledBy} className="mb-4 font-display text-lg font-semibold text-white">
        {title}
      </h2>
      {children}
    </section>
  )
}

/**
 * Labelled input with optional hint, character counter and error, wired with aria-describedby.
 * `dir` / `lang` follow the content (e.g. Arabic names right-to-left, slugs left-to-right).
 */
export function TextField({
  id,
  label,
  value,
  onChange,
  error,
  hint,
  max,
  optional,
  dir,
  lang,
  multiline,
  inputMode,
  action,
}: {
  id: string
  label: string
  value: string
  onChange: (value: string) => void
  error?: string
  hint?: string
  max?: number
  optional?: boolean
  dir?: 'ltr' | 'rtl'
  lang?: string
  multiline?: boolean
  inputMode?: 'numeric'
  action?: ReactNode
}) {
  const c = useAdminText().catalog
  const describedBy = [error ? `${id}-error` : '', hint ? `${id}-hint` : ''].filter(Boolean).join(' ') || undefined
  const common = {
    id,
    value,
    dir,
    lang,
    'aria-invalid': Boolean(error),
    'aria-describedby': describedBy,
  }
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between gap-3">
        <label htmlFor={id} className="text-sm font-medium text-slate-200">
          {label}
          {optional && <span className="ms-1.5 text-xs font-normal text-slate-500">({c.optional})</span>}
        </label>
        {action}
      </div>
      {multiline ? (
        <textarea {...common} rows={3} onChange={(event) => onChange(event.target.value)} className={`${fieldClass} min-h-20 resize-y`} />
      ) : (
        <input {...common} inputMode={inputMode} onChange={(event) => onChange(event.target.value)} className={`${fieldClass} ${dir === 'ltr' ? 'rtl:text-right' : ''}`} />
      )}
      {(hint || max) && (
        <div className="mt-1 flex justify-between gap-3 text-xs text-slate-500">
          <span id={hint ? `${id}-hint` : undefined}>{hint ?? ''}</span>
          {max && <span className={value.length > max ? 'text-rose-300' : ''}>{value.length}/{max}</span>}
        </div>
      )}
      {error && (
        <p id={`${id}-error`} className="mt-1 text-xs text-rose-300">
          {error}
        </p>
      )}
    </div>
  )
}

/** Whether a technology is shown on the public website. */
export function VisibilityBadge({ visible }: { visible: boolean }) {
  const s = useAdminText().technologies
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap ${
        visible ? 'border-emerald-300/25 bg-emerald-400/10 text-emerald-200' : 'border-white/15 bg-white/[0.04] text-slate-300'
      }`}
    >
      <span aria-hidden="true" className={`size-1.5 rounded-full ${visible ? 'bg-emerald-300' : 'bg-slate-500'}`} />
      {visible ? s.visible : s.hidden}
    </span>
  )
}

/** Read state of a contact message (A7). */
export function MessageStatusBadge({ status }: { status: MessageStatus }) {
  const s = useAdminText().messages
  const tone =
    status === 'unread'
      ? 'border-cyan-300/30 bg-cyan-300/10 text-cyan-100'
      : status === 'read'
        ? 'border-white/10 bg-white/[0.04] text-slate-300'
        : 'border-amber-300/25 bg-amber-400/10 text-amber-200'
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium whitespace-nowrap ${tone}`}>
      {status === 'unread' && <span aria-hidden="true" className="size-1.5 rounded-full bg-cyan-300" />}
      {s.statuses[status]}
    </span>
  )
}

/** "Linked to N projects" + the reminder that linked items are never deleted. */
export function UsageCard({ count }: { count: number }) {
  const c = useAdminText().catalog
  return (
    <section className="glass rounded-3xl p-5">
      <h2 className="mb-3 font-display text-base font-semibold text-white">{c.usage}</h2>
      <p className="text-sm text-slate-200">{count > 0 ? c.linkedProjects(count) : c.notLinked}</p>
      <p className="mt-2 text-xs leading-relaxed text-slate-400">{c.inUseNote}</p>
    </section>
  )
}

export const isSortOrder = (value: string) => /^\d{1,5}$/.test(value.trim()) && Number(value) <= 65535

/** Focus the first field (in the given order) that has an error, after React has rendered it. */
export function focusFirstError(order: { key: string; id: string }[], errors: Errors) {
  const first = order.find(({ key }) => errors[key])
  if (first) window.setTimeout(() => document.getElementById(first.id)?.focus(), 0)
}

/**
 * Server field errors → localized messages (the server's own texts are English only).
 * `messages` maps a field key to its localized "already used" text.
 */
export function mapServerErrors(
  fieldErrors: Record<string, string[]>,
  texts: { required: string; tooLong: (max: number) => string; invalidSlug: string; invalidNumber: string; failed: string },
  extra: { taken: (key: string) => string | undefined; max: (key: string) => number | undefined; invalid?: (key: string) => string | undefined },
): Errors {
  const errors: Errors = {}
  for (const [key, messages] of Object.entries(fieldErrors)) {
    const message = (messages[0] ?? '').toLowerCase()
    const taken = extra.taken(key)
    if (key === 'sort_order') errors[key] = texts.invalidNumber
    else if (message.includes('already') && taken) errors[key] = taken
    else if (message.includes('required')) errors[key] = texts.required
    else if (message.includes('greater than') && extra.max(key)) errors[key] = texts.tooLong(extra.max(key)!)
    else if (key.endsWith('slug')) errors[key] = texts.invalidSlug
    else errors[key] = extra.invalid?.(key) ?? texts.failed
  }
  return errors
}
