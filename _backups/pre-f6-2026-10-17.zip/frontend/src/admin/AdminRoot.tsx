import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { Outlet } from 'react-router'
import { RouteProgress } from '../components/ui/RouteStates'
import type { Locale } from '../i18n/config'
import { I18nProvider } from '../i18n/I18nProvider'
import { AdminAuthProvider } from './AdminAuth'
import { loadAdminLocale, saveAdminLocale } from './locale'

const AdminLocaleContext = createContext<{ locale: Locale; setLocale: (locale: Locale) => void } | null>(null)

export function useAdminLocale() {
  const value = useContext(AdminLocaleContext)
  if (!value) throw new Error('useAdminLocale must be used inside <AdminRoot>')
  return value
}

/** Asks search engines not to index any administration page while it is displayed. */
function useNoIndex() {
  useEffect(() => {
    const meta = document.createElement('meta')
    meta.name = 'robots'
    meta.content = 'noindex, nofollow'
    document.head.append(meta)
    return () => meta.remove()
  }, [])
}

/**
 * Root of /admin (lazy chunk): interface language (en/ar, RTL/LTR through I18nProvider),
 * the session state from Laravel, and the child pages.
 */
export function AdminRoot() {
  const [locale, setLocaleState] = useState<Locale>(loadAdminLocale)
  useNoIndex()

  const setLocale = useCallback((next: Locale) => {
    saveAdminLocale(next)
    setLocaleState(next)
  }, [])

  return (
    <AdminLocaleContext value={{ locale, setLocale }}>
      <I18nProvider locale={locale}>
        <AdminAuthProvider>
          <RouteProgress />
          <Outlet />
        </AdminAuthProvider>
      </I18nProvider>
    </AdminLocaleContext>
  )
}
