import { detectPreferredLocale, isLocale, type Locale } from '../i18n/config'

/*
 * Interface language of the administration. It is not part of the URL (/admin is one
 * address): the choice is remembered in this browser only, and defaults to the visitor's
 * preferred language (site cookie, then browser languages). Kept tiny: this module is
 * also used by the router fallbacks, which load before the admin code.
 */
const STORAGE_KEY = 'admin-locale'

export function loadAdminLocale(): Locale {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY)
    if (isLocale(saved)) return saved
  } catch {
    // Storage blocked (private mode, policy): fall back to the detected language.
  }
  return detectPreferredLocale()
}

export function saveAdminLocale(locale: Locale): void {
  try {
    window.localStorage.setItem(STORAGE_KEY, locale)
  } catch {
    // Not persisted; the choice still applies until the page is reloaded.
  }
}
