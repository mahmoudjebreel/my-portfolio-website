import { LoadingLabel } from '../components/ui/DataStates'
import { RouteError } from '../components/ui/RouteStates'
import { I18nProvider } from '../i18n/I18nProvider'
import { loadAdminLocale } from './locale'

/*
 * Rendered by the router before the admin chunk has loaded, so they live in the main
 * bundle and stay tiny: the admin language comes from local storage, the texts from the
 * public dictionaries.
 */

export function AdminBootFallback() {
  return (
    <I18nProvider locale={loadAdminLocale()}>
      <div data-testid="admin-boot" className="grid min-h-[100svh] place-items-center">
        <LoadingLabel />
        <span aria-hidden="true" className="size-10 rounded-full border-2 border-white/15 border-t-cyan-300 motion-safe:animate-spin" />
      </div>
    </I18nProvider>
  )
}

/** The admin code could not be downloaded (offline, new deployment) or failed to render. */
export function AdminRouteError() {
  return (
    <I18nProvider locale={loadAdminLocale()}>
      <RouteError />
    </I18nProvider>
  )
}
