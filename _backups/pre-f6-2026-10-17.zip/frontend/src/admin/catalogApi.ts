/**
 * Admin categories & technologies API (Laravel, routes/admin.php — A5). Every call needs an
 * administrator session; state-changing calls send the CSRF token (withCsrf). No delete.
 */
import { apiGet, apiSend, type RequestOptions } from '../api/client'
import type { Paginated } from '../api/types'
import { withCsrf } from './api'
import type { ByLocale } from './projectsApi'

export type TechnologyGroup = 'frontend' | 'backend' | 'database' | 'tools'
export const TECHNOLOGY_GROUPS: TechnologyGroup[] = ['frontend', 'backend', 'database', 'tools']

export interface CategoryNames {
  name: string
  slug: string
}

export interface AdminCategory {
  id: number
  sort_order: number
  translations: ByLocale<CategoryNames | null>
  projects_count: number
  /** Linked to at least one project: any future delete must refuse it. */
  in_use: boolean
  updated_at: string | null
}

export interface CategoryPayload {
  sort_order: number
  translations: ByLocale<CategoryNames | null>
}

export interface TechnologyTexts {
  display_name: string | null
  description: string | null
}

export interface AdminTechnology {
  id: number
  name: string
  slug: string
  group: TechnologyGroup
  icon: string | null
  is_visible: boolean
  sort_order: number
  translations: ByLocale<TechnologyTexts | null>
  projects_count: number
  /** Linked to at least one project: any future delete must refuse it. */
  in_use: boolean
  updated_at: string | null
}

export interface TechnologyPayload {
  name: string
  slug: string
  group: TechnologyGroup
  icon: string | null
  sort_order: number
  translations: ByLocale<TechnologyTexts | null>
  /** Read by the server only when creating; an update never changes visibility. */
  is_visible?: boolean
}

export interface CatalogListParams {
  q?: string
  page?: number
  perPage?: number
}

export interface TechnologyListParams extends CatalogListParams {
  group?: TechnologyGroup
  visibility?: 'visible' | 'hidden'
}

export function listCategories(params: CatalogListParams, options?: RequestOptions): Promise<Paginated<AdminCategory>> {
  return apiGet<Paginated<AdminCategory>>('/admin/categories', { q: params.q, page: params.page, per_page: params.perPage }, options)
}

export async function getCategory(id: number, options?: RequestOptions): Promise<AdminCategory> {
  return (await apiGet<{ data: AdminCategory }>(`/admin/categories/${id}`, {}, options)).data
}

export async function createCategory(payload: CategoryPayload): Promise<AdminCategory> {
  const body = await withCsrf(() => apiSend<{ data: AdminCategory }>('POST', '/admin/categories', payload))
  return body!.data
}

export async function updateCategory(id: number, payload: CategoryPayload): Promise<AdminCategory> {
  const body = await withCsrf(() => apiSend<{ data: AdminCategory }>('PUT', `/admin/categories/${id}`, payload))
  return body!.data
}

export function listTechnologies(params: TechnologyListParams, options?: RequestOptions): Promise<Paginated<AdminTechnology>> {
  return apiGet<Paginated<AdminTechnology>>(
    '/admin/technologies',
    { q: params.q, group: params.group, visibility: params.visibility, page: params.page, per_page: params.perPage },
    options,
  )
}

export async function getTechnology(id: number, options?: RequestOptions): Promise<AdminTechnology> {
  return (await apiGet<{ data: AdminTechnology }>(`/admin/technologies/${id}`, {}, options)).data
}

export async function createTechnology(payload: TechnologyPayload): Promise<AdminTechnology> {
  const body = await withCsrf(() => apiSend<{ data: AdminTechnology }>('POST', '/admin/technologies', payload))
  return body!.data
}

export async function updateTechnology(id: number, payload: TechnologyPayload): Promise<AdminTechnology> {
  const sent: TechnologyPayload = { ...payload }
  delete sent.is_visible // visibility is chosen only when creating
  const body = await withCsrf(() => apiSend<{ data: AdminTechnology }>('PUT', `/admin/technologies/${id}`, sent))
  return body!.data
}

/** Same icon rule as the API (TechnologyRequest::ICON_PATTERN). */
export const ICON_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:/-]*$/
