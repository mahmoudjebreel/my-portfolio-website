import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { useDocumentMeta } from '../lib/useDocumentMeta'
import { useAdminText } from './i18n'

/**
 * Title of the current admin page. Pages declare it with useAdminPage(); the header shows it
 * as the page's single h1, and it also becomes the browser tab title.
 */
const AdminPageTitleContext = createContext<{ title: string | null; setTitle: (title: string | null) => void } | null>(null)

export function AdminPageTitleProvider({ children }: { children: ReactNode }) {
  const [title, setTitle] = useState<string | null>(null)
  return <AdminPageTitleContext value={{ title, setTitle }}>{children}</AdminPageTitleContext>
}

export function useAdminPageTitle(): string | null {
  return useContext(AdminPageTitleContext)?.title ?? null
}

export function useAdminPage(title: string): void {
  const a = useAdminText()
  const setTitle = useContext(AdminPageTitleContext)?.setTitle
  useDocumentMeta(`${title} · ${a.brand}`)

  useEffect(() => {
    if (!setTitle) return
    setTitle(title)
    return () => setTitle(null)
  }, [title, setTitle])
}
