import { useCallback, useEffect, useRef, useState } from 'react'
import { ApiError } from '../api/client'
import { useAdminAuth } from './AdminAuth'

export type AdminDataStatus = 'loading' | 'success' | 'error'

export interface AdminData<T> {
  status: AdminDataStatus
  data: T | undefined
  error: ApiError | undefined
  /** Fetch again (after an error, or to refresh after a change). */
  reload: () => void
  /** Replace the loaded value locally (e.g. one updated row). */
  setData: (update: (current: T) => T) => void
}

const toApiError = (error: unknown): ApiError =>
  error instanceof ApiError ? error : new ApiError('invalid_response', 'Unexpected error.', { cause: error })

/**
 * Loads admin data without any shared cache: the administration always shows what the
 * server returns now. The request is cancelled when the key changes or on unmount.
 * A 401/403/419 hands over to the session logic (sign-in page with the reason).
 */
export function useAdminData<T>(key: string | null, fetcher: (signal: AbortSignal) => Promise<T>): AdminData<T> {
  const { handleAuthError } = useAdminAuth()
  const fetcherRef = useRef(fetcher)
  const [attempt, setAttempt] = useState(0)
  const [settled, setSettled] = useState<{ requestId: string; data?: T; error?: ApiError } | null>(null)

  useEffect(() => {
    fetcherRef.current = fetcher
  })

  const requestId = key === null ? null : `${key}#${attempt}`

  useEffect(() => {
    if (requestId === null) return
    const controller = new AbortController()
    fetcherRef.current(controller.signal).then(
      (data) => {
        if (!controller.signal.aborted) setSettled({ requestId, data })
      },
      (caught: unknown) => {
        const error = toApiError(caught)
        if (controller.signal.aborted || error.kind === 'aborted') return
        if (handleAuthError(error)) return
        setSettled({ requestId, error })
      },
    )
    return () => controller.abort()
  }, [requestId, handleAuthError])

  const reload = useCallback(() => setAttempt((value) => value + 1), [])
  const setData = useCallback((update: (current: T) => T) => {
    setSettled((current) => (current && current.data !== undefined ? { ...current, data: update(current.data) } : current))
  }, [])

  if (settled === null || settled.requestId !== requestId) {
    return { status: 'loading', data: undefined, error: undefined, reload, setData }
  }
  return settled.error
    ? { status: 'error', data: undefined, error: settled.error, reload, setData }
    : { status: 'success', data: settled.data, error: undefined, reload, setData }
}
