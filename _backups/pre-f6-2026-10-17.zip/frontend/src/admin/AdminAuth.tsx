import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { ApiError } from '../api/client'
import { fetchCurrentAdmin, signIn as apiSignIn, signOut as apiSignOut, type AdminUser } from './api'

/**
 * Admin session state, derived only from Laravel's answers: GET /admin/me decides who is
 * signed in. Nothing is stored locally; reloading the page asks the server again. Every
 * protection is enforced by the server — this state only chooses what to display.
 */
export type AdminAuthStatus =
  | 'checking' // first GET /admin/me in progress
  | 'authenticated'
  | 'guest' // no valid admin session
  | 'unavailable' // the server could not be reached to check the session

/** Why the visitor is a guest, shown on the sign-in page. */
export type GuestReason = 'expired' | 'signedOut' | 'forbidden' | null

interface AdminAuthValue {
  status: AdminAuthStatus
  user: AdminUser | null
  reason: GuestReason
  /** Error of the last session check when status is "unavailable". */
  error: ApiError | null
  /** Throws an ApiError when the sign-in fails (the page shows it). */
  signIn: (email: string, password: string) => Promise<void>
  /** Throws an ApiError when the server could not be reached (still signed in). */
  signOut: () => Promise<void>
  /** Asks the server again (retry after "unavailable"). */
  recheck: () => void
  /** For admin pages: reacts to a 401/419/403 from any admin request. Returns true when handled. */
  handleAuthError: (error: unknown) => boolean
}

const AdminAuthContext = createContext<AdminAuthValue | null>(null)

type State = { status: AdminAuthStatus; user: AdminUser | null; reason: GuestReason; error: ApiError | null }

const guest = (reason: GuestReason): State => ({ status: 'guest', user: null, reason, error: null })

const toApiError = (error: unknown): ApiError =>
  error instanceof ApiError ? error : new ApiError('invalid_response', 'Unexpected error.', { cause: error })

/** Session answers that mean "not (or no longer) an administrator". */
function guestReasonFor(error: ApiError, wasSignedIn: boolean): GuestReason | undefined {
  if (error.kind === 'forbidden') return 'forbidden'
  if (error.kind === 'unauthenticated' || error.kind === 'csrf') return wasSignedIn ? 'expired' : null
  return undefined
}

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>({ status: 'checking', user: null, reason: null, error: null })
  const [attempt, setAttempt] = useState(0)

  // Session check: on load and on every "recheck".
  useEffect(() => {
    const controller = new AbortController()
    fetchCurrentAdmin({ signal: controller.signal }).then(
      (user) => setState({ status: 'authenticated', user, reason: null, error: null }),
      (caught: unknown) => {
        const error = toApiError(caught)
        if (error.kind === 'aborted') return
        const reason = guestReasonFor(error, false)
        setState(reason === undefined ? { status: 'unavailable', user: null, reason: null, error } : guest(reason))
      },
    )
    return () => controller.abort()
  }, [attempt])

  // Returning to the tab: confirm the session is still valid (it ends after 120 minutes of
  // inactivity). A network error keeps the current state; only the server can sign out.
  useEffect(() => {
    if (state.status !== 'authenticated') return
    const onVisible = () => {
      if (document.visibilityState !== 'visible') return
      fetchCurrentAdmin().then(
        (user) => setState((current) => (current.status === 'authenticated' ? { ...current, user } : current)),
        (caught: unknown) => {
          const reason = guestReasonFor(toApiError(caught), true)
          if (reason !== undefined) setState(guest(reason))
        },
      )
    }
    document.addEventListener('visibilitychange', onVisible)
    return () => document.removeEventListener('visibilitychange', onVisible)
  }, [state.status])

  const signIn = useCallback(async (email: string, password: string) => {
    const user = await apiSignIn(email, password)
    setState({ status: 'authenticated', user, reason: null, error: null })
  }, [])

  const signOut = useCallback(async () => {
    try {
      await apiSignOut()
    } catch (caught) {
      const error = toApiError(caught)
      // Already signed out on the server: the result is the same.
      if (error.kind !== 'unauthenticated') throw error
    }
    setState(guest('signedOut'))
  }, [])

  const recheck = useCallback(() => {
    setState({ status: 'checking', user: null, reason: null, error: null })
    setAttempt((value) => value + 1)
  }, [])

  const handleAuthError = useCallback((caught: unknown) => {
    if (!(caught instanceof ApiError) || guestReasonFor(caught, true) === undefined) return false
    setState((current) => guest(guestReasonFor(caught, current.status === 'authenticated') ?? null))
    return true
  }, [])

  const value = useMemo<AdminAuthValue>(
    () => ({ ...state, signIn, signOut, recheck, handleAuthError }),
    [state, signIn, signOut, recheck, handleAuthError],
  )

  return <AdminAuthContext value={value}>{children}</AdminAuthContext>
}

export function useAdminAuth(): AdminAuthValue {
  const value = useContext(AdminAuthContext)
  if (!value) throw new Error('useAdminAuth must be used inside <AdminAuthProvider>')
  return value
}
