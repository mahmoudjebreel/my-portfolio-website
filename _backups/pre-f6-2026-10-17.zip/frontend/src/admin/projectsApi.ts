/**
 * Admin projects API (Laravel, routes/admin.php — A4). Every call needs an administrator
 * session; state-changing calls send the CSRF token (withCsrf).
 */
import { apiGet, apiSend, type RequestOptions } from '../api/client'
import type { Paginated } from '../api/types'
import type { Locale } from '../i18n/config'
import { withCsrf } from './api'

export type ProjectStatus = 'draft' | 'published'
export type ByLocale<T> = Record<Locale, T>

export const CONTENT_FIELDS = ['title', 'slug', 'short_description', 'description', 'problem', 'solution', 'cover_image_alt'] as const
export const REQUIRED_FIELDS = ['title', 'slug', 'short_description', 'description'] as const
export type ContentField = (typeof CONTENT_FIELDS)[number]
export type ProjectContent = Record<ContentField, string | null>

export interface AdminCategoryRef {
  id: number
  name: ByLocale<string | null>
}

export interface AdminProjectListItem {
  id: number
  status: ProjectStatus
  is_featured: boolean
  sort_order: number
  title: ByLocale<string | null>
  complete: ByLocale<boolean>
  categories: AdminCategoryRef[]
  updated_at: string | null
  published_at: string | null
}

export interface AdminProjectDetail {
  id: number
  status: ProjectStatus
  is_featured: boolean
  sort_order: number
  github_url: string | null
  live_url: string | null
  translations: ByLocale<ProjectContent | null>
  complete: ByLocale<boolean>
  category_ids: number[]
  technology_ids: number[]
  cover: { url: string } | null
  images_count: number
  updated_at: string | null
  published_at: string | null
}

export interface ProjectOptions {
  categories: AdminCategoryRef[]
  technologies: { id: number; name: string; group: 'frontend' | 'backend' | 'database' | 'tools'; is_visible: boolean }[]
}

export interface ProjectPayload {
  status: ProjectStatus
  is_featured: boolean
  sort_order: number
  github_url: string | null
  live_url: string | null
  category_ids: number[]
  technology_ids: number[]
  translations: ByLocale<Partial<ProjectContent> | null>
}

export interface ProjectListParams {
  q?: string
  status?: ProjectStatus
  category?: number
  page?: number
  perPage?: number
}

export function listProjects(params: ProjectListParams, options?: RequestOptions): Promise<Paginated<AdminProjectListItem>> {
  return apiGet<Paginated<AdminProjectListItem>>(
    '/admin/projects',
    { q: params.q, status: params.status, category: params.category, page: params.page, per_page: params.perPage },
    options,
  )
}

export async function getProject(id: number, options?: RequestOptions): Promise<AdminProjectDetail> {
  return (await apiGet<{ data: AdminProjectDetail }>(`/admin/projects/${id}`, {}, options)).data
}

export async function getProjectOptions(options?: RequestOptions): Promise<ProjectOptions> {
  return (await apiGet<{ data: ProjectOptions }>('/admin/project-options', {}, options)).data
}

export async function createProject(payload: ProjectPayload): Promise<AdminProjectDetail> {
  const body = await withCsrf(() => apiSend<{ data: AdminProjectDetail }>('POST', '/admin/projects', payload))
  return body!.data
}

export async function updateProject(id: number, payload: ProjectPayload): Promise<AdminProjectDetail> {
  const body = await withCsrf(() => apiSend<{ data: AdminProjectDetail }>('PUT', `/admin/projects/${id}`, payload))
  return body!.data
}

export async function setProjectStatus(id: number, status: ProjectStatus): Promise<AdminProjectListItem> {
  const body = await withCsrf(() => apiSend<{ data: AdminProjectListItem }>('PATCH', `/admin/projects/${id}/status`, { status }))
  return body!.data
}

/** Same slug rule as the API. */
export const SLUG_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/

export const hasValue = (value: string | null | undefined) => typeof value === 'string' && value.trim() !== ''

export const isFilled = (content: Partial<ProjectContent> | null | undefined) =>
  CONTENT_FIELDS.some((field) => hasValue(content?.[field]))

export const isComplete = (content: Partial<ProjectContent> | null | undefined) =>
  REQUIRED_FIELDS.every((field) => hasValue(content?.[field])) && SLUG_PATTERN.test(content?.slug ?? '')

/** Lowercase Latin slug from a title (non-Latin characters are dropped). */
export function slugify(value: string): string {
  return value
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 160)
    .replace(/-+$/g, '')
}
