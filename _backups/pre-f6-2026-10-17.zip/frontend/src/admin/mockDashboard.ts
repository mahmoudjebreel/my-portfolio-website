/**
 * MOCK DATA — static sample values for the dashboard preview (phase A3).
 * Nothing here comes from the database or the API, and nothing is ever sent anywhere.
 * The dashboard labels these values as sample data. Replace with API data in a later phase.
 */
import type { Locale } from '../i18n/config'

type Localized = Record<Locale, string>

export interface MockProject {
  id: number
  title: Localized
  category: Localized
  status: 'published' | 'draft'
  /** ISO 8601 UTC */
  updatedAt: string
}

export interface MockMessage {
  id: number
  sender: Localized
  subject: Localized
  /** ISO 8601 UTC */
  receivedAt: string
  read: boolean
}

export const mockProjects: MockProject[] = [
  {
    id: 1,
    title: { en: 'Sample project — Store front', ar: 'مشروع تجريبي — واجهة متجر' },
    category: { en: 'Web Applications', ar: 'تطبيقات الويب' },
    status: 'published',
    updatedAt: '2026-10-16T14:20:00Z',
  },
  {
    id: 2,
    title: { en: 'Sample project — Analytics dashboard', ar: 'مشروع تجريبي — لوحة تحليلات' },
    category: { en: 'Dashboards & Admin Panels', ar: 'لوحات التحكم والإدارة' },
    status: 'draft',
    updatedAt: '2026-10-15T09:05:00Z',
  },
  {
    id: 3,
    title: { en: 'Sample project — Product landing page', ar: 'مشروع تجريبي — صفحة هبوط منتج' },
    category: { en: 'Landing Pages', ar: 'صفحات الهبوط' },
    status: 'published',
    updatedAt: '2026-10-12T17:40:00Z',
  },
  {
    id: 4,
    title: { en: 'Sample project — Booking system', ar: 'مشروع تجريبي — نظام حجوزات' },
    category: { en: 'Web Applications', ar: 'تطبيقات الويب' },
    status: 'draft',
    updatedAt: '2026-10-08T11:15:00Z',
  },
  {
    id: 5,
    title: { en: 'Sample project — Portfolio template', ar: 'مشروع تجريبي — قالب معرض أعمال' },
    category: { en: 'Landing Pages', ar: 'صفحات الهبوط' },
    status: 'published',
    updatedAt: '2026-10-02T08:30:00Z',
  },
]

export const mockMessages: MockMessage[] = [
  {
    id: 1,
    sender: { en: 'Sample sender A', ar: 'مرسل تجريبي أ' },
    subject: { en: 'Website redesign enquiry', ar: 'استفسار عن إعادة تصميم موقع' },
    receivedAt: '2026-10-17T07:45:00Z',
    read: false,
  },
  {
    id: 2,
    sender: { en: 'Sample sender B', ar: 'مرسل تجريبي ب' },
    subject: { en: 'Collaboration on a dashboard', ar: 'تعاون في لوحة تحكم' },
    receivedAt: '2026-10-16T18:10:00Z',
    read: false,
  },
  {
    id: 3,
    sender: { en: 'Sample sender C', ar: 'مرسل تجريبي ج' },
    subject: { en: 'Question about your Laravel work', ar: 'سؤال عن أعمالك في Laravel' },
    receivedAt: '2026-10-15T12:00:00Z',
    read: true,
  },
  {
    id: 4,
    sender: { en: 'Sample sender D', ar: 'مرسل تجريبي د' },
    subject: { en: 'Freelance availability', ar: 'التوفر للعمل الحر' },
    receivedAt: '2026-10-13T16:25:00Z',
    read: true,
  },
]

/** Totals for the stat cards (sample values, consistent with each other). */
export const mockStats = {
  totalProjects: 12,
  publishedProjects: 8,
  draftProjects: 4,
  newMessages: 2,
}
