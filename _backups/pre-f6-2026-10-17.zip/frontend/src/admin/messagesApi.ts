/**
 * Admin contact inbox API (Laravel, routes/admin.php — A7). Every call needs an
 * administrator session; the status change sends the CSRF token (withCsrf).
 * There is no delete call, and nothing here sends an email.
 */
import { apiGet, apiSend, type RequestOptions } from '../api/client'
import type { Paginated } from '../api/types'
import { withCsrf } from './api'

export type MessageStatus = 'unread' | 'read' | 'archived'

export interface AdminMessage {
  id: number
  name: string
  email: string
  /** The stored address when it is a valid email (safe for mailto:), else null. */
  reply_email: string | null
  subject: string
  excerpt: string
  /** Full text, only in the detail response. Always rendered as plain text. */
  message?: string
  locale: 'en' | 'ar' | null
  status: MessageStatus
  read_at: string | null
  created_at: string | null
}

export type MessagePage = Paginated<AdminMessage> & { unread_count: number }
export interface MessageDetail {
  data: AdminMessage
  unread_count: number
}

export interface MessageListParams {
  q?: string
  status?: MessageStatus
  page?: number
  perPage?: number
}

export function listMessages(params: MessageListParams, options?: RequestOptions): Promise<MessagePage> {
  return apiGet<MessagePage>('/admin/messages', { q: params.q, status: params.status, page: params.page, per_page: params.perPage }, options)
}

export function getMessage(id: number, options?: RequestOptions): Promise<MessageDetail> {
  return apiGet<MessageDetail>(`/admin/messages/${id}`, {}, options)
}

export async function setMessageStatus(id: number, status: 'read' | 'unread'): Promise<MessageDetail> {
  const body = await withCsrf(() => apiSend<MessageDetail>('PATCH', `/admin/messages/${id}/status`, { status }))
  return body!
}

/**
 * mailto: link that only opens the visitor's mail program (nothing is sent). Each part of
 * the address is percent-encoded, so characters allowed in email addresses such as ? & #
 * cannot add recipients or headers.
 */
export function replyLink(email: string, subject: string): string {
  const at = email.lastIndexOf('@')
  const address = `${encodeURIComponent(email.slice(0, at))}@${encodeURIComponent(email.slice(at + 1))}`
  const reply = subject.trim() ? `Re: ${subject.trim()}` : 'Re:'
  return `mailto:${address}?subject=${encodeURIComponent(reply)}`
}
