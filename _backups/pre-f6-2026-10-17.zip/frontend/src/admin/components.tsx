import type { ReactNode } from 'react'
import { LoadingLabel } from '../components/ui/DataStates'
import { LOCALE_META, otherLocale } from '../i18n/config'
import { useI18n } from '../i18n/I18nProvider'
import { useAdminAuth } from './AdminAuth'
import { useAdminLocale } from './AdminRoot'
import { useAdminText } from './i18n'

/** Switches the administration language (not part of the URL). */
export function AdminLanguageToggle() {
  const { t } = useI18n()
  const { locale, setLocale } = useAdminLocale()
  const target = otherLocale(locale)

  return (
    <button
      type="button"
      onClick={() => setLocale(target)}
      lang={target}
      aria-label={`${t.language.switchTo} ${LOCALE_META[target].label}`}
      className="glass inline-flex h-10 min-w-10 items-center justify-center gap-2 rounded-full px-3 text-sm font-medium text-white transition hover:border-cyan-300/40 hover:bg-white/10"
    >
      <svg viewBox="0 0 24 24" className="size-4 text-cyan-300" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
        <circle cx="12" cy="12" r="9" />
        <path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3Z" />
      </svg>
      <span>{LOCALE_META[target].label}</span>
    </button>
  )
}

/** Full-screen background shared by the sign-in page and the session states. */
export function AdminBackdrop({ children }: { children: ReactNode }) {
  return (
    <div className="relative isolate grid min-h-[100svh] place-items-center overflow-hidden px-5 py-16">
      <div className="grid-backdrop absolute inset-0 -z-10" aria-hidden="true" />
      <div
        className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.22),transparent_60%),radial-gradient(ellipse_at_bottom_right,rgba(34,211,238,0.12),transparent_55%)]"
        aria-hidden="true"
      />
      {children}
    </div>
  )
}

export function AdminSessionChecking() {
  const a = useAdminText()
  return (
    <AdminBackdrop>
      <div data-testid="admin-checking" className="flex flex-col items-center gap-4 text-slate-300">
        <LoadingLabel />
        <span aria-hidden="true" className="size-10 rounded-full border-2 border-white/15 border-t-cyan-300 motion-safe:animate-spin" />
        <p>{a.boot.checking}</p>
      </div>
    </AdminBackdrop>
  )
}

export function AdminUnavailable() {
  const a = useAdminText()
  const { recheck } = useAdminAuth()
  return (
    <AdminBackdrop>
      <section role="alert" aria-labelledby="admin-unavailable-title" className="glass max-w-md rounded-3xl px-6 py-10 text-center">
        <h1 id="admin-unavailable-title" className="font-display text-2xl font-semibold text-white">
          {a.unavailable.title}
        </h1>
        <p className="mt-3 text-slate-400">{a.unavailable.text}</p>
        <button
          type="button"
          onClick={recheck}
          className="mt-8 rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-6 py-3 font-semibold text-ink-950 transition hover:brightness-110"
        >
          {a.unavailable.retry}
        </button>
      </section>
    </AdminBackdrop>
  )
}

/** Brand mark used in the sidebar and on the sign-in page. */
export function AdminBrand() {
  const a = useAdminText()
  return (
    <span className="flex items-center gap-3">
      <span
        aria-hidden="true"
        className="grid size-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 font-display text-sm font-bold text-ink-950 shadow-[0_0_24px_-4px] shadow-violet-500/60"
      >
        &lt;/&gt;
      </span>
      <span className="font-display text-sm font-semibold tracking-wide text-white">{a.brand}</span>
    </span>
  )
}
