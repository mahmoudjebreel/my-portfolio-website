/**
 * TEST FIXTURES ONLY — fake admin projects API (A4) on top of stubAdminApi. Follows the
 * Laravel rules: drafts need one complete language, publishing needs both, slugs unique per
 * language, server-side pagination, CSRF on writes, no delete route.
 */
import type { AdminProjectDetail, ProjectContent, ProjectOptions, ProjectPayload } from '../admin/projectsApi'
import type { Locale } from '../i18n/config'
import { stubAdminApi, type AdminStubOptions, type StubRequest } from './adminStub'

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })

export const content = (slug: string, overrides: Partial<ProjectContent> = {}): ProjectContent => ({
  title: slug.replace(/-/g, ' ').replace(/^./, (c) => c.toUpperCase()),
  slug,
  short_description: 'Short text',
  description: 'Long text',
  problem: null,
  solution: null,
  cover_image_alt: null,
  ...overrides,
})

const isComplete = (c: Partial<ProjectContent> | null | undefined) =>
  Boolean(c?.title && c.slug && c.short_description && c.description && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(c.slug))

let nextId = 100

export function projectRecord(overrides: Partial<AdminProjectDetail> = {}): AdminProjectDetail {
  const translations = overrides.translations ?? { en: content(`project-${nextId}`), ar: null }
  return {
    id: nextId++,
    status: 'draft',
    is_featured: false,
    sort_order: 0,
    github_url: null,
    live_url: null,
    category_ids: [],
    technology_ids: [],
    cover: null,
    images_count: 0,
    updated_at: '2026-10-16T10:00:00Z',
    published_at: null,
    ...overrides,
    translations,
    complete: { en: isComplete(translations.en), ar: isComplete(translations.ar) },
  }
}

export const OPTIONS: ProjectOptions = {
  categories: [
    { id: 1, name: { en: 'Web Applications', ar: 'تطبيقات الويب' } },
    { id: 2, name: { en: 'Landing Pages', ar: 'صفحات الهبوط' } },
  ],
  technologies: [
    { id: 10, name: 'React', group: 'frontend', is_visible: true },
    { id: 11, name: 'Laravel', group: 'backend', is_visible: true },
    { id: 12, name: 'Old Tool', group: 'tools', is_visible: false },
  ],
}

export interface ProjectsStubOptions extends AdminStubOptions {
  projects?: AdminProjectDetail[]
  list?: 'error' | 'unauthenticated'
}

function listItem(project: AdminProjectDetail) {
  return {
    id: project.id,
    status: project.status,
    is_featured: project.is_featured,
    sort_order: project.sort_order,
    title: { en: project.translations.en?.title ?? null, ar: project.translations.ar?.title ?? null },
    complete: project.complete,
    categories: OPTIONS.categories.filter((category) => project.category_ids.includes(category.id)),
    updated_at: project.updated_at,
    published_at: project.published_at,
  }
}

export function stubProjectsApi(options: ProjectsStubOptions = {}) {
  const projects: AdminProjectDetail[] = [...(options.projects ?? [])]

  const validate = (payload: ProjectPayload, ignoreId?: number) => {
    const errors: Record<string, string[]> = {}
    for (const locale of ['en', 'ar'] as Locale[]) {
      const c = payload.translations[locale]
      const slug = c?.slug
      if (slug && projects.some((p) => p.id !== ignoreId && p.translations[locale]?.slug === slug)) {
        errors[`translations.${locale}.slug`] = ['This slug is already used by another project in this language.']
      }
      if (payload.status === 'published' && !isComplete(c)) {
        errors[`translations.${locale}.title`] = [`The translations.${locale}.title field is required.`]
      }
    }
    if (payload.status === 'published' && !(isComplete(payload.translations.en) && isComplete(payload.translations.ar))) {
      errors.status = ['To publish, complete the English and Arabic content.']
    }
    return errors
  }

  const save = (payload: ProjectPayload, existing?: AdminProjectDetail): AdminProjectDetail => {
    const translations = {
      en: (payload.translations.en as ProjectContent | null) ?? existing?.translations.en ?? null,
      ar: (payload.translations.ar as ProjectContent | null) ?? existing?.translations.ar ?? null,
    }
    return {
      ...(existing ?? projectRecord()),
      status: payload.status,
      is_featured: payload.is_featured,
      sort_order: payload.sort_order,
      github_url: payload.github_url,
      live_url: payload.live_url,
      category_ids: payload.category_ids,
      technology_ids: payload.technology_ids,
      translations,
      complete: { en: isComplete(translations.en), ar: isComplete(translations.ar) },
      updated_at: '2026-10-17T12:00:00Z',
      published_at: payload.status === 'published' ? (existing?.published_at ?? '2026-10-17T12:00:00Z') : (existing?.published_at ?? null),
    }
  }

  const handle = ({ method, url, body, csrfOk }: StubRequest): Response | undefined => {
    const path = url.pathname
    const match = path.match(/^\/api\/admin\/projects\/(\d+)(\/status)?$/)
    const found = match ? projects.find((p) => p.id === Number(match[1])) : undefined

    if (method === 'GET' && path === '/api/admin/project-options') return json({ data: OPTIONS })

    if (method === 'GET' && path === '/api/admin/projects') {
      if (options.list === 'error') return json({ message: 'Server Error' }, 500)
      if (options.list === 'unauthenticated') return json({ message: 'Unauthenticated.' }, 401)
      const q = (url.searchParams.get('q') ?? '').toLowerCase()
      const status = url.searchParams.get('status')
      const category = Number(url.searchParams.get('category'))
      const perPage = Number(url.searchParams.get('per_page') ?? 10)
      const page = Number(url.searchParams.get('page') ?? 1)
      const all = projects
        .filter((p) => !q || [p.translations.en?.title, p.translations.ar?.title].some((t) => t?.toLowerCase().includes(q)))
        .filter((p) => !status || p.status === status)
        .filter((p) => !category || p.category_ids.includes(category))
      const lastPage = Math.max(1, Math.ceil(all.length / perPage))
      const data = all.slice((page - 1) * perPage, page * perPage).map(listItem)
      return json({
        data,
        links: { first: null, last: null, prev: null, next: null },
        meta: { current_page: page, from: data.length ? (page - 1) * perPage + 1 : null, last_page: lastPage, links: [], path: '/api/admin/projects', per_page: perPage, to: null, total: all.length },
      })
    }

    if (method === 'GET' && match && !match[2]) return found ? json({ data: found }) : json({ message: 'Resource not found.' }, 404)

    if (method !== 'GET' && !csrfOk()) return json({ message: 'CSRF token mismatch.' }, 419)

    if (method === 'POST' && path === '/api/admin/projects') {
      const payload = body as ProjectPayload
      const errors = validate(payload)
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      const created = save(payload)
      projects.unshift(created)
      return json({ data: created }, 201)
    }

    if (method === 'PUT' && match && !match[2]) {
      if (!found) return json({ message: 'Resource not found.' }, 404)
      const payload = body as ProjectPayload
      const errors = validate(payload, found.id)
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      Object.assign(found, save(payload, found))
      return json({ data: found })
    }

    if (method === 'PATCH' && match?.[2]) {
      if (!found) return json({ message: 'Resource not found.' }, 404)
      const status = (body as { status: string }).status
      if (status === 'published' && !(found.complete.en && found.complete.ar)) {
        return json({ message: 'To publish, complete the English and Arabic content.', errors: { status: ['To publish, complete the English and Arabic content.'] } }, 422)
      }
      found.status = status as AdminProjectDetail['status']
      return json({ data: listItem(found) })
    }

    return undefined
  }

  const api = stubAdminApi({ signedIn: true, ...options, handle })
  return { ...api, projects }
}
