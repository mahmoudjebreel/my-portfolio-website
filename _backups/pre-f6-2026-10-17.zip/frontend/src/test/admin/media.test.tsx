import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { mediaItem, MEDIA_PROJECTS, siteSettings, stubMediaApi } from '../adminMediaStub'
import { clearAdminCookies } from '../adminStub'
import { renderRoute } from '../renderRoute'

beforeEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

afterEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

const listRequests = (requests: { method: string; path: string; search: string }[]) =>
  requests.filter((request) => request.method === 'GET' && request.path === '/api/admin/media').map((request) => request.search)

const cover = () => mediaItem({ kind: 'cover', id: 1, file_name: 'shop-cover.jpg', mime_type: 'image/jpeg', width: 1600, height: 900, alt: { en: 'Shop home page', ar: null } })
const gallery = () => mediaItem({ id: 7, file_name: 'blog-1.webp', project: { id: 2, status: 'draft', title: MEDIA_PROJECTS[1]!.title }, alt: { en: null, ar: 'صفحة المدونة' } })
const missing = () => mediaItem({ id: 8, file_name: 'lost.webp', available: false, preview_url: null, mime_type: null, size: null })

const png = (name = 'screen.png', type = 'image/png') => new File([new Uint8Array([137, 80, 78, 71])], name, { type })

describe('Admin media — library', () => {
  it('opens from the sidebar and shows thumbnails with project and type', async () => {
    const { requests } = stubMediaApi({ media: [cover(), gallery(), missing()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin')

    await user.click(await screen.findByRole('link', { name: 'Images & media' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Images & media' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/media')

    const tiles = await screen.findAllByRole('button', { name: /^Show details of/ })
    expect(tiles).toHaveLength(3)
    expect(tiles[0]).toHaveTextContent('shop-cover.jpg')
    expect(tiles[0]).toHaveTextContent('Online Shop')
    expect(tiles[0]).toHaveTextContent('Cover')
    expect(within(tiles[0]!).getByRole('img')).toHaveAttribute('src', '/api/admin/media/cover/1/preview')
    expect(tiles[1]).toHaveTextContent('Gallery')
    expect(within(tiles[2]!).queryByRole('img')).toBeNull()
    expect(tiles[2]).toHaveTextContent('File unavailable')
    expect(screen.getByText('3 images · Page 1 of 1')).toBeInTheDocument()
    expect(screen.getByText('Select an image to see its details.')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /delete|remove|replace/i })).toBeNull()
    expect(listRequests(requests)).toEqual(['?page=1&per_page=12'])
  })

  it('shows the details of the selected image without storage paths', async () => {
    stubMediaApi({ media: [cover(), missing()] })
    const user = userEvent.setup()
    renderRoute('/admin/media')

    await user.click(await screen.findByRole('button', { name: 'Show details of shop-cover.jpg' }))
    const details = screen.getByRole('region', { name: 'Image details' })
    expect(within(details).getByText('image/jpeg')).toBeInTheDocument()
    expect(within(details).getByText('47 KB')).toBeInTheDocument()
    expect(within(details).getByText('1600 × 900')).toBeInTheDocument()
    expect(within(details).getByText('Shop home page')).toBeInTheDocument()
    expect(within(details).getByText('Not set — the project title is used.')).toBeInTheDocument()
    expect(within(details).getByRole('link', { name: 'Online Shop' })).toHaveAttribute('href', '/admin/projects/1/edit')
    expect(details).not.toHaveTextContent('storage')

    await user.click(screen.getByRole('button', { name: 'Show details of lost.webp' }))
    expect(screen.getByText('The stored file is missing or its location is not allowed, so it cannot be shown.')).toBeInTheDocument()
  })

  it('searches and filters on the server', async () => {
    const { requests } = stubMediaApi({ media: [cover(), gallery()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/media')

    await screen.findAllByRole('button', { name: /^Show details of/ })
    await user.selectOptions(screen.getByRole('combobox', { name: 'Project' }), '2')
    await waitFor(() => expect(router.state.location.search).toBe('?project=2'))
    expect(await screen.findByText('1 image · Page 1 of 1')).toBeInTheDocument()
    await user.selectOptions(screen.getByRole('combobox', { name: 'Type' }), 'cover')
    expect(await screen.findByText('No images match these filters.')).toBeInTheDocument()
    expect(listRequests(requests)).toContain('?project=2&kind=cover&page=1&per_page=12')

    await user.click(screen.getByRole('button', { name: 'Clear filters' }))
    await user.type(screen.getByRole('searchbox', { name: 'Search by project or file name' }), 'blog')
    await waitFor(() => expect(router.state.location.search).toBe('?q=blog'))
    expect(await screen.findByText('1 image · Page 1 of 1')).toBeInTheDocument()
  })

  it('explains an empty library and a loading error', async () => {
    stubMediaApi()
    const first = renderRoute('/admin/media')
    expect(await screen.findByText('No images yet. Upload the first one to a project gallery.')).toBeInTheDocument()
    first.unmount()

    stubMediaApi({ list: 'error' })
    renderRoute('/admin/media')
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('The images could not be loaded.')
    expect(within(alert).getByRole('button', { name: 'Retry' })).toBeInTheDocument()
  })

  it('is right-to-left in Arabic', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubMediaApi({ media: [cover()] })
    renderRoute('/admin/media')

    expect(await screen.findByRole('heading', { level: 1, name: 'الصور والوسائط' })).toBeInTheDocument()
    expect(await screen.findByText('صورة واحدة · الصفحة 1 من 1')).toBeInTheDocument()
    expect(within(screen.getByRole('button', { name: /^عرض تفاصيل/ })).getByText('متجر إلكتروني')).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
  })
})

describe('Admin media — upload', () => {
  it('checks the file before sending, then uploads to a project gallery', { timeout: 15_000 }, async () => {
    const { requests } = stubMediaApi({ media: [cover()] })
    const user = userEvent.setup({ applyAccept: false })
    renderRoute('/admin/media')

    await screen.findAllByRole('button', { name: /^Show details of/ })
    await user.click(screen.getByRole('button', { name: 'Upload image' }))
    const form = screen.getByRole('region', { name: 'Upload an image to a project gallery' })
    await user.click(within(form).getByRole('button', { name: 'Upload' }))
    expect(within(form).getAllByText('This field is required.')).toHaveLength(2)

    await user.selectOptions(within(form).getByLabelText('Project'), '2')
    await user.upload(within(form).getByLabelText('Image file'), new File(['hello'], 'notes.txt', { type: 'text/plain' }))
    await user.click(within(form).getByRole('button', { name: 'Upload' }))
    expect(within(form).getByText('Only JPG, PNG and WebP images are accepted.')).toBeInTheDocument()

    const big = png('big.png')
    Object.defineProperty(big, 'size', { value: 5 * 1024 * 1024 + 1 })
    await user.upload(within(form).getByLabelText('Image file'), big)
    await user.click(within(form).getByRole('button', { name: 'Upload' }))
    expect(within(form).getByText('The image may not be larger than 5 MB.')).toBeInTheDocument()
    expect(requests.some((request) => request.method === 'POST')).toBe(false)

    await user.upload(within(form).getByLabelText('Image file'), png())
    await user.type(within(form).getByLabelText(/Alternative text \(English\)/), 'Blog home')
    await user.click(within(form).getByRole('button', { name: 'Upload' }))

    expect(await screen.findByText('The image has been added to “Blog”.')).toBeInTheDocument()
    const post = requests.find((request) => request.method === 'POST' && request.path === '/api/admin/media')!
    expect(post.headers.get('X-XSRF-TOKEN')).toBeTruthy()
    expect(post.headers.get('Content-Type')).toBeNull()
    const sent = post.body as FormData
    expect(sent.get('project_id')).toBe('2')
    expect((sent.get('file') as File).name).toBe('screen.png')
    expect(sent.get('alt[en]')).toBe('Blog home')
    expect(sent.has('alt[ar]')).toBe(false)
    expect(sent.has('path')).toBe(false)

    const details = await screen.findByRole('region', { name: 'Image details' })
    expect(within(details).getByText('6f1c2a9e-0000-4000-8000-000000000001.webp')).toBeInTheDocument()
    expect(screen.queryByRole('region', { name: 'Upload an image to a project gallery' })).toBeNull()
  })

  it('explains a file the server refuses', { timeout: 15_000 }, async () => {
    stubMediaApi({ uploadError: 'The file is not a valid JPG, PNG or WebP image.' })
    const user = userEvent.setup()
    renderRoute('/admin/media')

    await user.click(await screen.findByRole('button', { name: 'Upload image' }))
    const form = screen.getByRole('region', { name: 'Upload an image to a project gallery' })
    await user.selectOptions(within(form).getByLabelText('Project'), '1')
    await user.upload(within(form).getByLabelText('Image file'), png('fake.png'))
    await user.click(within(form).getByRole('button', { name: 'Upload' }))

    expect(await screen.findByText('The file is not a valid image, or its dimensions are too large.')).toBeInTheDocument()
    expect(within(form).getByLabelText('Image file')).toHaveAttribute('aria-invalid', 'true')
  })
})

describe('Admin site settings', () => {
  const loaded = () =>
    siteSettings({
      texts: { display_name: { en: 'Jebreel', ar: 'جبريل' }, footer_text: { en: 'Built with care', ar: null } },
      values: { github_url: 'https://github.com/example', notification_email: 'alerts@example.com' },
    })

  it('opens from the sidebar and shows the stored values without saving anything', async () => {
    const { requests } = stubMediaApi({ settings: loaded() })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin')

    await user.click(await screen.findByRole('link', { name: 'Site settings' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Site settings' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/settings')

    const name = await screen.findByRole('group', { name: 'Display name' })
    expect(within(name).getByLabelText('English')).toHaveValue('Jebreel')
    expect(within(name).getByLabelText('English')).toHaveAttribute('dir', 'ltr')
    expect(within(name).getByLabelText('Arabic')).toHaveValue('جبريل')
    expect(within(name).getByLabelText('Arabic')).toHaveAttribute('dir', 'rtl')
    expect(screen.getByLabelText(/GitHub profile URL/)).toHaveValue('https://github.com/example')
    expect(screen.getByLabelText(/Notification email/)).toHaveValue('alerts@example.com')
    expect(screen.getByText('Private: used for notifications, never shown on the website.')).toBeInTheDocument()
    expect(screen.getByText('Set, but the file is not available.')).toBeInTheDocument()
    expect(screen.getByText('Not set')).toBeInTheDocument()
    expect(screen.queryByText('You have unsaved changes.')).toBeNull()
    expect(requests.filter((request) => request.method !== 'GET')).toEqual([])
  })

  it('validates, then saves only when the button is pressed', { timeout: 15_000 }, async () => {
    const { requests } = stubMediaApi({ settings: loaded() })
    const user = userEvent.setup()
    renderRoute('/admin/settings')

    const headline = within(await screen.findByRole('group', { name: 'Headline' }))
    await user.type(headline.getByLabelText('Arabic'), 'مرحبًا')
    const github = screen.getByLabelText(/GitHub profile URL/)
    await user.clear(github)
    await user.type(github, 'javascript:alert(1)')
    expect(screen.getByText('You have unsaved changes.')).toBeInTheDocument()
    expect(requests.some((request) => request.method === 'PUT')).toBe(false)

    await user.click(screen.getByRole('button', { name: 'Save settings' }))
    expect(screen.getByText('Enter a full http(s) address.')).toBeInTheDocument()
    expect(github).toHaveAttribute('aria-invalid', 'true')
    expect(requests.some((request) => request.method === 'PUT')).toBe(false)

    await user.clear(github)
    await user.click(screen.getByRole('button', { name: 'Save settings' }))
    expect(await screen.findByText('The settings have been saved.')).toBeInTheDocument()
    expect(screen.queryByText('You have unsaved changes.')).toBeNull()

    const put = requests.find((request) => request.method === 'PUT')!
    expect(put.path).toBe('/api/admin/site-settings')
    expect(put.headers.get('X-XSRF-TOKEN')).toBeTruthy()
    const body = put.body as { texts: Record<string, { en: string | null; ar: string | null }>; values: Record<string, string | null> }
    expect(body.texts.hero_headline).toEqual({ en: null, ar: 'مرحبًا' })
    expect(body.texts.display_name).toEqual({ en: 'Jebreel', ar: 'جبريل' })
    expect(body.values).toEqual({ contact_email: null, github_url: null, linkedin_url: null, notification_email: 'alerts@example.com' })
    expect(Object.keys(body.texts)).toHaveLength(10)
  })

  it('shows server validation errors in the interface language and can discard changes', { timeout: 15_000 }, async () => {
    stubMediaApi({ settings: loaded(), saveErrors: { 'values.contact_email': ['The values.contact_email field must be a valid email address.'] } })
    const user = userEvent.setup()
    renderRoute('/admin/settings')

    const email = await screen.findByLabelText(/Public contact email/)
    await user.type(email, 'owner@example.com')
    await user.click(screen.getByRole('button', { name: 'Save settings' }))
    expect(await screen.findByText('Enter a valid email address.')).toBeInTheDocument()
    expect(screen.getByText('Please correct the highlighted fields.')).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Discard changes' }))
    expect(email).toHaveValue('')
    expect(screen.queryByText('You have unsaved changes.')).toBeNull()
  })

  it('explains a loading error', async () => {
    stubMediaApi({ settingsLoad: 'error' })
    renderRoute('/admin/settings')
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('The settings could not be loaded.')
    expect(within(alert).getByRole('button', { name: 'Retry' })).toBeInTheDocument()
  })

  it('is right-to-left in Arabic', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubMediaApi({ settings: loaded() })
    renderRoute('/admin/settings')
    expect(await screen.findByRole('heading', { level: 1, name: 'إعدادات الموقع' })).toBeInTheDocument()
    expect(await screen.findByRole('button', { name: 'حفظ الإعدادات' })).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
  })
})
