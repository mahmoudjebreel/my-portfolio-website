import { act, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { safeAdminPath } from '../../admin/pages/AdminLoginPage'
import { OWNER, OWNER_PASSWORD, clearAdminCookies, setXsrfCookie, stubAdminApi } from '../adminStub'
import { renderRoute } from '../renderRoute'

beforeEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

afterEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

async function signInWith(email: string, password: string) {
  const user = userEvent.setup()
  await user.type(await screen.findByLabelText('Email address'), email)
  await user.type(screen.getByLabelText('Password'), password)
  await user.click(screen.getByRole('button', { name: 'Sign in' }))
}

const loginPosts = (requests: ReturnType<typeof stubAdminApi>['requests']) =>
  requests.filter((request) => request.method === 'POST' && request.path === '/api/admin/login')

describe('Admin — access', () => {
  it('sends a guest to the sign-in page and keeps the admin out of search engines', async () => {
    stubAdminApi()
    const { router } = renderRoute('/admin')

    expect(await screen.findByRole('heading', { level: 1, name: 'Sign in' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/login')
    expect(document.querySelector('meta[name="robots"]')).toHaveAttribute('content', 'noindex, nofollow')
    await waitFor(() => expect(document.title).toBe('Sign in · Administration'))
    expect(document.documentElement).toHaveAttribute('dir', 'ltr')
  })

  it('shows a loading state while the session is being checked', async () => {
    stubAdminApi({ pendingMe: true })
    renderRoute('/admin')
    expect(await screen.findByTestId('admin-checking')).toHaveTextContent('Checking your session…')
  })

  it('opens the administration directly for an existing session', async () => {
    const { requests } = stubAdminApi({ signedIn: true })
    renderRoute('/admin')

    expect(await screen.findByRole('heading', { level: 1, name: 'Dashboard' })).toBeInTheDocument()
    expect(screen.getByRole('navigation', { name: 'Administration menu' })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Dashboard' })).toHaveAttribute('aria-current', 'page')
    // Only the admin API is used, never the public data source.
    expect(requests.every((request) => request.path.startsWith('/api/admin/'))).toBe(true)
  })

  it('redirects /admin/login to the administration when already signed in', async () => {
    stubAdminApi({ signedIn: true })
    const { router } = renderRoute('/admin/login')

    expect(await screen.findByRole('heading', { level: 1, name: 'Dashboard' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin')
  })

  it('tells a non-admin session that it has no access', async () => {
    stubAdminApi({ me: 'forbidden' })
    renderRoute('/admin')
    expect(await screen.findByText('This account does not have access to the administration.')).toHaveAttribute('role', 'status')
  })

  it('explains when the server cannot be reached, and retries', async () => {
    const { server } = stubAdminApi({ me: 'network' })
    renderRoute('/admin')

    const alert = await screen.findByRole('alert')
    expect(within(alert).getByRole('heading', { name: 'The administration is unavailable' })).toBeInTheDocument()

    server.me = undefined
    await userEvent.click(within(alert).getByRole('button', { name: 'Try again' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Sign in' })).toBeInTheDocument()
  })

  it('shows its own page for unknown admin addresses', async () => {
    stubAdminApi({ signedIn: true })
    renderRoute('/admin/does-not-exist')
    expect(await screen.findByRole('heading', { level: 1, name: 'Page not found' })).toBeInTheDocument()
    expect(screen.getByRole('link', { name: 'Back to the dashboard' })).toHaveAttribute('href', '/admin')
  })
})

describe('Admin — sign in', () => {
  it('signs in through Laravel with the CSRF token, then opens the overview', async () => {
    const { requests } = stubAdminApi()
    const { router } = renderRoute('/admin')

    await signInWith(OWNER.email, OWNER_PASSWORD)

    expect(await screen.findByRole('heading', { level: 1, name: 'Dashboard' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin')

    // No cookie yet → GET csrf-cookie, then POST with the decoded XSRF-TOKEN value.
    const csrfIndex = requests.findIndex((request) => request.path === '/api/admin/csrf-cookie')
    const [login] = loginPosts(requests)
    expect(csrfIndex).toBeGreaterThanOrEqual(0)
    expect(requests.indexOf(login!)).toBeGreaterThan(csrfIndex)
    expect(login!.headers.get('X-XSRF-TOKEN')).toBe('token=1/x')
    expect(login!.headers.get('Content-Type')).toBe('application/json')
    expect(login!.headers.has('Authorization')).toBe(false)
    expect(login!.body).toEqual({ email: OWNER.email, password: OWNER_PASSWORD })
  })

  it('returns to the page that was requested before signing in', async () => {
    stubAdminApi()
    const { router } = renderRoute('/admin/some/page?x=1')
    expect(await screen.findByRole('heading', { level: 1, name: 'Sign in' })).toBeInTheDocument()

    await signInWith(OWNER.email, OWNER_PASSWORD)

    expect(await screen.findByRole('heading', { level: 1, name: 'Page not found' })).toBeInTheDocument()
    expect(router.state.location.pathname + router.state.location.search).toBe('/admin/some/page?x=1')
  })

  it('shows one generic message for wrong credentials and clears the password', async () => {
    stubAdminApi()
    renderRoute('/admin/login')

    await signInWith(OWNER.email, 'wrong password!')

    expect(await screen.findByRole('alert')).toHaveTextContent('The email address or password is incorrect.')
    expect(screen.queryByText(/do not match our records/)).toBeNull() // server text is not shown
    expect(screen.getByLabelText('Password')).toHaveValue('')
    expect(screen.getByLabelText('Password')).toHaveFocus()
    expect(screen.getByRole('heading', { level: 1, name: 'Sign in' })).toBeInTheDocument()
  })

  it('validates the form before calling the server', async () => {
    const { requests } = stubAdminApi()
    const user = userEvent.setup()
    renderRoute('/admin/login')

    await user.click(await screen.findByRole('button', { name: 'Sign in' }))
    expect(screen.getAllByText('This field is required.')).toHaveLength(2)
    expect(screen.getByLabelText('Email address')).toHaveFocus()
    expect(screen.getByLabelText('Email address')).toHaveAttribute('aria-invalid', 'true')

    await user.type(screen.getByLabelText('Email address'), 'not-an-email')
    await user.type(screen.getByLabelText('Password'), 'x')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))
    expect(screen.getByText('Please enter a valid email address.')).toBeInTheDocument()

    expect(loginPosts(requests)).toHaveLength(0)
  })

  it('reports rate limiting with the waiting time', async () => {
    stubAdminApi({ login: { rateLimited: 42 } })
    renderRoute('/admin/login')
    await signInWith(OWNER.email, OWNER_PASSWORD)
    expect(await screen.findByRole('alert')).toHaveTextContent('Too many attempts. Try again in 42 seconds.')
  })

  it('reports a server that cannot be reached', async () => {
    stubAdminApi({ login: 'network' })
    renderRoute('/admin/login')
    await signInWith(OWNER.email, OWNER_PASSWORD)
    expect(await screen.findByRole('alert')).toHaveTextContent('The server could not be reached.')
  })

  it('recovers once from an expired CSRF token (419) with a fresh cookie', async () => {
    const { requests } = stubAdminApi()
    setXsrfCookie('stale-token')
    renderRoute('/admin/login')

    await signInWith(OWNER.email, OWNER_PASSWORD)

    expect(await screen.findByRole('heading', { level: 1, name: 'Dashboard' })).toBeInTheDocument()
    const posts = loginPosts(requests)
    expect(posts.map((post) => post.headers.get('X-XSRF-TOKEN'))).toEqual(['stale-token', 'token=1/x'])
  })

  it('offers to show the password', async () => {
    stubAdminApi()
    const user = userEvent.setup()
    renderRoute('/admin/login')

    const password = await screen.findByLabelText('Password')
    expect(password).toHaveAttribute('type', 'password')
    expect(password).toHaveAttribute('autocomplete', 'current-password')
    await user.click(screen.getByRole('button', { name: 'Show password' }))
    expect(password).toHaveAttribute('type', 'text')
    expect(screen.getByRole('button', { name: 'Hide password' })).toHaveAttribute('aria-pressed', 'true')
  })
})

describe('Admin — session', () => {
  it('signs out through Laravel and lands on the sign-in page', async () => {
    const { requests, server } = stubAdminApi({ signedIn: true })
    setXsrfCookie('token=0/x')
    server.token = 'token=0/x'
    const { router } = renderRoute('/admin')

    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }))

    expect(await screen.findByText('You have been signed out.')).toHaveAttribute('role', 'status')
    expect(router.state.location.pathname).toBe('/admin/login')
    const logout = requests.find((request) => request.path === '/api/admin/logout')
    expect(logout?.method).toBe('POST')
    expect(logout?.headers.get('X-XSRF-TOKEN')).toBe('token=0/x')
    expect(server.user).toBeNull()
  })

  it('stays signed in and says so when signing out fails', async () => {
    stubAdminApi({ signedIn: true, logout: 'network' })
    renderRoute('/admin')

    await userEvent.click(await screen.findByRole('button', { name: 'Sign out' }))

    expect(await screen.findByRole('alert')).toHaveTextContent('Could not sign out.')
    expect(screen.getByRole('heading', { level: 1, name: 'Dashboard' })).toBeInTheDocument()
  })

  it('notices an expired session when the tab becomes visible again', async () => {
    const { server } = stubAdminApi({ signedIn: true })
    const { router } = renderRoute('/admin')
    await screen.findByRole('heading', { level: 1, name: 'Dashboard' })

    server.user = null // the session ended on the server (120 minutes without activity)
    Object.defineProperty(document, 'visibilityState', { configurable: true, value: 'visible' })
    act(() => document.dispatchEvent(new Event('visibilitychange')))

    expect(await screen.findByText('Your session has expired. Please sign in again.')).toHaveAttribute('role', 'status')
    expect(router.state.location.pathname).toBe('/admin/login')
  })
})

describe('Admin — languages and layout', () => {
  it('switches to Arabic, right-to-left, and remembers the choice', async () => {
    stubAdminApi()
    renderRoute('/admin/login')

    await userEvent.click(await screen.findByRole('button', { name: /Switch language to العربية/ }))

    expect(await screen.findByRole('heading', { level: 1, name: 'تسجيل الدخول' })).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
    expect(document.documentElement).toHaveAttribute('lang', 'ar')
    expect(screen.getByLabelText('البريد الإلكتروني')).toHaveAttribute('dir', 'ltr') // emails stay LTR
    expect(window.localStorage.getItem('admin-locale')).toBe('ar')
  })

  it('opens in the remembered language and shows the Arabic administration', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubAdminApi({ signedIn: true })
    renderRoute('/admin')

    expect(await screen.findByRole('heading', { level: 1, name: 'لوحة التحكم' })).toBeInTheDocument()
    expect(screen.getByRole('navigation', { name: 'قائمة الإدارة' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'تسجيل الخروج' })).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
  })

  it('opens and closes the mobile menu', async () => {
    stubAdminApi({ signedIn: true })
    const user = userEvent.setup()
    renderRoute('/admin')

    const open = await screen.findByRole('button', { name: 'Open menu' })
    expect(open).toHaveAttribute('aria-expanded', 'false')
    await user.click(open)
    expect(open).toHaveAttribute('aria-expanded', 'true')
    await user.keyboard('{Escape}')
    expect(open).toHaveAttribute('aria-expanded', 'false')
  })
})

describe('safeAdminPath', () => {
  it('only returns to admin pages', () => {
    expect(safeAdminPath('/admin')).toBe('/admin')
    expect(safeAdminPath('/admin/projects?page=2')).toBe('/admin/projects?page=2')
    expect(safeAdminPath('//evil.example')).toBe('/admin')
    expect(safeAdminPath('https://evil.example/admin')).toBe('/admin')
    expect(safeAdminPath('/administrator')).toBe('/admin')
    expect(safeAdminPath('/en')).toBe('/admin')
    expect(safeAdminPath('/admin/login')).toBe('/admin') // no redirect loop
    expect(safeAdminPath(undefined)).toBe('/admin')
  })
})
