import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { clearAdminCookies } from '../adminStub'
import { content, projectRecord, stubProjectsApi } from '../adminProjectsStub'
import { renderRoute } from '../renderRoute'

beforeEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

afterEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

const shop = () =>
  projectRecord({
    status: 'published',
    translations: { en: content('online-shop', { title: 'Online Shop' }), ar: content('matjar', { title: 'متجر' }) },
    category_ids: [1],
    updated_at: '2026-10-16T14:20:00Z',
  })
const draft = () => projectRecord({ translations: { en: content('blog-draft', { title: 'Blog draft' }), ar: null }, category_ids: [2] })

const listRequests = (requests: { method: string; path: string; search: string }[]) =>
  requests.filter((request) => request.method === 'GET' && request.path === '/api/admin/projects').map((request) => request.search)

describe('Admin projects — list', () => {
  it('opens from the sidebar and lists real API data', async () => {
    const { requests } = stubProjectsApi({ projects: [shop(), draft()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin')

    await user.click(await screen.findByRole('link', { name: 'Projects' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Projects' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/projects')

    const table = await screen.findByRole('table')
    const rows = within(table).getAllByRole('row').slice(1)
    expect(rows).toHaveLength(2)
    expect(rows[0]).toHaveTextContent('Online Shop')
    expect(rows[0]).toHaveTextContent('Web Applications')
    expect(rows[0]).toHaveTextContent('Published')
    expect(rows[0]).toHaveTextContent('October 16, 2026')
    expect(within(rows[0]!).getByText('AR')).toHaveTextContent('AR complete')
    expect(within(rows[1]!).getByText('AR')).toHaveTextContent('AR incomplete')
    expect(rows[1]).toHaveTextContent('Draft')
    expect(screen.getByText('2 projects · Page 1 of 1')).toBeInTheDocument()
    expect(listRequests(requests)).toEqual(['?page=1&per_page=10'])
  })

  it('searches, filters and paginates on the server', async () => {
    const many = Array.from({ length: 12 }, (_, i) => projectRecord({ translations: { en: content(`item-${i + 1}`, { title: `Item ${i + 1}` }), ar: null } }))
    const { requests } = stubProjectsApi({ projects: [shop(), ...many] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/projects')

    expect(await screen.findByText('13 projects · Page 1 of 2')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Next' }))
    expect(await screen.findByText('13 projects · Page 2 of 2')).toBeInTheDocument()
    expect(router.state.location.search).toBe('?page=2')

    await user.type(screen.getByRole('searchbox'), 'shop')
    await waitFor(() => expect(router.state.location.search).toBe('?q=shop'))
    expect(await screen.findByText('1 project · Page 1 of 1')).toBeInTheDocument()

    await user.selectOptions(screen.getByRole('combobox', { name: 'Status' }), 'published')
    await user.selectOptions(screen.getByRole('combobox', { name: 'Category' }), '1')
    await waitFor(() => expect(router.state.location.search).toBe('?q=shop&status=published&category=1'))
    await screen.findByText('Online Shop')
    expect(listRequests(requests)).toContain('?q=shop&status=published&category=1&page=1&per_page=10')
  })

  it('offers to clear filters when nothing matches, and explains an empty list', async () => {
    stubProjectsApi({ projects: [] })
    const { router } = renderRoute('/admin/projects?status=draft')

    expect(await screen.findByText('No projects match these filters.')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Clear filters' }))
    expect(await screen.findByText('No projects yet. Create the first one.')).toBeInTheDocument()
    expect(router.state.location.search).toBe('')
  })

  it('shows an error with retry', async () => {
    stubProjectsApi({ list: 'error' })
    renderRoute('/admin/projects')
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('The projects could not be loaded.')
    expect(within(alert).getByRole('button', { name: 'Retry' })).toBeInTheDocument()
  })

  it('sends an expired session back to the sign-in page', async () => {
    stubProjectsApi({ list: 'unauthenticated' })
    const { router } = renderRoute('/admin/projects')
    expect(await screen.findByText('Your session has expired. Please sign in again.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/login')
  })

  it('refuses to publish incomplete content, and publishes complete content', async () => {
    const complete = projectRecord({ translations: { en: content('ready', { title: 'Ready' }), ar: content('jahiz', { title: 'جاهز' }) } })
    const { requests } = stubProjectsApi({ projects: [draft(), complete] })
    const user = userEvent.setup()
    renderRoute('/admin/projects')

    await user.click(await screen.findByRole('button', { name: 'Publish: Blog draft' }))
    expect(await screen.findByRole('alert')).toHaveTextContent('To publish, complete the English and Arabic content first.')
    expect(within(screen.getAllByRole('row')[1]!).getByText('Draft')).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Publish: Ready' }))
    expect(await screen.findByText('“Ready” is now published.')).toBeInTheDocument()
    expect(within(screen.getAllByRole('row')[2]!).getByText('Published')).toBeInTheDocument()
    const patch = requests.filter((request) => request.method === 'PATCH').at(-1)!
    expect(patch.path).toMatch(/^\/api\/admin\/projects\/\d+\/status$/)
    expect(patch.body).toEqual({ status: 'published' })
    expect(patch.headers.get('X-XSRF-TOKEN')).toBeTruthy()
  })

  it('is right-to-left in Arabic', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubProjectsApi({ projects: [shop()] })
    renderRoute('/admin/projects')

    expect(await screen.findByRole('heading', { level: 1, name: 'المشاريع' })).toBeInTheDocument()
    expect(await screen.findByText('متجر')).toBeInTheDocument()
    expect(within(screen.getByRole('table')).getByText('منشور')).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
  })
})

describe('Admin projects — form', () => {
  // Types many characters: allow more than the default 5 s on a busy machine.
  it('validates before sending: one language for a draft, both to publish', { timeout: 15_000 }, async () => {
    const { requests } = stubProjectsApi()
    const user = userEvent.setup()
    renderRoute('/admin/projects/new')

    await user.click(await screen.findByRole('button', { name: 'Save project' }))
    expect(await screen.findByText('Fill in the content in at least one language.')).toBeInTheDocument()

    const english = screen.getByRole('region', { name: 'English content' })
    await user.type(within(english).getByLabelText('Title'), 'Portfolio Site')
    await user.click(within(english).getByRole('button', { name: 'Generate from title' }))
    expect(within(english).getByLabelText('Slug')).toHaveValue('portfolio-site')
    await user.click(screen.getByRole('radio', { name: 'Published' }))
    await user.click(screen.getByRole('button', { name: 'Save project' }))

    expect(screen.getByText('To publish, complete the English and Arabic content.')).toBeInTheDocument()
    expect(within(english).getByLabelText('Short description')).toHaveAttribute('aria-invalid', 'true')
    const arabic = screen.getByRole('region', { name: 'Arabic content' })
    expect(within(arabic).getByLabelText('Title')).toHaveAttribute('aria-invalid', 'true')
    expect(requests.some((request) => request.method === 'POST' && request.path === '/api/admin/projects')).toBe(false)
  })

  // Types many characters: allow more than the default 5 s on a busy machine.
  it('creates a draft with one language and returns to the list', { timeout: 15_000 }, async () => {
    const { requests } = stubProjectsApi()
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/projects/new')

    const english = await screen.findByRole('region', { name: 'English content' })
    await user.type(within(english).getByLabelText('Title'), 'Portfolio Site')
    await user.type(within(english).getByLabelText('Slug'), 'portfolio-site')
    await user.type(within(english).getByLabelText('Short description'), 'A bilingual portfolio.')
    await user.type(within(english).getByLabelText('Description'), 'Long description.')
    await user.click(await screen.findByRole('checkbox', { name: 'Web Applications' }))
    await user.click(screen.getByRole('checkbox', { name: 'React' }))
    await user.type(screen.getByLabelText(/Live demo URL/), 'https://example.com')
    await user.click(screen.getByRole('button', { name: 'Save project' }))

    expect(await screen.findByText('The project has been created.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/projects')
    expect(await screen.findByText('Portfolio Site')).toBeInTheDocument()

    const post = requests.find((request) => request.method === 'POST' && request.path === '/api/admin/projects')!
    expect(post.headers.get('X-XSRF-TOKEN')).toBeTruthy()
    expect(post.body).toEqual({
      status: 'draft',
      is_featured: false,
      sort_order: 0,
      github_url: null,
      live_url: 'https://example.com',
      category_ids: [1],
      technology_ids: [10],
      translations: {
        en: {
          title: 'Portfolio Site',
          slug: 'portfolio-site',
          short_description: 'A bilingual portfolio.',
          description: 'Long description.',
          problem: null,
          solution: null,
          cover_image_alt: null,
        },
        ar: null,
      },
    })
  })

  // Types many characters: allow more than the default 5 s on a busy machine.
  it('shows server validation errors in the interface language', { timeout: 15_000 }, async () => {
    stubProjectsApi({ projects: [shop()] })
    const user = userEvent.setup()
    renderRoute('/admin/projects/new')

    const english = await screen.findByRole('region', { name: 'English content' })
    await user.type(within(english).getByLabelText('Title'), 'Copy')
    await user.type(within(english).getByLabelText('Slug'), 'online-shop')
    await user.type(within(english).getByLabelText('Short description'), 'Short')
    await user.type(within(english).getByLabelText('Description'), 'Long')
    await user.click(screen.getByRole('button', { name: 'Save project' }))

    expect(await screen.findByText('This slug is already used by another project in this language.')).toBeInTheDocument()
    expect(within(english).getByLabelText('Slug')).toHaveAttribute('aria-invalid', 'true')
  })

  // Types many characters: allow more than the default 5 s on a busy machine.
  it('loads a project for editing and saves the changes', { timeout: 15_000 }, async () => {
    const project = shop()
    const { requests } = stubProjectsApi({ projects: [project] })
    const user = userEvent.setup()
    const { router } = renderRoute(`/admin/projects/${project.id}/edit`)

    expect(await screen.findByRole('heading', { level: 1, name: 'Edit project' })).toBeInTheDocument()
    const arabic = await screen.findByRole('region', { name: 'Arabic content' })
    expect(within(arabic).getByLabelText('Title')).toHaveValue('متجر')
    expect(within(arabic).getByLabelText('Title')).toHaveAttribute('dir', 'rtl')
    expect(within(arabic).getByLabelText('Slug')).toHaveAttribute('dir', 'ltr')
    expect(screen.getByRole('radio', { name: 'Published' })).toBeChecked()
    expect(screen.getByRole('checkbox', { name: 'Web Applications' })).toBeChecked()

    const title = within(screen.getByRole('region', { name: 'English content' })).getByLabelText('Title')
    await user.clear(title)
    await user.type(title, 'Online Shop v2')
    await user.click(screen.getByRole('button', { name: 'Save project' }))

    expect(await screen.findByText('The project has been saved.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/projects')
    const put = requests.find((request) => request.method === 'PUT')!
    expect(put.path).toBe(`/api/admin/projects/${project.id}`)
    expect((put.body as { translations: { en: { title: string } } }).translations.en.title).toBe('Online Shop v2')
  })

  it('explains a project that does not exist', async () => {
    stubProjectsApi()
    renderRoute('/admin/projects/999999/edit')
    expect(await screen.findByText('This project does not exist.')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /Back to projects/ })).toHaveAttribute('href', '/admin/projects')
  })

  it('shows images read-only', async () => {
    const project = projectRecord({ translations: { en: content('with-cover'), ar: null }, cover: { url: '/storage/projects/cover.jpg' }, images_count: 3 })
    stubProjectsApi({ projects: [project] })
    renderRoute(`/admin/projects/${project.id}/edit`)

    expect(await screen.findByText('Images are managed in a later phase. Existing images are kept unchanged.')).toBeInTheDocument()
    expect(screen.getByText('3 gallery images')).toBeInTheDocument()
    expect(document.querySelector('img[src="/storage/projects/cover.jpg"]')).not.toBeNull()
    expect(screen.queryByRole('button', { name: /upload|delete/i })).toBeNull()
  })
})
