import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { categoryRecord, stubCatalogApi, technologyRecord } from '../adminCatalogStub'
import { clearAdminCookies } from '../adminStub'
import { renderRoute } from '../renderRoute'

beforeEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

afterEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

const listRequests = (requests: { method: string; path: string; search: string }[], path: string) =>
  requests.filter((request) => request.method === 'GET' && request.path === path).map((request) => request.search)

const web = () =>
  categoryRecord({
    sort_order: 1,
    translations: { en: { name: 'Web Applications', slug: 'web-applications' }, ar: { name: 'تطبيقات الويب', slug: 'tatbiqat-alweb' } },
    projects_count: 3,
    updated_at: '2026-10-16T14:20:00Z',
  })
const landing = () => categoryRecord({ sort_order: 2, translations: { en: { name: 'Landing Pages', slug: 'landing-pages' }, ar: null } })

describe('Admin categories — list', () => {
  it('opens from the sidebar and shows both languages and linked projects', async () => {
    const { requests } = stubCatalogApi({ categories: [web(), landing()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin')

    await user.click(await screen.findByRole('link', { name: 'Categories' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Categories' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/categories')

    const table = await screen.findByRole('table')
    expect(within(table).getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual(['English name', 'Arabic name', 'Projects', 'Order', 'Updated', 'Actions'])
    const rows = within(table).getAllByRole('row').slice(1)
    expect(rows[0]).toHaveTextContent('Web Applications')
    expect(within(rows[0]!).getByText('تطبيقات الويب').closest('[dir]')).toHaveAttribute('dir', 'rtl')
    expect(within(rows[0]!).getAllByRole('cell')[2]).toHaveTextContent('3')
    expect(rows[0]).toHaveTextContent('October 16, 2026')
    expect(rows[1]).toHaveTextContent('Not translated')
    expect(within(rows[1]!).getByRole('link', { name: 'Edit: Landing Pages' })).toHaveAttribute('href', expect.stringMatching(/^\/admin\/categories\/\d+\/edit$/))
    expect(screen.getByText('2 categories · Page 1 of 1')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /delete/i })).toBeNull()
    expect(listRequests(requests, '/api/admin/categories')).toEqual(['?page=1&per_page=10'])
  })

  it('searches and paginates on the server', async () => {
    const many = Array.from({ length: 11 }, (_, i) => categoryRecord({ translations: { en: { name: `Group ${i + 1}`, slug: `group-${i + 1}` }, ar: null } }))
    const { requests } = stubCatalogApi({ categories: [web(), ...many] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/categories')

    expect(await screen.findByText('12 categories · Page 1 of 2')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Next' }))
    expect(await screen.findByText('12 categories · Page 2 of 2')).toBeInTheDocument()
    expect(router.state.location.search).toBe('?page=2')

    await user.type(screen.getByRole('searchbox', { name: 'Search by name' }), 'الويب')
    await waitFor(() => expect(router.state.location.search).toBe(`?q=${encodeURIComponent('الويب')}`))
    expect(await screen.findByText('1 category · Page 1 of 1')).toBeInTheDocument()
    expect(listRequests(requests, '/api/admin/categories')).toContain(`?q=${encodeURIComponent('الويب')}&page=1&per_page=10`)
  })

  it('explains an empty list, no results and a loading error', async () => {
    stubCatalogApi()
    const { router } = renderRoute('/admin/categories?q=nothing')
    expect(await screen.findByText('No categories match this search.')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Clear filters' }))
    expect(await screen.findByText('No categories yet. Create the first one.')).toBeInTheDocument()
    expect(router.state.location.search).toBe('')
  })

  it('shows an error with retry, and sends an expired session to sign-in', async () => {
    stubCatalogApi({ list: 'error' })
    const first = renderRoute('/admin/categories')
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('The categories could not be loaded.')
    expect(within(alert).getByRole('button', { name: 'Retry' })).toBeInTheDocument()
    first.unmount()

    stubCatalogApi({ list: 'unauthenticated' })
    const { router } = renderRoute('/admin/categories')
    expect(await screen.findByText('Your session has expired. Please sign in again.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/login')
  })

  it('is right-to-left in Arabic', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubCatalogApi({ categories: [web()] })
    renderRoute('/admin/categories')

    expect(await screen.findByRole('heading', { level: 1, name: 'التصنيفات' })).toBeInTheDocument()
    expect(await screen.findByText('تصنيف واحد · الصفحة 1 من 1')).toBeInTheDocument()
    expect(within(screen.getByRole('table')).getByRole('columnheader', { name: 'الاسم العربي' })).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
  })
})

describe('Admin categories — form', () => {
  it('validates before sending and creates a category in one language', { timeout: 15_000 }, async () => {
    const { requests } = stubCatalogApi()
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/categories/new')

    await user.click(await screen.findByRole('button', { name: 'Save category' }))
    expect(await screen.findByText('Fill in the name in at least one language.')).toBeInTheDocument()

    const english = screen.getByRole('region', { name: 'English name' })
    await user.type(within(english).getByLabelText('Name'), 'Mobile Apps')
    await user.click(screen.getByRole('button', { name: 'Save category' }))
    expect(within(english).getByLabelText('Slug')).toHaveAttribute('aria-invalid', 'true')
    expect(within(english).getByText('This field is required.')).toBeInTheDocument()

    await user.type(within(english).getByLabelText('Slug'), 'Mobile Apps')
    await user.click(screen.getByRole('button', { name: 'Save category' }))
    expect(within(english).getByText('Use lowercase Latin letters, numbers and single hyphens.')).toBeInTheDocument()
    expect(requests.some((request) => request.method === 'POST')).toBe(false)

    await user.click(within(english).getByRole('button', { name: 'Generate from name' }))
    expect(within(english).getByLabelText('Slug')).toHaveValue('mobile-apps')
    await user.click(screen.getByRole('button', { name: 'Save category' }))

    expect(await screen.findByText('The category has been created.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/categories')
    expect(await screen.findByText('Mobile Apps')).toBeInTheDocument()
    const post = requests.find((request) => request.method === 'POST' && request.path === '/api/admin/categories')!
    expect(post.headers.get('X-XSRF-TOKEN')).toBeTruthy()
    expect(post.body).toEqual({ sort_order: 0, translations: { en: { name: 'Mobile Apps', slug: 'mobile-apps' }, ar: null } })
  })

  it('shows a name already in use in the interface language', { timeout: 15_000 }, async () => {
    stubCatalogApi({ categories: [web()] })
    const user = userEvent.setup()
    renderRoute('/admin/categories/new')

    const english = await screen.findByRole('region', { name: 'English name' })
    await user.type(within(english).getByLabelText('Name'), 'Web Applications')
    await user.type(within(english).getByLabelText('Slug'), 'web-applications')
    await user.click(screen.getByRole('button', { name: 'Save category' }))

    expect(await screen.findByText('Another category already uses this name in this language.')).toBeInTheDocument()
    expect(screen.getByText('Another category already uses this slug in this language.')).toBeInTheDocument()
    expect(within(english).getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true')
  })

  it('edits a category, keeps saved languages and shows its usage', { timeout: 15_000 }, async () => {
    const category = web()
    const { requests } = stubCatalogApi({ categories: [category] })
    const user = userEvent.setup()
    renderRoute(`/admin/categories/${category.id}/edit`)

    expect(await screen.findByRole('heading', { level: 1, name: 'Edit category' })).toBeInTheDocument()
    const arabic = await screen.findByRole('region', { name: 'Arabic name' })
    expect(within(arabic).getByLabelText('Name')).toHaveValue('تطبيقات الويب')
    expect(within(arabic).getByLabelText('Name')).toHaveAttribute('dir', 'rtl')
    expect(within(arabic).getByLabelText('Slug')).toHaveAttribute('dir', 'ltr')
    expect(screen.getByText('Linked to 3 projects')).toBeInTheDocument()
    expect(screen.getByText('Deleting is not available. A linked item can never be deleted while projects use it.')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /delete/i })).toBeNull()

    await user.clear(within(arabic).getByLabelText('Name'))
    await user.clear(within(arabic).getByLabelText('Slug'))
    await user.click(screen.getByRole('button', { name: 'Save category' }))
    expect(within(arabic).getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true')
    expect(requests.some((request) => request.method === 'PUT')).toBe(false)

    await user.type(within(arabic).getByLabelText('Name'), 'الويب')
    await user.type(within(arabic).getByLabelText('Slug'), 'alweb')
    const order = screen.getByLabelText('Sort order')
    await user.clear(order)
    await user.type(order, '5')
    await user.click(screen.getByRole('button', { name: 'Save category' }))

    expect(await screen.findByText('The category has been saved.')).toBeInTheDocument()
    const put = requests.find((request) => request.method === 'PUT')!
    expect(put.path).toBe(`/api/admin/categories/${category.id}`)
    expect(put.body).toEqual({
      sort_order: 5,
      translations: { en: { name: 'Web Applications', slug: 'web-applications' }, ar: { name: 'الويب', slug: 'alweb' } },
    })
  })

  it('explains a category that does not exist', async () => {
    stubCatalogApi()
    renderRoute('/admin/categories/999999/edit')
    expect(await screen.findByText('This category does not exist.')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /Back to categories/ })).toHaveAttribute('href', '/admin/categories')
  })
})

const react = () => technologyRecord({ name: 'React', slug: 'react', group: 'frontend', icon: 'simple-icons:react', projects_count: 2, updated_at: '2026-10-16T14:20:00Z' })
const oldTool = () => technologyRecord({ name: 'Old Tool', slug: 'old-tool', group: 'tools', is_visible: false, translations: { en: null, ar: { display_name: 'أداة قديمة', description: null } } })

describe('Admin technologies — list', () => {
  it('opens from the sidebar with icon, group, visibility and usage', async () => {
    const { requests } = stubCatalogApi({ technologies: [react(), oldTool()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin')

    await user.click(await screen.findByRole('link', { name: 'Technologies' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Technologies' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/technologies')

    const rows = within(await screen.findByRole('table')).getAllByRole('row').slice(1)
    const first = within(rows[0]!).getAllByRole('cell').map((cell) => cell.textContent)
    expect(first.slice(0, 6)).toEqual(['Reactreact', 'Front-End', 'simple-icons:react', 'Visible', '2', 'October 16, 2026'])
    expect(rows[1]).toHaveTextContent('No icon')
    expect(rows[1]).toHaveTextContent('Hidden')
    expect(screen.getByText('2 technologies · Page 1 of 1')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /delete/i })).toBeNull()
    expect(listRequests(requests, '/api/admin/technologies')).toEqual(['?page=1&per_page=10'])
  })

  it('filters by group and visibility on the server', async () => {
    const { requests } = stubCatalogApi({ technologies: [react(), oldTool()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/technologies')

    await screen.findByRole('table')
    await user.selectOptions(screen.getByRole('combobox', { name: 'Visibility' }), 'hidden')
    await waitFor(() => expect(router.state.location.search).toBe('?visibility=hidden'))
    expect(await screen.findByText('1 technology · Page 1 of 1')).toBeInTheDocument()
    expect(screen.getByText('Old Tool')).toBeInTheDocument()

    await user.selectOptions(screen.getByRole('combobox', { name: 'Group' }), 'frontend')
    expect(await screen.findByText('No technologies match these filters.')).toBeInTheDocument()
    expect(listRequests(requests, '/api/admin/technologies')).toContain('?group=frontend&visibility=hidden&page=1&per_page=10')
  })

  it('shows a loading error with retry', async () => {
    stubCatalogApi({ list: 'error' })
    renderRoute('/admin/technologies')
    expect(await screen.findByRole('alert')).toHaveTextContent('The technologies could not be loaded.')
  })
})

describe('Admin technologies — form', () => {
  it('creates a hidden technology by default, with an optional icon', { timeout: 15_000 }, async () => {
    const { requests } = stubCatalogApi()
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/technologies/new')

    await user.click(await screen.findByRole('button', { name: 'Save technology' }))
    expect(screen.getByLabelText('Name')).toHaveAttribute('aria-invalid', 'true')
    expect(screen.getByLabelText('Group')).toHaveAttribute('aria-invalid', 'true')

    await user.type(screen.getByLabelText('Name'), 'Tailwind CSS')
    await user.click(screen.getByRole('button', { name: 'Generate from name' }))
    expect(screen.getByLabelText('Slug')).toHaveValue('tailwind-css')
    await user.selectOptions(screen.getByLabelText('Group'), 'frontend')
    await user.type(screen.getByLabelText(/^Icon/), 'bad icon!')
    await user.click(screen.getByRole('button', { name: 'Save technology' }))
    expect(screen.getByText('Use letters, numbers and . _ : / - only.')).toBeInTheDocument()

    await user.clear(screen.getByLabelText(/^Icon/))
    expect(screen.getByRole('checkbox', { name: 'Show on the public website' })).not.toBeChecked()
    expect(screen.getByText('New technologies stay hidden unless you choose to show them.')).toBeInTheDocument()
    const arabic = screen.getByRole('region', { name: 'Arabic texts' })
    await user.type(within(arabic).getByLabelText(/Translated name/), 'تيلويند')
    expect(within(arabic).getByLabelText(/Translated name/)).toHaveAttribute('dir', 'rtl')
    await user.click(screen.getByRole('button', { name: 'Save technology' }))

    expect(await screen.findByText('The technology has been created.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/technologies')
    const post = requests.find((request) => request.method === 'POST' && request.path === '/api/admin/technologies')!
    expect(post.headers.get('X-XSRF-TOKEN')).toBeTruthy()
    expect(post.body).toEqual({
      name: 'Tailwind CSS',
      slug: 'tailwind-css',
      group: 'frontend',
      icon: null,
      sort_order: 0,
      is_visible: false,
      translations: { en: { display_name: null, description: null }, ar: { display_name: 'تيلويند', description: null } },
    })
    expect(await screen.findByText('Hidden')).toBeInTheDocument()
  })

  it('edits a hidden technology without changing its visibility', { timeout: 15_000 }, async () => {
    const tool = oldTool()
    const { requests, technologies } = stubCatalogApi({ technologies: [tool, react()] })
    const user = userEvent.setup()
    renderRoute(`/admin/technologies/${tool.id}/edit`)

    expect(await screen.findByRole('heading', { level: 1, name: 'Edit technology' })).toBeInTheDocument()
    expect(screen.getByLabelText('Name')).toHaveValue('Old Tool')
    expect(screen.getByText('Visibility is not changed when editing: a hidden technology stays hidden.')).toBeInTheDocument()
    expect(screen.queryByRole('checkbox', { name: 'Show on the public website' })).toBeNull()
    expect(screen.getByText('Not linked to any project')).toBeInTheDocument()

    await user.clear(screen.getByLabelText('Name'))
    await user.type(screen.getByLabelText('Name'), 'React')
    await user.click(screen.getByRole('button', { name: 'Save technology' }))
    expect(await screen.findByText('Another technology already uses this name.')).toBeInTheDocument()

    await user.clear(screen.getByLabelText('Name'))
    await user.type(screen.getByLabelText('Name'), 'Legacy Tool')
    await user.click(screen.getByRole('button', { name: 'Save technology' }))

    expect(await screen.findByText('The technology has been saved.')).toBeInTheDocument()
    const put = requests.filter((request) => request.method === 'PUT').at(-1)!
    expect(put.path).toBe(`/api/admin/technologies/${tool.id}`)
    expect(put.body).not.toHaveProperty('is_visible')
    expect(put.body).toMatchObject({ name: 'Legacy Tool', slug: 'old-tool', group: 'tools', icon: null })
    expect(technologies.find((item) => item.id === tool.id)!.is_visible).toBe(false)
  })

  it('explains a technology that does not exist', async () => {
    stubCatalogApi()
    renderRoute('/admin/technologies/999999/edit')
    expect(await screen.findByText('This technology does not exist.')).toBeInTheDocument()
  })
})
