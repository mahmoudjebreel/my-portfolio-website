import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { mockMessages, mockProjects, mockStats } from '../../admin/mockDashboard'
import { OWNER, clearAdminCookies, setXsrfCookie, stubAdminApi } from '../adminStub'
import { renderRoute } from '../renderRoute'

beforeEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

afterEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

async function openDashboard() {
  const api = stubAdminApi({ signedIn: true })
  const view = renderRoute('/admin')
  // The first test of the file also waits for the lazily loaded admin chunks.
  await screen.findByRole('heading', { level: 1, name: 'Dashboard' }, { timeout: 5000 })
  return { ...api, ...view }
}

describe('Admin dashboard (A3, mock data)', () => {
  it('shows the page title in the header, a welcome line and the tab title', async () => {
    await openDashboard()

    const header = screen.getByRole('banner')
    expect(within(header).getByRole('heading', { level: 1, name: 'Dashboard' })).toBeInTheDocument()
    expect(within(header).getByText(OWNER.name)).toBeInTheDocument()
    expect(screen.getByText(`Welcome back, ${OWNER.name}`)).toBeInTheDocument()
    await waitFor(() => expect(document.title).toBe('Dashboard · Administration'))
  })

  it('clearly labels every figure and list as mock data', async () => {
    await openDashboard()

    expect(screen.getByRole('note')).toHaveTextContent('sample data')
    // One badge next to the welcome line and one per list.
    expect(screen.getAllByText('Mock data')).toHaveLength(3)
  })

  it('shows the four summary cards', async () => {
    await openDashboard()

    const summary = screen.getByRole('heading', { name: 'Summary' }).closest('section')!
    const cards = within(summary).getAllByRole('listitem')
    expect(cards.map((card) => card.textContent)).toEqual([
      `Total projects${mockStats.totalProjects}`,
      `Published projects${mockStats.publishedProjects}`,
      `Draft projects${mockStats.draftProjects}`,
      `New messages${mockStats.newMessages}`,
    ])
  })

  it('lists the latest projects with category, status and update date', async () => {
    await openDashboard()

    const panel = screen.getByRole('heading', { name: 'Latest projects' }).closest('section')!
    const table = within(panel).getByRole('table')
    expect(within(table).getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual(['Project', 'Category', 'Status', 'Updated'])

    const rows = within(table).getAllByRole('row').slice(1)
    expect(rows).toHaveLength(mockProjects.length)
    const first = within(rows[0]!).getAllByRole('cell').map((cell) => cell.textContent)
    expect(first).toEqual(['Sample project — Store front', 'Web Applications', 'Published', 'October 16, 2026'])
    expect(within(rows[1]!).getByText('Draft')).toBeInTheDocument()
    expect(within(rows[0]!).getByText('October 16, 2026')).toHaveAttribute('datetime', '2026-10-16T14:20:00Z')
  })

  it('lists the latest contact messages with their read state', async () => {
    await openDashboard()

    const panel = screen.getByRole('heading', { name: 'Latest contact messages' }).closest('section')!
    const items = within(panel).getAllByRole('listitem')
    expect(items).toHaveLength(mockMessages.length)
    expect(items[0]).toHaveTextContent('Sample sender A')
    expect(items[0]).toHaveTextContent('Website redesign enquiry')
    expect(items[0]).toHaveTextContent('October 17, 2026')
    expect(items[0]).toHaveTextContent('Unread')
    expect(items[2]).toHaveTextContent('Read')
  })

  it('makes no API call for the dashboard data', async () => {
    const { requests } = await openDashboard()
    expect(requests.map((request) => request.path)).toEqual(['/api/admin/me'])
  })
})

describe('Admin sidebar', () => {
  it('links every administration section (A4–A7)', async () => {
    await openDashboard()

    const nav = screen.getByRole('navigation', { name: 'Administration menu' })
    expect(within(nav).getByRole('link', { name: 'Dashboard' })).toHaveAttribute('aria-current', 'page')
    const sections = {
      Projects: '/admin/projects',
      Categories: '/admin/categories',
      Technologies: '/admin/technologies',
      'Images & media': '/admin/media',
      'Contact messages': '/admin/messages',
      'Site settings': '/admin/settings',
    }
    for (const [name, href] of Object.entries(sections)) {
      expect(within(nav).getByRole('link', { name }), name).toHaveAttribute('href', href)
    }
    expect(nav.querySelector('[aria-disabled]')).toBeNull()
    expect(within(nav).getByRole('button', { name: 'Sign out' })).toBeInTheDocument()
  })

  it('signs out from the sidebar through Laravel', async () => {
    const { requests, server, router } = await openDashboard()
    setXsrfCookie('token=0/x')
    server.token = 'token=0/x'

    await userEvent.click(within(screen.getByRole('navigation', { name: 'Administration menu' })).getByRole('button', { name: 'Sign out' }))

    expect(await screen.findByText('You have been signed out.')).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/login')
    expect(requests.some((request) => request.method === 'POST' && request.path === '/api/admin/logout')).toBe(true)
  })
})

describe('Admin dashboard in Arabic', () => {
  it('is right-to-left with Arabic labels and Latin digits', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubAdminApi({ signedIn: true })
    renderRoute('/admin')

    expect(await screen.findByRole('heading', { level: 1, name: 'لوحة التحكم' })).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
    expect(screen.getAllByText('بيانات تجريبية')).toHaveLength(3)
    expect(screen.getByText('إجمالي المشاريع')).toBeInTheDocument()
    expect(screen.getByText('مشروع تجريبي — واجهة متجر')).toBeInTheDocument()

    const panel = screen.getByRole('heading', { name: 'آخر المشاريع' }).closest('section')!
    const dates = within(panel)
      .getAllByRole('cell')
      .map((cell) => cell.querySelector('time')?.textContent)
      .filter(Boolean)
    expect(dates.length).toBe(mockProjects.length)
    for (const date of dates) expect(date).not.toMatch(/[٠-٩]/)
    expect(screen.getByRole('navigation', { name: 'قائمة الإدارة' })).toBeInTheDocument()
  })
})
