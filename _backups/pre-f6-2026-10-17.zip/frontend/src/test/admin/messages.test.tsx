import { screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { replyLink } from '../../admin/messagesApi'
import { messageRecord, stubMessagesApi } from '../adminMessagesStub'
import { clearAdminCookies } from '../adminStub'
import { renderRoute } from '../renderRoute'

beforeEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

afterEach(() => {
  clearAdminCookies()
  window.localStorage.clear()
})

const listRequests = (requests: { method: string; path: string; search: string }[]) =>
  requests.filter((request) => request.method === 'GET' && request.path === '/api/admin/messages').map((request) => request.search)

const sara = () => messageRecord({ id: 1, created_at: '2026-10-16T09:30:00Z' })
const omar = () =>
  messageRecord({
    id: 2,
    name: 'عمر خالد',
    email: 'omar@example.com',
    reply_email: 'omar@example.com',
    subject: 'تصميم شعار',
    message: 'مرحبًا، أحتاج شعارًا.',
    locale: 'ar',
    status: 'read',
    read_at: '2026-10-15T10:00:00Z',
    created_at: '2026-10-15T08:00:00Z',
  })
const archived = () => messageRecord({ id: 3, name: 'Old lead', subject: 'Old', status: 'archived', created_at: '2026-10-01T08:00:00Z' })

describe('Admin contact inbox — list', () => {
  it('opens from the sidebar, newest first, with the unread count', async () => {
    const { requests } = stubMessagesApi({ messages: [omar(), sara(), archived()] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin')

    await user.click(await screen.findByRole('link', { name: 'Contact messages' }))
    expect(await screen.findByRole('heading', { level: 1, name: 'Contact messages' })).toBeInTheDocument()
    expect(router.state.location.pathname).toBe('/admin/messages')

    const table = await screen.findByRole('table')
    expect(within(table).getAllByRole('columnheader').map((cell) => cell.textContent)).toEqual(['From', 'Subject', 'Received', 'Status'])
    const rows = within(table).getAllByRole('row').slice(1)
    expect(rows[0]).toHaveTextContent('Sara Ahmed')
    expect(rows[0]).toHaveTextContent('sara@example.com')
    expect(rows[0]).toHaveTextContent('Website redesign')
    expect(rows[0]).toHaveTextContent('October 16, 2026')
    expect(rows[0]).toHaveTextContent('Unread')
    expect(rows[1]).toHaveTextContent('Read')
    expect(rows[2]).toHaveTextContent('Archived')
    expect(screen.getByRole('status')).toHaveTextContent('1 unread message')
    expect(screen.getByText('3 messages · Page 1 of 1')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /delete/i })).toBeNull()
    expect(listRequests(requests)).toEqual(['?page=1&per_page=15'])
  })

  // Types and waits for several server round trips: allow more than the default 5 s on a busy machine.
  it('searches, filters by status and paginates on the server', { timeout: 15_000 }, async () => {
    const many = Array.from({ length: 16 }, (_, i) => messageRecord({ name: `Visitor ${i + 1}`, subject: `Question ${i + 1}`, email: `v${i + 1}@example.com` }))
    const { requests } = stubMessagesApi({ messages: [omar(), ...many] })
    const user = userEvent.setup()
    const { router } = renderRoute('/admin/messages')

    expect(await screen.findByText('17 messages · Page 1 of 2')).toBeInTheDocument()
    await user.click(screen.getByRole('button', { name: 'Next' }))
    expect(await screen.findByText('17 messages · Page 2 of 2')).toBeInTheDocument()

    await user.selectOptions(screen.getByRole('combobox', { name: 'Status' }), 'read')
    await waitFor(() => expect(router.state.location.search).toBe('?status=read'))
    expect(await screen.findByText('1 message · Page 1 of 1')).toBeInTheDocument()

    await user.click(screen.getByRole('combobox', { name: 'Status' }))
    await user.selectOptions(screen.getByRole('combobox', { name: 'Status' }), '')
    await user.type(screen.getByRole('searchbox', { name: 'Search by name, email or subject' }), 'v12@')
    await waitFor(() => expect(router.state.location.search).toBe('?q=v12%40'))
    expect(await screen.findByText('Visitor 12')).toBeInTheDocument()
    expect(listRequests(requests)).toContain('?q=v12%40&page=1&per_page=15')
  })

  it('explains an empty inbox, no results and a loading error', async () => {
    stubMessagesApi()
    const { router, unmount } = renderRoute('/admin/messages?status=unread')
    expect(await screen.findByText('No messages match these filters.')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Clear filters' }))
    expect(await screen.findByText('No messages yet.')).toBeInTheDocument()
    expect(screen.getByRole('status')).toHaveTextContent('No unread messages')
    expect(router.state.location.search).toBe('')
    unmount()

    stubMessagesApi({ list: 'error' })
    renderRoute('/admin/messages')
    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('The messages could not be loaded.')
    expect(within(alert).getByRole('button', { name: 'Retry' })).toBeInTheDocument()
  })

  it('is right-to-left in Arabic', async () => {
    window.localStorage.setItem('admin-locale', 'ar')
    stubMessagesApi({ messages: [omar(), sara()] })
    renderRoute('/admin/messages')

    expect(await screen.findByRole('heading', { level: 1, name: 'رسائل التواصل' })).toBeInTheDocument()
    expect(await screen.findByText('رسالة واحدة غير مقروءة')).toBeInTheDocument()
    expect(within(screen.getByRole('table')).getByText('مقروءة')).toBeInTheDocument()
    await waitFor(() => expect(document.documentElement).toHaveAttribute('dir', 'rtl'))
  })
})

describe('Admin contact inbox — message', () => {
  it('shows the full message as plain text without marking it read', async () => {
    const hostile = messageRecord({
      id: 9,
      subject: '<b>Bold?</b>',
      message: '<img src=x onerror="window.__pwned=1">\n<script>window.__pwned=2</script>\nSecond line',
    })
    const { requests } = stubMessagesApi({ messages: [hostile] })
    const user = userEvent.setup()
    renderRoute('/admin/messages')

    await user.click(await screen.findByRole('link', { name: 'Open the message from Sara Ahmed' }))
    const body = await screen.findByTestId('message-body')
    expect(body.textContent).toBe('<img src=x onerror="window.__pwned=1">\n<script>window.__pwned=2</script>\nSecond line')
    expect(body.querySelector('img, script')).toBeNull()
    expect(screen.getByRole('heading', { level: 2, name: '<b>Bold?</b>' }).querySelector('b')).toBeNull()
    expect((window as unknown as { __pwned?: number }).__pwned).toBeUndefined()

    expect(screen.getByText('Unread')).toBeInTheDocument()
    expect(screen.getByText('October 16, 2026')).toBeInTheDocument()
    expect(requests.some((request) => request.method !== 'GET')).toBe(false)
  })

  it('offers a safe reply link that sends nothing', async () => {
    stubMessagesApi({ messages: [sara(), messageRecord({ id: 5, email: 'not an email', reply_email: null })] })
    const first = renderRoute('/admin/messages/1')
    expect(await screen.findByRole('link', { name: 'Reply by email' })).toHaveAttribute('href', 'mailto:sara@example.com?subject=Re%3A%20Website%20redesign')
    expect(screen.getByText('Opens your email program. Nothing is sent automatically.')).toBeInTheDocument()
    first.unmount()

    renderRoute('/admin/messages/5')
    expect(await screen.findByText('The stored address is not a valid email, so no reply link is offered.')).toBeInTheDocument()
    expect(screen.queryByRole('link', { name: 'Reply by email' })).toBeNull()
  })

  it('marks a message read and unread', async () => {
    const { requests } = stubMessagesApi({ messages: [sara()] })
    const user = userEvent.setup()
    renderRoute('/admin/messages/1')

    await user.click(await screen.findByRole('button', { name: 'Mark as read' }))
    expect(await screen.findByText('The message is marked as read.')).toBeInTheDocument()
    expect(screen.getByText('Read')).toBeInTheDocument()
    expect(screen.getByText('October 17, 2026')).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Mark as unread' }))
    expect(await screen.findByText('The message is marked as unread.')).toBeInTheDocument()
    expect(screen.getByText('Unread')).toBeInTheDocument()

    const patches = requests.filter((request) => request.method === 'PATCH')
    expect(patches.map((request) => [request.path, request.body])).toEqual([
      ['/api/admin/messages/1/status', { status: 'read' }],
      ['/api/admin/messages/1/status', { status: 'unread' }],
    ])
    expect(patches[0]!.headers.get('X-XSRF-TOKEN')).toBeTruthy()
  })

  it('reports a failed change and keeps archived messages unchanged', async () => {
    stubMessagesApi({ messages: [sara(), archived()], statusError: 'server' })
    const user = userEvent.setup()
    const first = renderRoute('/admin/messages/1')
    await user.click(await screen.findByRole('button', { name: 'Mark as read' }))
    expect(await screen.findByText('The change could not be saved. Please try again.')).toBeInTheDocument()
    expect(screen.getByText('Unread')).toBeInTheDocument()
    first.unmount()

    renderRoute('/admin/messages/3')
    expect(await screen.findByText('Archived messages cannot be changed here.')).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /Mark as/ })).toBeNull()
  })

  it('explains a message that does not exist', async () => {
    stubMessagesApi()
    renderRoute('/admin/messages/999999')
    expect(await screen.findByText('This message does not exist.')).toBeInTheDocument()
    expect(screen.getByRole('link', { name: /Back to messages/ })).toHaveAttribute('href', '/admin/messages')
  })

  it('shows an Arabic message right-to-left', async () => {
    stubMessagesApi({ messages: [omar()] })
    renderRoute('/admin/messages/2')
    const body = await screen.findByTestId('message-body')
    expect(body).toHaveAttribute('dir', 'auto')
    expect(body).toHaveAttribute('lang', 'ar')
    expect(screen.getByText('Arabic')).toBeInTheDocument()
  })
})

describe('replyLink', () => {
  it('encodes characters that could add recipients or headers', () => {
    expect(replyLink('a?cc=evil@x.com&bcc=y@example.com', 'Hi')).toBe('mailto:a%3Fcc%3Devil%40x.com%26bcc%3Dy@example.com?subject=Re%3A%20Hi')
    expect(replyLink('user@example.com', '')).toBe('mailto:user@example.com?subject=Re%3A')
  })
})
