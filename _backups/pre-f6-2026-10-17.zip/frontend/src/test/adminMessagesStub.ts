/**
 * TEST FIXTURES ONLY — fake admin contact inbox API (A7) on top of stubAdminApi.
 * Follows the Laravel rules: newest first, search on name / email / subject, read / unread
 * only (archived cannot change, 409), CSRF on the status change, no delete.
 */
import type { AdminMessage } from '../admin/messagesApi'
import { stubAdminApi, type AdminStubOptions, type StubRequest } from './adminStub'

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })

let nextId = 300

export function messageRecord(overrides: Partial<AdminMessage> = {}): AdminMessage {
  const id = overrides.id ?? nextId++
  const message = overrides.message ?? 'Hello, I would like a new website.'
  return {
    id,
    name: 'Sara Ahmed',
    email: 'sara@example.com',
    reply_email: 'sara@example.com',
    subject: 'Website redesign',
    excerpt: message.slice(0, 140),
    message,
    locale: 'en',
    status: 'unread',
    read_at: null,
    created_at: '2026-10-16T09:30:00Z',
    ...overrides,
  }
}

export interface MessagesStubOptions extends AdminStubOptions {
  messages?: AdminMessage[]
  list?: 'error'
  statusError?: 'server'
}

export function stubMessagesApi(options: MessagesStubOptions = {}) {
  const messages: AdminMessage[] = [...(options.messages ?? [])]
  const unreadCount = () => messages.filter((message) => message.status === 'unread').length
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const summary = ({ message: _body, ...rest }: AdminMessage) => rest

  const handle = ({ method, url, body, csrfOk }: StubRequest): Response | undefined => {
    const path = url.pathname
    const match = path.match(/^\/api\/admin\/messages\/(\d+)(\/status)?$/)
    const found = match ? messages.find((message) => message.id === Number(match[1])) : undefined

    if (method === 'GET' && path === '/api/admin/messages') {
      if (options.list === 'error') return json({ message: 'Server Error' }, 500)
      const q = (url.searchParams.get('q') ?? '').toLowerCase()
      const status = url.searchParams.get('status')
      const perPage = Number(url.searchParams.get('per_page') ?? 15)
      const page = Number(url.searchParams.get('page') ?? 1)
      const all = messages
        .filter((message) => !q || [message.name, message.email, message.subject].some((value) => value.toLowerCase().includes(q)))
        .filter((message) => !status || message.status === status)
        .sort((x, y) => (y.created_at ?? '').localeCompare(x.created_at ?? ''))
      const data = all.slice((page - 1) * perPage, page * perPage).map(summary)
      return json({
        data,
        links: { first: null, last: null, prev: null, next: null },
        meta: { current_page: page, from: null, last_page: Math.max(1, Math.ceil(all.length / perPage)), links: [], path, per_page: perPage, to: null, total: all.length },
        unread_count: unreadCount(),
      })
    }

    if (method === 'GET' && match && !match[2]) return found ? json({ data: found, unread_count: unreadCount() }) : json({ message: 'Resource not found.' }, 404)

    if (method === 'PATCH' && match?.[2]) {
      if (!csrfOk()) return json({ message: 'CSRF token mismatch.' }, 419)
      if (!found) return json({ message: 'Resource not found.' }, 404)
      if (options.statusError === 'server') return json({ message: 'Server Error' }, 500)
      if (found.status === 'archived') return json({ message: 'Archived messages cannot be changed here.' }, 409)
      const status = (body as { status: 'read' | 'unread' }).status
      found.status = status
      found.read_at = status === 'read' ? (found.read_at ?? '2026-10-17T12:00:00Z') : null
      return json({ data: found, unread_count: unreadCount() })
    }

    return undefined
  }

  const api = stubAdminApi({ signedIn: true, ...options, handle })
  return { ...api, messages }
}
