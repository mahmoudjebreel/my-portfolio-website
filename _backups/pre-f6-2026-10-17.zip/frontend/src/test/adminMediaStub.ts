/**
 * TEST FIXTURES ONLY — fake admin media & site settings API (A6) on top of stubAdminApi.
 * Follows the Laravel rules: JPG/PNG/WebP up to 5 MB re-encoded to WebP, server-chosen
 * names, CSRF on writes, no delete; settings saved only on PUT, with validation.
 */
import type { AdminMediaItem, AdminSiteSettings, MediaProjectOption, SiteSettingsPayload } from '../admin/mediaApi'
import { stubAdminApi, type AdminStubOptions, type StubRequest } from './adminStub'

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })

export const MEDIA_PROJECTS: MediaProjectOption[] = [
  { id: 1, title: { en: 'Online Shop', ar: 'متجر إلكتروني' } },
  { id: 2, title: { en: 'Blog', ar: null } },
]

let nextId = 900

export function mediaItem(overrides: Partial<AdminMediaItem> = {}): AdminMediaItem {
  const kind = overrides.kind ?? 'gallery'
  const id = overrides.id ?? nextId++
  return {
    key: `${kind}-${id}`,
    kind,
    id,
    file_name: `image-${id}.webp`,
    mime_type: 'image/webp',
    size: 48_128,
    width: 1280,
    height: 720,
    sort_order: kind === 'gallery' ? 0 : null,
    alt: { en: null, ar: null },
    available: true,
    preview_url: `/api/admin/media/${kind}/${id}/preview`,
    project: { id: 1, status: 'published', title: MEDIA_PROJECTS[0]!.title },
    updated_at: '2026-10-16T10:00:00Z',
    ...overrides,
  }
}

const TEXT_KEYS = [
  'display_name',
  'professional_title',
  'hero_eyebrow',
  'hero_headline',
  'hero_description',
  'about_text',
  'experience_text',
  'footer_text',
  'seo_default_title',
  'seo_default_description',
] as const

export function siteSettings(overrides: { texts?: Partial<AdminSiteSettings['texts']>; values?: Partial<AdminSiteSettings['values']> } = {}): AdminSiteSettings {
  const texts = Object.fromEntries(TEXT_KEYS.map((key) => [key, { en: null, ar: null }])) as AdminSiteSettings['texts']
  return {
    texts: { ...texts, ...overrides.texts },
    values: { contact_email: null, github_url: null, linkedin_url: null, notification_email: null, ...overrides.values },
    images: { profile_image_path: { set: true, url: null }, og_default_image_path: { set: false, url: null } },
    limits: {
      texts: { display_name: 100, professional_title: 150, hero_eyebrow: 150, hero_headline: 200, hero_description: 1000, about_text: 5000, experience_text: 5000, footer_text: 300, seo_default_title: 120, seo_default_description: 300 },
      email: 254,
      url: 500,
    },
    private_keys: ['notification_email'],
  }
}

export interface MediaStubOptions extends AdminStubOptions {
  media?: AdminMediaItem[]
  settings?: AdminSiteSettings
  list?: 'error'
  settingsLoad?: 'error'
  /** Server-side refusal of the next upload (e.g. content that is not really an image). */
  uploadError?: string
  /** Server-side validation errors returned by the settings save. */
  saveErrors?: Record<string, string[]>
}

export function stubMediaApi(options: MediaStubOptions = {}) {
  const media: AdminMediaItem[] = [...(options.media ?? [])]
  let settings = options.settings ?? siteSettings()

  const handle = ({ method, url, body, csrfOk }: StubRequest): Response | undefined => {
    const path = url.pathname

    if (method === 'GET' && path === '/api/admin/media') {
      if (options.list === 'error') return json({ message: 'Server Error' }, 500)
      const q = (url.searchParams.get('q') ?? '').toLowerCase()
      const project = Number(url.searchParams.get('project'))
      const kind = url.searchParams.get('kind')
      const perPage = Number(url.searchParams.get('per_page') ?? 12)
      const page = Number(url.searchParams.get('page') ?? 1)
      const all = media
        .filter((item) => !q || [item.file_name, item.project.title.en, item.project.title.ar].some((value) => value?.toLowerCase().includes(q)))
        .filter((item) => !project || item.project.id === project)
        .filter((item) => !kind || item.kind === kind)
      const data = all.slice((page - 1) * perPage, page * perPage)
      return json({
        data,
        links: { first: null, last: null, prev: null, next: null },
        meta: { current_page: page, from: null, last_page: Math.max(1, Math.ceil(all.length / perPage)), links: [], path, per_page: perPage, to: null, total: all.length },
        projects: MEDIA_PROJECTS,
      })
    }

    if (method === 'GET' && path === '/api/admin/site-settings') {
      if (options.settingsLoad === 'error') return json({ message: 'Server Error' }, 500)
      return json({ data: settings })
    }

    if (method !== 'GET' && !csrfOk()) return json({ message: 'CSRF token mismatch.' }, 419)

    if (method === 'POST' && path === '/api/admin/media') {
      const form = body as FormData
      const file = form.get('file') as File
      const projectId = Number(form.get('project_id'))
      if (options.uploadError) return json({ message: options.uploadError, errors: { file: [options.uploadError] } }, 422)
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        return json({ message: 'Only JPG, PNG and WebP images are accepted.', errors: { file: ['Only JPG, PNG and WebP images are accepted.'] } }, 422)
      }
      const project = MEDIA_PROJECTS.find((item) => item.id === projectId)!
      const created = mediaItem({
        file_name: '6f1c2a9e-0000-4000-8000-000000000001.webp',
        project: { id: project.id, status: 'draft', title: project.title },
        alt: { en: (form.get('alt[en]') as string | null) ?? null, ar: (form.get('alt[ar]') as string | null) ?? null },
        updated_at: '2026-10-17T12:00:00Z',
      })
      media.unshift(created)
      return json({ data: created }, 201)
    }

    if (method === 'PUT' && path === '/api/admin/site-settings') {
      const payload = body as SiteSettingsPayload
      const errors: Record<string, string[]> = { ...options.saveErrors }
      if (payload.values.github_url && !/^https?:\/\//.test(payload.values.github_url)) errors['values.github_url'] = ['The values.github_url field must be a valid URL.']
      if ((payload.texts.footer_text.en ?? '').length > 300) errors['texts.footer_text.en'] = ['The texts.footer_text.en field must not be greater than 300 characters.']
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      settings = {
        ...settings,
        texts: Object.fromEntries(Object.entries(payload.texts).map(([key, value]) => [key, { en: value.en ?? '', ar: value.ar ?? '' }])) as AdminSiteSettings['texts'],
        values: payload.values,
      }
      return json({ data: settings })
    }

    return undefined
  }

  const api = stubAdminApi({ signedIn: true, ...options, handle })
  return { ...api, media, getSettings: () => settings }
}
