/**
 * TEST FIXTURES ONLY — a fake `fetch` that answers like the Laravel admin API from A1
 * (backend/routes/admin.php): session state on the "server", an XSRF-TOKEN cookie issued by
 * GET /api/admin/csrf-cookie and rotated at sign-in and sign-out, 419 for a missing or wrong
 * X-XSRF-TOKEN header, one generic 422 for bad credentials.
 */
import { vi } from 'vitest'
import type { AdminUser } from '../admin/api'

export const OWNER: AdminUser = { id: 1, name: 'Site Owner', email: 'owner@example.com' }
export const OWNER_PASSWORD = 'correct horse battery staple'

export interface AdminStubOptions {
  /** Already signed in on the server. */
  signedIn?: boolean
  me?: 'network' | 'forbidden'
  login?: 'network' | { rateLimited: number | null }
  logout?: 'network'
  /** GET /admin/me never answers. */
  pendingMe?: boolean
  /** Extra routes (e.g. projects); return undefined to fall through to 404. */
  handle?: (request: StubRequest) => Response | Promise<Response> | undefined
}

export interface StubRequest {
  method: string
  url: URL
  headers: Headers
  body: unknown
  csrfOk: () => boolean
}

export interface RecordedRequest {
  method: string
  path: string
  /** Query string, e.g. "?q=shop&per_page=10". */
  search: string
  headers: Headers
  body: unknown
}

const json = (body: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...headers } })

export function setXsrfCookie(value: string) {
  document.cookie = `XSRF-TOKEN=${encodeURIComponent(value)}; path=/`
}

export function clearAdminCookies() {
  document.cookie = 'XSRF-TOKEN=; path=/; max-age=0'
}

export function stubAdminApi(options: AdminStubOptions = {}) {
  const server = { user: options.signedIn ? OWNER : null, token: null as string | null, issued: 0, me: options.me }
  const requests: RecordedRequest[] = []

  const issueToken = () => {
    server.issued += 1
    server.token = `token=${server.issued}/x`
    setXsrfCookie(server.token)
  }
  const csrfOk = (headers: Headers) => server.token !== null && headers.get('X-XSRF-TOKEN') === server.token

  const fetchMock = vi.fn<(input: string, init?: RequestInit) => Promise<Response>>(async (input, init) => {
    const url = new URL(input, 'http://localhost')
    const method = init?.method ?? 'GET'
    const headers = new Headers(init?.headers)
    const body = typeof init?.body === 'string' ? JSON.parse(init.body) : init?.body instanceof FormData ? init.body : undefined
    requests.push({ method, path: url.pathname, search: url.search, headers, body })

    switch (`${method} ${url.pathname}`) {
      case 'GET /api/admin/csrf-cookie':
        issueToken()
        return new Response(null, { status: 204 })

      case 'GET /api/admin/me':
        if (options.pendingMe) return new Promise<Response>(() => {})
        if (server.me === 'network') throw new TypeError('Failed to fetch')
        if (server.me === 'forbidden') return json({ message: 'Forbidden.' }, 403)
        return server.user ? json({ data: server.user }) : json({ message: 'Unauthenticated.' }, 401)

      case 'POST /api/admin/login': {
        if (options.login === 'network') throw new TypeError('Failed to fetch')
        if (!csrfOk(headers)) return json({ message: 'CSRF token mismatch.' }, 419)
        if (typeof options.login === 'object') {
          const retry = options.login.rateLimited
          return json({ message: 'Too many login attempts. Please try again later.' }, 429, retry ? { 'Retry-After': String(retry) } : {})
        }
        const credentials = body as { email?: string; password?: string }
        if (credentials.email === OWNER.email && credentials.password === OWNER_PASSWORD) {
          server.user = OWNER
          issueToken() // the session and its token are regenerated at sign-in
          return json({ data: OWNER })
        }
        const message = 'These credentials do not match our records.'
        return json({ message, errors: { email: [message] } }, 422)
      }

      case 'POST /api/admin/logout':
        if (options.logout === 'network') throw new TypeError('Failed to fetch')
        if (!csrfOk(headers)) return json({ message: 'CSRF token mismatch.' }, 419)
        server.user = null
        issueToken()
        return new Response(null, { status: 204 })

      default: {
        const handled = await options.handle?.({ method, url, headers, body, csrfOk: () => csrfOk(headers) })
        return handled ?? json({ message: 'Resource not found.' }, 404)
      }
    }
  })

  vi.stubGlobal('fetch', fetchMock)
  return { server, requests, fetchMock }
}
