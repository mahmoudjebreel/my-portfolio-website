/**
 * TEST FIXTURES ONLY — fake admin categories & technologies API (A5) on top of stubAdminApi.
 * Follows the Laravel rules: one language at least for a category, names and slugs unique,
 * visibility chosen only when creating, CSRF on writes, server-side pagination, no delete.
 */
import type { AdminCategory, AdminTechnology, CategoryPayload, TechnologyPayload } from '../admin/catalogApi'
import type { Locale } from '../i18n/config'
import { stubAdminApi, type AdminStubOptions, type StubRequest } from './adminStub'

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })

let nextId = 500

export function categoryRecord(overrides: Partial<AdminCategory> = {}): AdminCategory {
  const projects = overrides.projects_count ?? 0
  return {
    id: nextId++,
    sort_order: 0,
    translations: { en: { name: 'Web Applications', slug: 'web-applications' }, ar: null },
    updated_at: '2026-10-16T10:00:00Z',
    ...overrides,
    projects_count: projects,
    in_use: projects > 0,
  }
}

export function technologyRecord(overrides: Partial<AdminTechnology> = {}): AdminTechnology {
  const projects = overrides.projects_count ?? 0
  return {
    id: nextId++,
    name: 'React',
    slug: 'react',
    group: 'frontend',
    icon: null,
    is_visible: true,
    sort_order: 0,
    translations: { en: null, ar: null },
    updated_at: '2026-10-16T10:00:00Z',
    ...overrides,
    projects_count: projects,
    in_use: projects > 0,
  }
}

export interface CatalogStubOptions extends AdminStubOptions {
  categories?: AdminCategory[]
  technologies?: AdminTechnology[]
  list?: 'error' | 'unauthenticated'
}

function paginate<T>(all: T[], url: URL, path: string) {
  const perPage = Number(url.searchParams.get('per_page') ?? 10)
  const page = Number(url.searchParams.get('page') ?? 1)
  const data = all.slice((page - 1) * perPage, page * perPage)
  return json({
    data,
    links: { first: null, last: null, prev: null, next: null },
    meta: { current_page: page, from: data.length ? (page - 1) * perPage + 1 : null, last_page: Math.max(1, Math.ceil(all.length / perPage)), links: [], path, per_page: perPage, to: null, total: all.length },
  })
}

export function stubCatalogApi(options: CatalogStubOptions = {}) {
  const categories: AdminCategory[] = [...(options.categories ?? [])]
  const technologies: AdminTechnology[] = [...(options.technologies ?? [])]

  const validateCategory = (payload: CategoryPayload, ignoreId?: number) => {
    const errors: Record<string, string[]> = {}
    for (const locale of ['en', 'ar'] as Locale[]) {
      const names = payload.translations[locale]
      if (!names) continue
      const others = categories.filter((category) => category.id !== ignoreId).map((category) => category.translations[locale])
      if (others.some((other) => other?.name === names.name)) errors[`translations.${locale}.name`] = ['This name is already used by another category in this language.']
      if (others.some((other) => other?.slug === names.slug)) errors[`translations.${locale}.slug`] = ['This slug is already used by another category in this language.']
    }
    if (!payload.translations.en && !payload.translations.ar) errors.translations = ['Fill in the name in at least one language.']
    return errors
  }

  const validateTechnology = (payload: TechnologyPayload, ignoreId?: number) => {
    const errors: Record<string, string[]> = {}
    const others = technologies.filter((technology) => technology.id !== ignoreId)
    if (others.some((other) => other.name === payload.name)) errors.name = ['This name is already used by another technology.']
    if (others.some((other) => other.slug === payload.slug)) errors.slug = ['This slug is already used by another technology.']
    return errors
  }

  const handle = ({ method, url, body, csrfOk }: StubRequest): Response | undefined => {
    const path = url.pathname
    const categoryMatch = path.match(/^\/api\/admin\/categories\/(\d+)$/)
    const technologyMatch = path.match(/^\/api\/admin\/technologies\/(\d+)$/)
    const category = categoryMatch ? categories.find((item) => item.id === Number(categoryMatch[1])) : undefined
    const technology = technologyMatch ? technologies.find((item) => item.id === Number(technologyMatch[1])) : undefined
    const q = (url.searchParams.get('q') ?? '').toLowerCase()

    if (method === 'GET' && (path === '/api/admin/categories' || path === '/api/admin/technologies')) {
      if (options.list === 'error') return json({ message: 'Server Error' }, 500)
      if (options.list === 'unauthenticated') return json({ message: 'Unauthenticated.' }, 401)
    }

    if (method === 'GET' && path === '/api/admin/categories') {
      const all = categories.filter((item) => !q || [item.translations.en?.name, item.translations.ar?.name].some((name) => name?.toLowerCase().includes(q)))
      return paginate(all, url, path)
    }
    if (method === 'GET' && path === '/api/admin/technologies') {
      const group = url.searchParams.get('group')
      const visibility = url.searchParams.get('visibility')
      const all = technologies
        .filter((item) => !q || item.name.toLowerCase().includes(q))
        .filter((item) => !group || item.group === group)
        .filter((item) => !visibility || item.is_visible === (visibility === 'visible'))
      return paginate(all, url, path)
    }
    if (method === 'GET' && categoryMatch) return category ? json({ data: category }) : json({ message: 'Resource not found.' }, 404)
    if (method === 'GET' && technologyMatch) return technology ? json({ data: technology }) : json({ message: 'Resource not found.' }, 404)

    if (method !== 'GET' && !csrfOk()) return json({ message: 'CSRF token mismatch.' }, 419)

    if (method === 'POST' && path === '/api/admin/categories') {
      const payload = body as CategoryPayload
      const errors = validateCategory(payload)
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      const created = categoryRecord({ sort_order: payload.sort_order, translations: payload.translations, updated_at: '2026-10-17T12:00:00Z' })
      categories.unshift(created)
      return json({ data: created }, 201)
    }
    if (method === 'PUT' && categoryMatch) {
      if (!category) return json({ message: 'Resource not found.' }, 404)
      const payload = body as CategoryPayload
      const errors = validateCategory(payload, category.id)
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      category.sort_order = payload.sort_order
      category.translations = { en: payload.translations.en ?? category.translations.en, ar: payload.translations.ar ?? category.translations.ar }
      return json({ data: category })
    }
    if (method === 'POST' && path === '/api/admin/technologies') {
      const payload = body as TechnologyPayload
      const errors = validateTechnology(payload)
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      const created = technologyRecord({ ...payload, is_visible: payload.is_visible ?? false, updated_at: '2026-10-17T12:00:00Z' })
      technologies.unshift(created)
      return json({ data: created }, 201)
    }
    if (method === 'PUT' && technologyMatch) {
      if (!technology) return json({ message: 'Resource not found.' }, 404)
      const payload = body as TechnologyPayload
      const errors = validateTechnology(payload, technology.id)
      if (Object.keys(errors).length) return json({ message: 'The given data was invalid.', errors }, 422)
      const { is_visible: _ignored, ...changes } = payload // like the server: never changed by an update
      void _ignored
      Object.assign(technology, changes)
      return json({ data: technology })
    }
    return undefined
  }

  const api = stubAdminApi({ signedIn: true, ...options, handle })
  return { ...api, categories, technologies }
}
