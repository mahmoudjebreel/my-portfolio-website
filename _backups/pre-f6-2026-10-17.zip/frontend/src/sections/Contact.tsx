import { useId, useState, type FormEvent } from 'react'
import { Reveal } from '../components/ui/Reveal'
import { SectionHeading } from '../components/ui/SectionHeading'
import { useI18n } from '../i18n/I18nProvider'

type Field = 'name' | 'email' | 'subject' | 'message'
type Values = Record<Field, string>

// Same limits as the server-side rules in the approved design.
const LIMITS: Record<Field, { min: number; max: number }> = {
  name: { min: 2, max: 100 },
  email: { min: 3, max: 254 },
  subject: { min: 3, max: 150 },
  message: { min: 10, max: 5000 },
}
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export function Contact() {
  const { t } = useI18n()
  const formId = useId()
  const [values, setValues] = useState<Values>({ name: '', email: '', subject: '', message: '' })
  const [touched, setTouched] = useState<Partial<Record<Field, boolean>>>({})
  const [notice, setNotice] = useState(false)

  const errorFor = (field: Field): string | null => {
    const value = values[field].trim()
    if (!value) return t.contact.required
    if (field === 'email' && !EMAIL.test(value)) return t.contact.invalidEmail
    if (value.length < LIMITS[field].min) return t.contact.tooShort(LIMITS[field].min)
    return null
  }

  const onSubmit = (event: FormEvent) => {
    event.preventDefault()
    setTouched({ name: true, email: true, subject: true, message: true })
    const firstInvalid = (Object.keys(values) as Field[]).find((field) => errorFor(field))
    if (firstInvalid) {
      document.getElementById(`${formId}-${firstInvalid}`)?.focus()
      setNotice(false)
      return
    }
    // Not connected to the API yet: never pretend the message was sent.
    setNotice(true)
  }

  const field = (name: Field, label: string, type: 'text' | 'email' | 'textarea' = 'text') => {
    const id = `${formId}-${name}`
    const error = touched[name] ? errorFor(name) : null
    const common = {
      id,
      name,
      value: values[name],
      maxLength: LIMITS[name].max,
      required: true,
      'aria-invalid': Boolean(error),
      'aria-describedby': error ? `${id}-error` : undefined,
      onChange: (event: { target: { value: string } }) => setValues((v) => ({ ...v, [name]: event.target.value })),
      onBlur: () => setTouched((v) => ({ ...v, [name]: true })),
      className:
        'w-full rounded-xl border border-white/10 bg-white/[0.04] px-4 py-3 text-white placeholder:text-slate-500 transition focus:border-cyan-300/60 focus:bg-white/[0.07] focus:outline-none aria-[invalid=true]:border-rose-400/60',
    }
    return (
      <div className={name === 'message' ? 'sm:col-span-2' : undefined}>
        <label htmlFor={id} className="mb-2 block text-sm font-medium text-slate-200">
          {label}
        </label>
        {type === 'textarea' ? (
          <textarea {...common} rows={6} />
        ) : (
          <input {...common} type={type} autoComplete={name === 'name' ? 'name' : name === 'email' ? 'email' : 'off'} />
        )}
        {error && (
          <p id={`${id}-error`} className="mt-2 text-sm text-rose-300">
            {error}
          </p>
        )}
      </div>
    )
  }

  return (
    <section id="contact" aria-labelledby="contact-title" className="relative py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <SectionHeading id="contact-title" eyebrow={t.contact.eyebrow} title={t.contact.title} />
            <Reveal>
              <p className="-mt-6 max-w-md leading-relaxed text-slate-400">{t.contact.text}</p>
            </Reveal>
          </div>

          <Reveal delay={0.1}>
            <form noValidate onSubmit={onSubmit} className="glass grid gap-5 rounded-3xl p-6 sm:grid-cols-2 sm:p-8">
              {field('name', t.contact.name)}
              {field('email', t.contact.email, 'email')}
              <div className="sm:col-span-2">{field('subject', t.contact.subject)}</div>
              {field('message', t.contact.message, 'textarea')}
              <div className="flex flex-col gap-4 sm:col-span-2">
                <button
                  type="submit"
                  className="inline-flex w-full items-center justify-center rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-7 py-3.5 font-semibold text-ink-950 transition hover:brightness-110 sm:w-auto sm:self-start"
                >
                  {t.contact.send}
                </button>
                <p role="status" className="text-sm text-amber-200/90">
                  {notice ? t.contact.notConnected : ''}
                </p>
              </div>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
