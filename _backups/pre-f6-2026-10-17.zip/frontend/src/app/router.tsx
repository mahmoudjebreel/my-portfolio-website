import { Navigate, createBrowserRouter, type RouteObject } from 'react-router'
import { AdminBootFallback, AdminRouteError } from '../admin/RouteFallbacks'
import { RouteError, RouteLoading } from '../components/ui/RouteStates'
import { DEFAULT_LOCALE, detectPreferredLocale } from '../i18n/config'
import { I18nProvider } from '../i18n/I18nProvider'
import { HomePage } from '../pages/HomePage'
import { NotFoundPage } from '../pages/NotFoundPage'
import { LocaleLayout } from './LocaleLayout'

function RootRedirect() {
  return <Navigate to={`/${detectPreferredLocale()}`} replace />
}

/*
 * The project pages are loaded on demand (own chunks), so the home page never waits for
 * their code. A direct visit shows RouteLoading inside the layout; a failed download
 * (offline, new deployment) shows RouteError instead of the router's default error screen.
 */
const lazyPage = {
  hydrateFallbackElement: <RouteLoading />,
  errorElement: <RouteError />,
}

/*
 * Administration (/admin): its own lazy chunks, never loaded by the public site. The static
 * "/admin" segment ranks above "/:locale". Access is decided by Laravel (session + is_admin);
 * the pages only display what the API allows.
 */
const adminRoutes: RouteObject = {
  path: '/admin',
  hydrateFallbackElement: <AdminBootFallback />,
  errorElement: <AdminRouteError />,
  lazy: async () => ({ Component: (await import('../admin/AdminRoot')).AdminRoot }),
  children: [
    { path: 'login', lazy: async () => ({ Component: (await import('../admin/pages/AdminLoginPage')).AdminLoginPage }) },
    {
      lazy: async () => ({ Component: (await import('../admin/AdminShell')).AdminShell }),
      children: [
        { index: true, lazy: async () => ({ Component: (await import('../admin/pages/AdminHomePage')).AdminHomePage }) },
        { path: 'projects', lazy: async () => ({ Component: (await import('../admin/pages/AdminProjectsPage')).AdminProjectsPage }) },
        { path: 'projects/new', lazy: async () => ({ Component: (await import('../admin/pages/AdminProjectFormPage')).AdminProjectFormPage }) },
        { path: 'projects/:id/edit', lazy: async () => ({ Component: (await import('../admin/pages/AdminProjectFormPage')).AdminProjectFormPage }) },
        { path: 'categories', lazy: async () => ({ Component: (await import('../admin/pages/AdminCategoriesPage')).AdminCategoriesPage }) },
        { path: 'categories/new', lazy: async () => ({ Component: (await import('../admin/pages/AdminCategoryFormPage')).AdminCategoryFormPage }) },
        { path: 'categories/:id/edit', lazy: async () => ({ Component: (await import('../admin/pages/AdminCategoryFormPage')).AdminCategoryFormPage }) },
        { path: 'technologies', lazy: async () => ({ Component: (await import('../admin/pages/AdminTechnologiesPage')).AdminTechnologiesPage }) },
        { path: 'technologies/new', lazy: async () => ({ Component: (await import('../admin/pages/AdminTechnologyFormPage')).AdminTechnologyFormPage }) },
        { path: 'technologies/:id/edit', lazy: async () => ({ Component: (await import('../admin/pages/AdminTechnologyFormPage')).AdminTechnologyFormPage }) },
        { path: 'media', lazy: async () => ({ Component: (await import('../admin/pages/AdminMediaPage')).AdminMediaPage }) },
        { path: 'settings', lazy: async () => ({ Component: (await import('../admin/pages/AdminSettingsPage')).AdminSettingsPage }) },
        { path: 'messages', lazy: async () => ({ Component: (await import('../admin/pages/AdminMessagesPage')).AdminMessagesPage }) },
        { path: 'messages/:id', lazy: async () => ({ Component: (await import('../admin/pages/AdminMessagePage')).AdminMessagePage }) },
        { path: '*', lazy: async () => ({ Component: (await import('../admin/pages/AdminNotFoundPage')).AdminNotFoundPage }) },
      ],
    },
  ],
}

export const routes: RouteObject[] = [
  { path: '/', element: <RootRedirect /> },
  adminRoutes,
  {
    path: '/:locale',
    element: <LocaleLayout />,
    children: [
      { index: true, element: <HomePage /> },
      {
        path: 'projects',
        ...lazyPage,
        lazy: async () => ({ Component: (await import('../pages/ProjectsPage')).ProjectsPage }),
      },
      {
        path: 'projects/:slug',
        ...lazyPage,
        lazy: async () => ({ Component: (await import('../pages/ProjectDetailPage')).ProjectDetailPage }),
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
  {
    path: '*',
    element: (
      <I18nProvider locale={DEFAULT_LOCALE}>
        <NotFoundPage />
      </I18nProvider>
    ),
  },
]

export const createRouter = () => createBrowserRouter(routes)
