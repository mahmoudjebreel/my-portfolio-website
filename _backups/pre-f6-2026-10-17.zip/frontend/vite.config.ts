/// <reference types="vitest/config" />
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'
import { parseDataSource } from './src/data/sourceConfig.ts'

const DEFAULT_PROXY_TARGET = 'http://127.0.0.1:8010'

export default defineConfig(({ command, mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  // Fails fast on an invalid VITE_DATA_SOURCE, and refuses "mock" for production builds.
  parseDataSource(env.VITE_DATA_SOURCE, { production: command === 'build' && mode === 'production' })

  // The Laravel API of this project runs on `php artisan serve` (127.0.0.1:8010 by default).
  // The dev server proxies API, Sanctum and storage requests so the SPA and the API share one origin.
  const backend = env.VITE_API_PROXY_TARGET?.trim() || DEFAULT_PROXY_TARGET
  if (!/^https?:\/\/[^\s/]+$/.test(backend)) {
    throw new Error(`VITE_API_PROXY_TARGET must be an origin like ${DEFAULT_PROXY_TARGET} (got "${backend}").`)
  }

  return {
    plugins: [react(), tailwindcss()],
    server: {
      host: '127.0.0.1',
      port: 5173,
      strictPort: true,
      proxy: {
        '/api': backend,
        '/sanctum': backend,
        '/storage': backend,
      },
    },
    build: {
      target: 'es2022',
      sourcemap: false,
    },
    test: {
      environment: 'jsdom',
      setupFiles: ['./src/test/setup.ts'],
      css: false,
      restoreMocks: true,
      unstubGlobals: true,
      unstubEnvs: true,
      // Worker threads start reliably on this Windows setup (forked workers timed out on startup).
      pool: 'threads',
    },
  }
})
